"""REV23 Finding 4 I0A -- sole owner of immutable target/prepared-unit path
grammars, placeholder domains, accepted-registry parsing/indexing, and
frozen schema-binding tables.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Governing sections: Finding 4 SS3.4, 5.1-5.3; accepted PATH_GRAMMAR_REGISTRY.json;
accepted PREPARED_ROLE_MATRIX.json; accepted SCHEMA_REGISTRY_REV23.json

This module performs no filesystem, network, or subprocess side effects and
never imports prepared_evidence.py, governing_package.py, or claim_hashes.py.
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple

from .canonical import AssuranceLevel, I0AResultCode, ValidationResult

__all__ = [
    "FrozenPathGrammarId",
    "PreparedObjectRole",
    "PreparedUnitKind",
    "I0AInputUnitKind",
    "PublicationMode",
    "UnitContext",
    "RegistryDefinitionIndex",
    "RegistryDefinitionIndexResult",
    "BindingQuery",
    "SchemaBinding",
    "BindingResolutionResult",
    "build_accepted_registry_schema_definition_index",
    "resolve_selected_schema_binding",
    "validate_normalized_relative_path",
]

class FrozenPathGrammarId(Enum):
    TARGET_PARTITION_PAYLOAD_00 = "TARGET_PARTITION_PAYLOAD_00"
    TARGET_HISTORY_MANIFEST_00 = "TARGET_HISTORY_MANIFEST_00"
    TARGET_HISTORY_MANIFEST_SIDECAR_00 = "TARGET_HISTORY_MANIFEST_SIDECAR_00"
    TARGET_HISTORY_INDEX_00 = "TARGET_HISTORY_INDEX_00"
    TARGET_PUBLICATION_MARKER_00 = "TARGET_PUBLICATION_MARKER_00"
    TARGET_PUBLICATION_MARKER_SIDECAR_00 = "TARGET_PUBLICATION_MARKER_SIDECAR_00"
    TARGET_CURRENT_GENERATION_MANIFEST_00 = "TARGET_CURRENT_GENERATION_MANIFEST_00"
    TARGET_CURRENT_GENERATION_MANIFEST_SIDECAR_00 = (
        "TARGET_CURRENT_GENERATION_MANIFEST_SIDECAR_00"
    )
    TARGET_CURRENT_GENERATION_INDEX_00 = "TARGET_CURRENT_GENERATION_INDEX_00"
    TARGET_CURRENT_GENERATION_MARKER_00 = "TARGET_CURRENT_GENERATION_MARKER_00"
    TARGET_CURRENT_GENERATION_MARKER_SIDECAR_00 = (
        "TARGET_CURRENT_GENERATION_MARKER_SIDECAR_00"
    )
    TARGET_LEGACY_CURRENT_MANIFEST_00 = "TARGET_LEGACY_CURRENT_MANIFEST_00"
    TARGET_LEGACY_CURRENT_MANIFEST_SIDECAR_00 = (
        "TARGET_LEGACY_CURRENT_MANIFEST_SIDECAR_00"
    )
    TARGET_LEGACY_CURRENT_INDEX_00 = "TARGET_LEGACY_CURRENT_INDEX_00"
    TARGET_BOUND_PAYLOAD_INTENT_00 = "TARGET_BOUND_PAYLOAD_INTENT_00"
    TARGET_BOUND_PAYLOAD_INTENT_SIDECAR_00 = "TARGET_BOUND_PAYLOAD_INTENT_SIDECAR_00"
    TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_00 = (
        "TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_00"
    )
    TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR_00 = (
        "TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR_00"
    )
    TARGET_FENCE_UNIT_MANIFEST_00 = "TARGET_FENCE_UNIT_MANIFEST_00"
    TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00 = "TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00"
    TARGET_FENCE_EVENT_00 = "TARGET_FENCE_EVENT_00"
    TARGET_FENCE_EVENT_SIDECAR_00 = "TARGET_FENCE_EVENT_SIDECAR_00"
    TARGET_AUTHORIZATION_USE_ROW_BATCH_00 = "TARGET_AUTHORIZATION_USE_ROW_BATCH_00"
    TARGET_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_00 = (
        "TARGET_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_00"
    )
    TARGET_CAPTURE_ROW_BATCH_00 = "TARGET_CAPTURE_ROW_BATCH_00"
    TARGET_CAPTURE_ROW_BATCH_SIDECAR_00 = "TARGET_CAPTURE_ROW_BATCH_SIDECAR_00"
    TARGET_NORMAL_FINAL_INVENTORY_00 = "TARGET_NORMAL_FINAL_INVENTORY_00"
    TARGET_NORMAL_FINAL_INVENTORY_01 = "TARGET_NORMAL_FINAL_INVENTORY_01"
    TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_00 = (
        "TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_00"
    )
    TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_01 = (
        "TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_01"
    )
    TARGET_NORMAL_FINAL_MARKER_00 = "TARGET_NORMAL_FINAL_MARKER_00"
    TARGET_NORMAL_FINAL_MARKER_01 = "TARGET_NORMAL_FINAL_MARKER_01"
    TARGET_NORMAL_FINAL_MARKER_SIDECAR_00 = "TARGET_NORMAL_FINAL_MARKER_SIDECAR_00"
    TARGET_NORMAL_FINAL_MARKER_SIDECAR_01 = "TARGET_NORMAL_FINAL_MARKER_SIDECAR_01"
    PREPARED_CLAIM_SCOPE_JSON = "PREPARED_CLAIM_SCOPE_JSON"
    PREPARED_CLAIM_SCOPE_SHA256 = "PREPARED_CLAIM_SCOPE_SHA256"
    PREPARED_CLAIM_SEMANTIC_JSON = "PREPARED_CLAIM_SEMANTIC_JSON"
    PREPARED_CLAIM_SEMANTIC_SHA256 = "PREPARED_CLAIM_SEMANTIC_SHA256"
    PREPARED_PREPARATION_PLAN_JSON = "PREPARED_PREPARATION_PLAN_JSON"
    PREPARED_PREPARATION_PLAN_SHA256 = "PREPARED_PREPARATION_PLAN_SHA256"
    PREPARED_PREPARED_UNIT_JSON = "PREPARED_PREPARED_UNIT_JSON"
    PREPARED_PREPARED_UNIT_SHA256 = "PREPARED_PREPARED_UNIT_SHA256"
    PREPARED_OBJECT_BIN = "PREPARED_OBJECT_BIN"


class PreparedObjectRole(Enum):
    PARTITION_PAYLOAD = "PARTITION_PAYLOAD"
    HISTORY_MANIFEST = "HISTORY_MANIFEST"
    HISTORY_MANIFEST_SIDECAR = "HISTORY_MANIFEST_SIDECAR"
    HISTORY_INDEX = "HISTORY_INDEX"
    PUBLICATION_MARKER = "PUBLICATION_MARKER"
    PUBLICATION_MARKER_SIDECAR = "PUBLICATION_MARKER_SIDECAR"
    CURRENT_GENERATION_MANIFEST = "CURRENT_GENERATION_MANIFEST"
    CURRENT_GENERATION_MANIFEST_SIDECAR = "CURRENT_GENERATION_MANIFEST_SIDECAR"
    CURRENT_GENERATION_INDEX = "CURRENT_GENERATION_INDEX"
    CURRENT_GENERATION_MARKER = "CURRENT_GENERATION_MARKER"
    CURRENT_GENERATION_MARKER_SIDECAR = "CURRENT_GENERATION_MARKER_SIDECAR"
    LEGACY_CURRENT_MANIFEST = "LEGACY_CURRENT_MANIFEST"
    LEGACY_CURRENT_MANIFEST_SIDECAR = "LEGACY_CURRENT_MANIFEST_SIDECAR"
    LEGACY_CURRENT_INDEX = "LEGACY_CURRENT_INDEX"
    BOUND_PAYLOAD_INTENT = "BOUND_PAYLOAD_INTENT"
    BOUND_PAYLOAD_INTENT_SIDECAR = "BOUND_PAYLOAD_INTENT_SIDECAR"
    BOUND_SNAPSHOT_CLAIM_SEMANTIC = "BOUND_SNAPSHOT_CLAIM_SEMANTIC"
    BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR = "BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR"
    FENCE_UNIT_MANIFEST = "FENCE_UNIT_MANIFEST"
    FENCE_UNIT_MANIFEST_SIDECAR = "FENCE_UNIT_MANIFEST_SIDECAR"
    FENCE_EVENT = "FENCE_EVENT"
    FENCE_EVENT_SIDECAR = "FENCE_EVENT_SIDECAR"
    AUTHORIZATION_USE_ROW_BATCH = "AUTHORIZATION_USE_ROW_BATCH"
    AUTHORIZATION_USE_ROW_BATCH_SIDECAR = "AUTHORIZATION_USE_ROW_BATCH_SIDECAR"
    CAPTURE_ROW_BATCH = "CAPTURE_ROW_BATCH"
    CAPTURE_ROW_BATCH_SIDECAR = "CAPTURE_ROW_BATCH_SIDECAR"
    NORMAL_FINAL_INVENTORY = "NORMAL_FINAL_INVENTORY"
    NORMAL_FINAL_INVENTORY_SIDECAR = "NORMAL_FINAL_INVENTORY_SIDECAR"
    NORMAL_FINAL_MARKER = "NORMAL_FINAL_MARKER"
    NORMAL_FINAL_MARKER_SIDECAR = "NORMAL_FINAL_MARKER_SIDECAR"


class PreparedUnitKind(Enum):
    SNAPSHOT_PUBLICATION = "SNAPSHOT_PUBLICATION"
    FENCE_ACQUIRED = "FENCE_ACQUIRED"
    AUTHORIZATION_USE_EVENT_COMMITTED = "AUTHORIZATION_USE_EVENT_COMMITTED"
    REQUEST_RESERVED_COMMITTED = "REQUEST_RESERVED_COMMITTED"
    CAPTURE_STARTED_COMMITTED = "CAPTURE_STARTED_COMMITTED"
    CAPTURE_TERMINAL_COMMITTED = "CAPTURE_TERMINAL_COMMITTED"
    CAPTURE_SNAPSHOT_COMMITTED = "CAPTURE_SNAPSHOT_COMMITTED"
    CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED = (
        "CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED"
    )
    CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED = (
        "CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED"
    )
    FENCE_RELEASED = "FENCE_RELEASED"
    NORMAL_FINALIZATION = "NORMAL_FINALIZATION"


class I0AInputUnitKind(Enum):
    SNAPSHOT_PUBLICATION = "SNAPSHOT_PUBLICATION"


class PublicationMode(Enum):
    ATOMIC_BUNDLE_MEMBER = "ATOMIC_BUNDLE_MEMBER"
    SINGLE_AUTHORITATIVE_FILE = "SINGLE_AUTHORITATIVE_FILE"
    REUSE_IMMUTABLE_SOURCE = "REUSE_IMMUTABLE_SOURCE"
    DERIVED_VIEW_TARGET = "DERIVED_VIEW_TARGET"


@dataclass(frozen=True)
class UnitContext:
    unit_kind: PreparedUnitKind
    subject_family: Optional[str]
    subject_sequence: int


@dataclass(frozen=True)
class RegistryDefinitionIndex:
    registry_file_sha256: str
    schema_ids: Tuple[str, ...]
    json_schema_count: int
    table_schema_count: int
    total_schema_count: int
    schema_ids_logical_sha256: str


@dataclass(frozen=True)
class RegistryDefinitionIndexResult:
    code: I0AResultCode
    established_assurances: Tuple[AssuranceLevel, ...]
    index: Optional[RegistryDefinitionIndex]


@dataclass(frozen=True)
class BindingQuery:
    role: PreparedObjectRole
    unit_kind: PreparedUnitKind
    publication_mode: PublicationMode
    canonical_target_path: str
    content_schema_id: str
    logical_sha256_is_null: bool
    sidecar_of_object_ordinal_is_null: bool
    paired_target_role: Optional[PreparedObjectRole]
    paired_target_content_schema_id: Optional[str]
    paired_target_canonical_target_path: Optional[str]


@dataclass(frozen=True)
class SchemaBinding:
    binding_id: str
    role: PreparedObjectRole
    unit_kind: PreparedUnitKind
    publication_mode: PublicationMode
    target_grammar_id: FrozenPathGrammarId
    content_schema_id: str
    logical_sha256_nullability: str
    sidecar_rule: str


@dataclass(frozen=True)
class BindingResolutionResult:
    code: I0AResultCode
    established_assurances: Tuple[AssuranceLevel, ...]
    binding: Optional[SchemaBinding]


# ---------------------------------------------------------------------------
# Private symbols (absent from __all__)
# ---------------------------------------------------------------------------


class _PrivateBindingMatchCode(Enum):
    PRIVATE_BINDING_MATCH_EXACTLY_ONE = "PRIVATE_BINDING_MATCH_EXACTLY_ONE"
    PRIVATE_BINDING_MATCH_ZERO = "PRIVATE_BINDING_MATCH_ZERO"
    PRIVATE_BINDING_MATCH_MULTIPLE = "PRIVATE_BINDING_MATCH_MULTIPLE"
    PRIVATE_BINDING_MATCH_INPUT_INVALID = "PRIVATE_BINDING_MATCH_INPUT_INVALID"


@dataclass(frozen=True)
class _PrivateBindingMatchResult:
    code: _PrivateBindingMatchCode
    matching_bindings: Tuple[SchemaBinding, ...]


@dataclass(frozen=True)
class _BindingSetResolutionInput:
    query: BindingQuery
    candidate_bindings: Tuple[SchemaBinding, ...]


class _DuplicateJsonKeyError(Exception):
    def __init__(self, duplicate_key: str) -> None:
        super().__init__(duplicate_key)
        self.duplicate_key = duplicate_key


def _reject_duplicate_json_object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateJsonKeyError(key)
        result[key] = value
    return result


def _reject_json_non_integer_number(token: str):
    raise ValueError("non-integer JSON number rejected: " + token)


def _reject_json_constant(token: str):
    raise ValueError("non-standard JSON constant rejected: " + token)


def _parse_accepted_registry_bytes(registry_bytes: bytes):
    text = registry_bytes.decode("utf-8", "strict")
    value = json.loads(
        text,
        object_pairs_hook=_reject_duplicate_json_object_pairs,
        parse_float=_reject_json_non_integer_number,
        parse_constant=_reject_json_constant,
    )
    reserialized = json.dumps(
        value, ensure_ascii=False, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    if reserialized != registry_bytes:
        raise ValueError("non-canonical registry bytes")
    return value


def _resolve_compatible_binding_set(
    value: _BindingSetResolutionInput,
) -> _PrivateBindingMatchResult:
    q = value.query
    if not isinstance(q.role, PreparedObjectRole) or not isinstance(
        q.unit_kind, PreparedUnitKind
    ):
        return _PrivateBindingMatchResult(
            code=_PrivateBindingMatchCode.PRIVATE_BINDING_MATCH_INPUT_INVALID,
            matching_bindings=(),
        )
    paired_fields = (
        q.paired_target_role,
        q.paired_target_content_schema_id,
        q.paired_target_canonical_target_path,
    )
    if q.sidecar_of_object_ordinal_is_null:
        if any(f is not None for f in paired_fields):
            return _PrivateBindingMatchResult(
                code=_PrivateBindingMatchCode.PRIVATE_BINDING_MATCH_INPUT_INVALID,
                matching_bindings=(),
            )
    else:
        if any(f is None for f in paired_fields):
            return _PrivateBindingMatchResult(
                code=_PrivateBindingMatchCode.PRIVATE_BINDING_MATCH_INPUT_INVALID,
                matching_bindings=(),
            )

    matches = tuple(
        candidate
        for candidate in value.candidate_bindings
        if candidate.role == q.role
        and candidate.unit_kind == q.unit_kind
        and candidate.publication_mode == q.publication_mode
        and candidate.content_schema_id == q.content_schema_id
    )
    if len(matches) == 0:
        return _PrivateBindingMatchResult(
            code=_PrivateBindingMatchCode.PRIVATE_BINDING_MATCH_ZERO,
            matching_bindings=(),
        )
    if len(matches) > 1:
        return _PrivateBindingMatchResult(
            code=_PrivateBindingMatchCode.PRIVATE_BINDING_MATCH_MULTIPLE,
            matching_bindings=matches,
        )
    return _PrivateBindingMatchResult(
        code=_PrivateBindingMatchCode.PRIVATE_BINDING_MATCH_EXACTLY_ONE,
        matching_bindings=matches,
    )


# Exact frozen target/prepared-unit grammars: grammar_id -> (template, placeholder_domains)
# Materialized from the accepted PATH_GRAMMAR_REGISTRY.json / PREPARED_ROLE_MATRIX.json
# contract as recorded in I0A_ROLE_CONTENT_SCHEMA_DISPOSITION_MATRIX.json. 43 entries.
_FROZEN_TARGET_GRAMMARS = {
    FrozenPathGrammarId.PREPARED_CLAIM_SCOPE_JSON: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/CLAIM_SCOPE.json', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.PREPARED_CLAIM_SCOPE_SHA256: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/CLAIM_SCOPE.sha256', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.PREPARED_CLAIM_SEMANTIC_JSON: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/CLAIM_SEMANTIC.json', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.PREPARED_CLAIM_SEMANTIC_SHA256: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/CLAIM_SEMANTIC.sha256', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.PREPARED_OBJECT_BIN: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/objects/<object_ordinal_10d>.bin', ('run_id', 'unit_kind', 'prepared_unit_id', 'object_ordinal_10d')),
    FrozenPathGrammarId.PREPARED_PREPARATION_PLAN_JSON: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/PREPARATION_PLAN.json', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.PREPARED_PREPARATION_PLAN_SHA256: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/PREPARATION_PLAN.sha256', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.PREPARED_PREPARED_UNIT_JSON: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/PREPARED_UNIT.json', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.PREPARED_PREPARED_UNIT_SHA256: ('artifacts/local_curl_per_side/runs/<run_id>/prepared_evidence/<unit_kind>/<prepared_unit_id>/PREPARED_UNIT.sha256', ('run_id', 'unit_kind', 'prepared_unit_id')),
    FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/rows/authorization_use_events.parquet', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/rows/authorization_use_events.sha256', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_BOUND_PAYLOAD_INTENT_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/bound_payload_intent.json', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_BOUND_PAYLOAD_INTENT_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/bound_payload_intent.sha256', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/bound_snapshot_claim_semantic.json', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/bound_snapshot_claim_semantic.sha256', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_CAPTURE_ROW_BATCH_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/rows/capture_events.parquet', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_CAPTURE_ROW_BATCH_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/rows/capture_events.sha256', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_CURRENT_GENERATION_INDEX_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/current_view_generations/<snapshot_sequence_20d>/snapshot_partitions.parquet', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MANIFEST_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/current_view_generations/<snapshot_sequence_20d>/audit_snapshot_manifest.json', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MANIFEST_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/current_view_generations/<snapshot_sequence_20d>/audit_snapshot_manifest.sha256', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MARKER_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/current_view_generations/<snapshot_sequence_20d>/CURRENT_VIEW_COMMITTED.json', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MARKER_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/current_view_generations/<snapshot_sequence_20d>/CURRENT_VIEW_COMMITTED.sha256', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_FENCE_EVENT_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/fence_event.json', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/fence_event.sha256', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/FENCE_UNIT.json', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/capture/commit_fence_history/<fence_sequence_20d>/FENCE_UNIT.sha256', ('run_id', 'fence_sequence_20d')),
    FrozenPathGrammarId.TARGET_HISTORY_INDEX_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/audit_snapshot_history/<snapshot_sequence_20d>/snapshot_partitions.parquet', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_HISTORY_MANIFEST_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/audit_snapshot_history/<snapshot_sequence_20d>/audit_snapshot_manifest.json', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_HISTORY_MANIFEST_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/audit_snapshot_history/<snapshot_sequence_20d>/audit_snapshot_manifest.sha256', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_LEGACY_CURRENT_INDEX_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/snapshot_partitions.parquet', ('run_id', 'family_root')),
    FrozenPathGrammarId.TARGET_LEGACY_CURRENT_MANIFEST_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/audit_snapshot_manifest.json', ('run_id', 'family_root')),
    FrozenPathGrammarId.TARGET_LEGACY_CURRENT_MANIFEST_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/audit_snapshot_manifest.sha256', ('run_id', 'family_root')),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_00: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/final_artifact_inventory.json', ('run_id',)),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_01: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/stop_artifact_inventory.json', ('run_id',)),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/final_artifact_inventory.sha256', ('run_id',)),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_01: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/stop_artifact_inventory.sha256', ('run_id',)),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_00: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/REPLAY_FINALIZED.json', ('run_id',)),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_01: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/STOP_FINALIZED.json', ('run_id',)),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/REPLAY_FINALIZED.sha256', ('run_id',)),
    FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_SIDECAR_01: ('artifacts/local_curl_per_side/runs/<run_id>/finalization/STOP_FINALIZED.sha256', ('run_id',)),
    FrozenPathGrammarId.TARGET_PARTITION_PAYLOAD_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/partitions/<partition_id>.parquet', ('run_id', 'family_root', 'partition_id')),
    FrozenPathGrammarId.TARGET_PUBLICATION_MARKER_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/audit_snapshot_history/<snapshot_sequence_20d>/PUBLICATION_COMMITTED.json', ('run_id', 'family_root', 'snapshot_sequence_20d')),
    FrozenPathGrammarId.TARGET_PUBLICATION_MARKER_SIDECAR_00: ('artifacts/local_curl_per_side/runs/<run_id>/<family_root>/audit_snapshot_history/<snapshot_sequence_20d>/PUBLICATION_COMMITTED.sha256', ('run_id', 'family_root', 'snapshot_sequence_20d')),
}

# Exact frozen production binding table. 79 immutable rows generated from the
# accepted role/path/schema contract in this scope package; no runtime
# registration, injection, or reverse import.
_FROZEN_PRODUCTION_BINDINGS: Tuple[SchemaBinding, ...] = (
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_AUTHORIZATION_USE_EVENT_COMMITTED_ATOMIC_BUNDLE_MEMBER_66044DE9D271', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH, unit_kind=PreparedUnitKind.AUTHORIZATION_USE_EVENT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_00, content_schema_id='table:authorization_use_events', logical_sha256_nullability='NON_NULL_WHEN_PRESENT', sidecar_rule='EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_IFF_PRESENT'),
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED_ATOMIC_BUNDLE_MEMBER_7C944EBB1C6F', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH, unit_kind=PreparedUnitKind.CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_00, content_schema_id='table:authorization_use_events', logical_sha256_nullability='NON_NULL_WHEN_PRESENT', sidecar_rule='EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_IFF_PRESENT'),
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED_ATOMIC_BUNDLE_MEMBER_B423FA9E771D', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH, unit_kind=PreparedUnitKind.CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_00, content_schema_id='table:authorization_use_events', logical_sha256_nullability='NON_NULL_WHEN_PRESENT', sidecar_rule='EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_IFF_PRESENT'),
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_REQUEST_RESERVED_COMMITTED_ATOMIC_BUNDLE_MEMBER_3F66CD2FF8CD', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH, unit_kind=PreparedUnitKind.REQUEST_RESERVED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_00, content_schema_id='table:authorization_use_events', logical_sha256_nullability='NON_NULL_WHEN_PRESENT', sidecar_rule='EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_IFF_PRESENT'),
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_AUTHORIZATION_USE_EVENT_COMMITTED_ATOMIC_BUNDLE_MEMBER_9993F6A31407', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH_SIDECAR, unit_kind=PreparedUnitKind.AUTHORIZATION_USE_EVENT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_ORDINAL'),
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED_ATOMIC_BUNDLE_MEMBER_9F92E8409D45', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH_SIDECAR, unit_kind=PreparedUnitKind.CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_ORDINAL'),
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED_ATOMIC_BUNDLE_MEMBER_A62FF1C4783E', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH_SIDECAR, unit_kind=PreparedUnitKind.CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_ORDINAL'),
    SchemaBinding(binding_id='BINDING_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_REQUEST_RESERVED_COMMITTED_ATOMIC_BUNDLE_MEMBER_A749EFA8B3A1', role=PreparedObjectRole.AUTHORIZATION_USE_ROW_BATCH_SIDECAR, unit_kind=PreparedUnitKind.REQUEST_RESERVED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_AUTHORIZATION_USE_ROW_BATCH_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_AUTHORIZATION_USE_ROW_BATCH_ORDINAL'),
    SchemaBinding(binding_id='BINDING_BOUND_PAYLOAD_INTENT_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_5120A88260E3', role=PreparedObjectRole.BOUND_PAYLOAD_INTENT, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_BOUND_PAYLOAD_INTENT_00, content_schema_id='json:capture_payload_intent_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_BOUND_PAYLOAD_INTENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_BOUND_PAYLOAD_INTENT_SIDECAR_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_B7B23A20BDA8', role=PreparedObjectRole.BOUND_PAYLOAD_INTENT_SIDECAR, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_BOUND_PAYLOAD_INTENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_BOUND_PAYLOAD_INTENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_BOUND_SNAPSHOT_CLAIM_SEMANTIC_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_6CCC301FC56D', role=PreparedObjectRole.BOUND_SNAPSHOT_CLAIM_SEMANTIC, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_00, content_schema_id='json:snapshot_publication_claim_semantic_v23', logical_sha256_nullability='NON_NULL_WHEN_PRESENT', sidecar_rule='EXACTLY_ONE_BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR_IFF_PRESENT'),
    SchemaBinding(binding_id='BINDING_BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_BE05D238F7A6', role=PreparedObjectRole.BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_BOUND_SNAPSHOT_CLAIM_SEMANTIC_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_BOUND_SNAPSHOT_CLAIM_SEMANTIC_ORDINAL'),
    SchemaBinding(binding_id='BINDING_CAPTURE_ROW_BATCH_CAPTURE_STARTED_COMMITTED_ATOMIC_BUNDLE_MEMBER_33CD925701BB', role=PreparedObjectRole.CAPTURE_ROW_BATCH, unit_kind=PreparedUnitKind.CAPTURE_STARTED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CAPTURE_ROW_BATCH_00, content_schema_id='table:capture_events', logical_sha256_nullability='NON_NULL_WHEN_PRESENT', sidecar_rule='EXACTLY_ONE_CAPTURE_ROW_BATCH_SIDECAR_IFF_PRESENT'),
    SchemaBinding(binding_id='BINDING_CAPTURE_ROW_BATCH_CAPTURE_TERMINAL_COMMITTED_ATOMIC_BUNDLE_MEMBER_75771354BD63', role=PreparedObjectRole.CAPTURE_ROW_BATCH, unit_kind=PreparedUnitKind.CAPTURE_TERMINAL_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CAPTURE_ROW_BATCH_00, content_schema_id='table:capture_events', logical_sha256_nullability='NON_NULL_WHEN_PRESENT', sidecar_rule='EXACTLY_ONE_CAPTURE_ROW_BATCH_SIDECAR_IFF_PRESENT'),
    SchemaBinding(binding_id='BINDING_CAPTURE_ROW_BATCH_SIDECAR_CAPTURE_STARTED_COMMITTED_ATOMIC_BUNDLE_MEMBER_1220611A77D5', role=PreparedObjectRole.CAPTURE_ROW_BATCH_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_STARTED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CAPTURE_ROW_BATCH_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_CAPTURE_ROW_BATCH_ORDINAL'),
    SchemaBinding(binding_id='BINDING_CAPTURE_ROW_BATCH_SIDECAR_CAPTURE_TERMINAL_COMMITTED_ATOMIC_BUNDLE_MEMBER_4926D847C130', role=PreparedObjectRole.CAPTURE_ROW_BATCH_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_TERMINAL_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CAPTURE_ROW_BATCH_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_CAPTURE_ROW_BATCH_ORDINAL'),
    SchemaBinding(binding_id='BINDING_CURRENT_GENERATION_INDEX_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_B63F690AC092', role=PreparedObjectRole.CURRENT_GENERATION_INDEX, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CURRENT_GENERATION_INDEX_00, content_schema_id='table:snapshot_partition', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_CURRENT_GENERATION_MANIFEST_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_B6A16DC646EF', role=PreparedObjectRole.CURRENT_GENERATION_MANIFEST, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MANIFEST_00, content_schema_id='json:audit_snapshot_manifest', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_CURRENT_GENERATION_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_CURRENT_GENERATION_MANIFEST_SIDECAR_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_54AACF951B03', role=PreparedObjectRole.CURRENT_GENERATION_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_CURRENT_GENERATION_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_CURRENT_GENERATION_MARKER_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_2CA192270524', role=PreparedObjectRole.CURRENT_GENERATION_MARKER, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MARKER_00, content_schema_id='json:snapshot_current_view_commit_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_CURRENT_GENERATION_MARKER_SIDECAR'),
    SchemaBinding(binding_id='BINDING_CURRENT_GENERATION_MARKER_SIDECAR_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_C5525C913847', role=PreparedObjectRole.CURRENT_GENERATION_MARKER_SIDECAR, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_CURRENT_GENERATION_MARKER_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_CURRENT_GENERATION_MARKER_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_AUTHORIZATION_USE_EVENT_COMMITTED_ATOMIC_BUNDLE_MEMBER_6B5B853E2CEA', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.AUTHORIZATION_USE_EVENT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED_ATOMIC_BUNDLE_MEMBER_9496756BE658', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_CAPTURE_SNAPSHOT_COMMITTED_ATOMIC_BUNDLE_MEMBER_5BF92C13216F', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.CAPTURE_SNAPSHOT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_CAPTURE_STARTED_COMMITTED_ATOMIC_BUNDLE_MEMBER_1D314434C28B', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.CAPTURE_STARTED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_CAPTURE_TERMINAL_COMMITTED_ATOMIC_BUNDLE_MEMBER_FD774B6ACA0E', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.CAPTURE_TERMINAL_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED_ATOMIC_BUNDLE_MEMBER_440EB71EB8B7', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_496BA9556D21', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_FENCE_RELEASED_ATOMIC_BUNDLE_MEMBER_A89A4D840A44', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.FENCE_RELEASED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_REQUEST_RESERVED_COMMITTED_ATOMIC_BUNDLE_MEMBER_69DC34C15B7D', role=PreparedObjectRole.FENCE_EVENT, unit_kind=PreparedUnitKind.REQUEST_RESERVED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_00, content_schema_id='json:fence_event_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_EVENT_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_AUTHORIZATION_USE_EVENT_COMMITTED_ATOMIC_BUNDLE_MEMBER_55428E95FCBF', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.AUTHORIZATION_USE_EVENT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED_ATOMIC_BUNDLE_MEMBER_9A5D4F63CDFD', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_CAPTURE_SNAPSHOT_COMMITTED_ATOMIC_BUNDLE_MEMBER_BEC064C4022C', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_SNAPSHOT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_CAPTURE_STARTED_COMMITTED_ATOMIC_BUNDLE_MEMBER_ACC81A33B18C', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_STARTED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_CAPTURE_TERMINAL_COMMITTED_ATOMIC_BUNDLE_MEMBER_2049DF7B85F7', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_TERMINAL_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED_ATOMIC_BUNDLE_MEMBER_6716E8BC0A42', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_46651336CCA6', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_FENCE_RELEASED_ATOMIC_BUNDLE_MEMBER_BB1DEE2ED098', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.FENCE_RELEASED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_EVENT_SIDECAR_REQUEST_RESERVED_COMMITTED_ATOMIC_BUNDLE_MEMBER_914E48CD1888', role=PreparedObjectRole.FENCE_EVENT_SIDECAR, unit_kind=PreparedUnitKind.REQUEST_RESERVED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_EVENT_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_EVENT_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_AUTHORIZATION_USE_EVENT_COMMITTED_ATOMIC_BUNDLE_MEMBER_85939247A8EF', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.AUTHORIZATION_USE_EVENT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED_ATOMIC_BUNDLE_MEMBER_60C99612F823', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_CAPTURE_SNAPSHOT_COMMITTED_ATOMIC_BUNDLE_MEMBER_4E0BD0433BC7', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.CAPTURE_SNAPSHOT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_CAPTURE_STARTED_COMMITTED_ATOMIC_BUNDLE_MEMBER_C74127053B80', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.CAPTURE_STARTED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_CAPTURE_TERMINAL_COMMITTED_ATOMIC_BUNDLE_MEMBER_26BB66B6A210', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.CAPTURE_TERMINAL_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED_ATOMIC_BUNDLE_MEMBER_88F47006983B', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_FA313973876B', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_FENCE_RELEASED_ATOMIC_BUNDLE_MEMBER_C195FE83C2AA', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.FENCE_RELEASED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_REQUEST_RESERVED_COMMITTED_ATOMIC_BUNDLE_MEMBER_9E282AE48370', role=PreparedObjectRole.FENCE_UNIT_MANIFEST, unit_kind=PreparedUnitKind.REQUEST_RESERVED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_00, content_schema_id='json:fence_unit_manifest_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_FENCE_UNIT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_AUTHORIZATION_USE_EVENT_COMMITTED_ATOMIC_BUNDLE_MEMBER_0E83A3C584E1', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.AUTHORIZATION_USE_EVENT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED_ATOMIC_BUNDLE_MEMBER_86736C866FFD', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.CANCELLATION_CHECKPOINT_AND_ROW_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_CAPTURE_SNAPSHOT_COMMITTED_ATOMIC_BUNDLE_MEMBER_E2D36F155F2F', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_SNAPSHOT_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_CAPTURE_STARTED_COMMITTED_ATOMIC_BUNDLE_MEMBER_B092F739E193', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_STARTED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_CAPTURE_TERMINAL_COMMITTED_ATOMIC_BUNDLE_MEMBER_D13DEA7BAA84', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.CAPTURE_TERMINAL_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED_ATOMIC_BUNDLE_MEMBER_182CC9E07754', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.CONTINUATION_CHECKPOINT_AND_ACTIVATION_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_FENCE_ACQUIRED_ATOMIC_BUNDLE_MEMBER_B03A1EA57EAA', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.FENCE_ACQUIRED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_FENCE_RELEASED_ATOMIC_BUNDLE_MEMBER_E843D66880FE', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.FENCE_RELEASED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_FENCE_UNIT_MANIFEST_SIDECAR_REQUEST_RESERVED_COMMITTED_ATOMIC_BUNDLE_MEMBER_1B06771086F7', role=PreparedObjectRole.FENCE_UNIT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.REQUEST_RESERVED_COMMITTED, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_FENCE_UNIT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_FENCE_UNIT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_HISTORY_INDEX_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_8F8230BE3214', role=PreparedObjectRole.HISTORY_INDEX, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_HISTORY_INDEX_00, content_schema_id='table:snapshot_partition', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_HISTORY_MANIFEST_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_AD3799C09C37', role=PreparedObjectRole.HISTORY_MANIFEST, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_HISTORY_MANIFEST_00, content_schema_id='json:audit_snapshot_manifest', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_HISTORY_MANIFEST_SIDECAR_IN_SAME_UNIT'),
    SchemaBinding(binding_id='BINDING_HISTORY_MANIFEST_SIDECAR_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_BE12A8D2204A', role=PreparedObjectRole.HISTORY_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_HISTORY_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_HISTORY_MANIFEST_ORDINAL_IN_SAME_UNIT'),
    SchemaBinding(binding_id='BINDING_LEGACY_CURRENT_INDEX_SNAPSHOT_PUBLICATION_DERIVED_VIEW_TARGET_2C133E2B157A', role=PreparedObjectRole.LEGACY_CURRENT_INDEX, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.DERIVED_VIEW_TARGET, target_grammar_id=FrozenPathGrammarId.TARGET_LEGACY_CURRENT_INDEX_00, content_schema_id='table:snapshot_partition', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_LEGACY_CURRENT_MANIFEST_SNAPSHOT_PUBLICATION_DERIVED_VIEW_TARGET_B22960D32DD2', role=PreparedObjectRole.LEGACY_CURRENT_MANIFEST, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.DERIVED_VIEW_TARGET, target_grammar_id=FrozenPathGrammarId.TARGET_LEGACY_CURRENT_MANIFEST_00, content_schema_id='json:audit_snapshot_manifest', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_LEGACY_CURRENT_MANIFEST_SIDECAR'),
    SchemaBinding(binding_id='BINDING_LEGACY_CURRENT_MANIFEST_SIDECAR_SNAPSHOT_PUBLICATION_DERIVED_VIEW_TARGET_364C9029C9F1', role=PreparedObjectRole.LEGACY_CURRENT_MANIFEST_SIDECAR, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.DERIVED_VIEW_TARGET, target_grammar_id=FrozenPathGrammarId.TARGET_LEGACY_CURRENT_MANIFEST_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_LEGACY_CURRENT_MANIFEST_ORDINAL'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_INVENTORY_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_A6B996733CBD', role=PreparedObjectRole.NORMAL_FINAL_INVENTORY, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_00, content_schema_id='json:final_artifact_inventory', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_NORMAL_FINAL_INVENTORY_SIDECAR'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_INVENTORY_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_37268682CB33', role=PreparedObjectRole.NORMAL_FINAL_INVENTORY, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_01, content_schema_id='json:stop_artifact_inventory', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_NORMAL_FINAL_INVENTORY_SIDECAR'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_INVENTORY_SIDECAR_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_8F47EF3312A9', role=PreparedObjectRole.NORMAL_FINAL_INVENTORY_SIDECAR, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_NORMAL_FINAL_INVENTORY_ORDINAL'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_INVENTORY_SIDECAR_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_595FACE66AA9', role=PreparedObjectRole.NORMAL_FINAL_INVENTORY_SIDECAR, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_INVENTORY_SIDECAR_01, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_NORMAL_FINAL_INVENTORY_ORDINAL'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_MARKER_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_DA8169FC7783', role=PreparedObjectRole.NORMAL_FINAL_MARKER, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_00, content_schema_id='json:finalization_marker_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_NORMAL_FINAL_MARKER_SIDECAR'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_MARKER_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_AD75320BD2A9', role=PreparedObjectRole.NORMAL_FINAL_MARKER, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_01, content_schema_id='json:finalization_marker_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='EXACTLY_ONE_NORMAL_FINAL_MARKER_SIDECAR'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_MARKER_SIDECAR_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_ACDCE34023A3', role=PreparedObjectRole.NORMAL_FINAL_MARKER_SIDECAR, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_NORMAL_FINAL_MARKER_ORDINAL'),
    SchemaBinding(binding_id='BINDING_NORMAL_FINAL_MARKER_SIDECAR_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_E0311F925D02', role=PreparedObjectRole.NORMAL_FINAL_MARKER_SIDECAR, unit_kind=PreparedUnitKind.NORMAL_FINALIZATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_SIDECAR_01, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_NORMAL_FINAL_MARKER_ORDINAL'),
    SchemaBinding(binding_id='BINDING_PARTITION_PAYLOAD_SNAPSHOT_PUBLICATION_REUSE_IMMUTABLE_SOURCE_A73AD56484B6', role=PreparedObjectRole.PARTITION_PAYLOAD, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.REUSE_IMMUTABLE_SOURCE, target_grammar_id=FrozenPathGrammarId.TARGET_PARTITION_PAYLOAD_00, content_schema_id='table:canonical_compatibility_analysis', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_PARTITION_PAYLOAD_SNAPSHOT_PUBLICATION_REUSE_IMMUTABLE_SOURCE_30CD326A81AD', role=PreparedObjectRole.PARTITION_PAYLOAD, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.REUSE_IMMUTABLE_SOURCE, target_grammar_id=FrozenPathGrammarId.TARGET_PARTITION_PAYLOAD_00, content_schema_id='table:capture_events', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_PARTITION_PAYLOAD_SNAPSHOT_PUBLICATION_REUSE_IMMUTABLE_SOURCE_62B9FB259ABE', role=PreparedObjectRole.PARTITION_PAYLOAD, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.REUSE_IMMUTABLE_SOURCE, target_grammar_id=FrozenPathGrammarId.TARGET_PARTITION_PAYLOAD_00, content_schema_id='table:strict_audit_analysis', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_PARTITION_PAYLOAD_SNAPSHOT_PUBLICATION_SINGLE_AUTHORITATIVE_FILE_FA5B89416A4F', role=PreparedObjectRole.PARTITION_PAYLOAD, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_PARTITION_PAYLOAD_00, content_schema_id='table:canonical_compatibility_analysis', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_PARTITION_PAYLOAD_SNAPSHOT_PUBLICATION_SINGLE_AUTHORITATIVE_FILE_544EF4C313B7', role=PreparedObjectRole.PARTITION_PAYLOAD, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_PARTITION_PAYLOAD_00, content_schema_id='table:capture_events', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_PARTITION_PAYLOAD_SNAPSHOT_PUBLICATION_SINGLE_AUTHORITATIVE_FILE_4A052BF4E0AB', role=PreparedObjectRole.PARTITION_PAYLOAD, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.SINGLE_AUTHORITATIVE_FILE, target_grammar_id=FrozenPathGrammarId.TARGET_PARTITION_PAYLOAD_00, content_schema_id='table:strict_audit_analysis', logical_sha256_nullability='NON_NULL', sidecar_rule='NO_SIDECAR_DESCRIPTOR'),
    SchemaBinding(binding_id='BINDING_PUBLICATION_MARKER_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_00', role=PreparedObjectRole.PUBLICATION_MARKER, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_PUBLICATION_MARKER_00, content_schema_id='json:snapshot_publication_commit_v23', logical_sha256_nullability='NON_NULL', sidecar_rule='REQUIRES_EXACTLY_ONE_PUBLICATION_MARKER_SIDECAR'),
    SchemaBinding(binding_id='BINDING_PUBLICATION_MARKER_SIDECAR_SNAPSHOT_PUBLICATION_ATOMIC_BUNDLE_MEMBER_14622BB549F9', role=PreparedObjectRole.PUBLICATION_MARKER_SIDECAR, unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION, publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER, target_grammar_id=FrozenPathGrammarId.TARGET_PUBLICATION_MARKER_SIDECAR_00, content_schema_id='json:sha256_sidecar', logical_sha256_nullability='NULL_REQUIRED', sidecar_rule='SIDECAR_OF_EXACTLY_ONE_PUBLICATION_MARKER'),
)

_PLACEHOLDER_REGEX = {
    "fence_sequence_20d": re.compile(r"^[0-9]{20}$"),
    "object_ordinal_10d": re.compile(r"^[0-9]{10}$"),
    "partition_id": re.compile(r"^part_[0-9a-f]{64}$"),
    "prepared_unit_id": re.compile(r"^prep_[0-9a-f]{64}$"),
    "run_id": re.compile(r"^run_[0-9a-f]{64}$"),
    "snapshot_sequence_20d": re.compile(r"^[0-9]{20}$"),
}

_FAMILY_ROOT_DOMAIN = ("capture", "analysis_compatibility", "analysis_strict")

_UNIT_KIND_DOMAIN = tuple(k.value for k in PreparedUnitKind)


def _grammar_regex(template, placeholder_domains):
    # Build an exact matching regex from the immutable template by
    # substituting each <placeholder> with its lexical-domain pattern,
    # in declared placeholder order.
    pattern = re.escape(template)
    for name in placeholder_domains:
        escaped_token = re.escape("<" + name + ">")
        if name == "family_root":
            group = "(?:capture|analysis/compatibility|strict)"
        elif name == "unit_kind":
            group = "(?:" + "|".join(re.escape(v) for v in _UNIT_KIND_DOMAIN) + ")"
        elif name in ("fence_sequence_20d", "snapshot_sequence_20d"):
            group = "[0-9]{20}"
        elif name == "object_ordinal_10d":
            group = "[0-9]{10}"
        elif name == "partition_id":
            group = "part_[0-9a-f]{64}"
        elif name == "prepared_unit_id":
            group = "prep_[0-9a-f]{64}"
        elif name == "run_id":
            group = "run_[0-9a-f]{64}"
        else:
            group = ".*"
        pattern = pattern.replace(escaped_token, group)
    return re.compile("^" + pattern + "$")


def validate_normalized_relative_path(path, grammar_id):
    """Resolve FrozenPathGrammarId only against immutable module-owned
    target/prepared-unit grammar tables and exact placeholder domains;
    lexical validation only; no filesystem facts and no caller-supplied
    template."""
    if not isinstance(path, str) or len(path) == 0:
        return ValidationResult(
            code=I0AResultCode.ERR_PATH_LEXICAL_INVALID,
            established_assurances=(),
        )
    if "\\" in path or path.startswith("/") or ".." in path.split("/"):
        return ValidationResult(
            code=I0AResultCode.ERR_PATH_LEXICAL_INVALID,
            established_assurances=(),
        )
    entry = _FROZEN_TARGET_GRAMMARS.get(grammar_id)
    if entry is None:
        return ValidationResult(
            code=I0AResultCode.ERR_PATH_LEXICAL_INVALID,
            established_assurances=(),
        )
    template, placeholder_domains = entry
    pattern = _grammar_regex(template, placeholder_domains)
    if pattern.match(path) is None:
        return ValidationResult(
            code=I0AResultCode.ERR_PATH_GRAMMAR_MISMATCH,
            established_assurances=(),
        )
    return ValidationResult(
        code=I0AResultCode.I0A_VALID_A1_PATH,
        established_assurances=(AssuranceLevel.A1_LEXICAL_PATH_SHAPE,),
    )


_PINNED_SCHEMA_REGISTRY_SHA256 = (
    "c9e8fe1b2c64f64e9cefd76e820c9589708723485ff7e54f4f69e3fe4ed49689"
)


def build_accepted_registry_schema_definition_index(registry_bytes):
    """Hash-first fixed-byte API. Requires exact accepted registry SHA-256,
    then strictly parses and canonically re-serializes for byte equality,
    then enumerates the complete accepted json_schemas/table_schemas
    definition domains."""
    import hashlib

    observed_sha256 = hashlib.sha256(registry_bytes).hexdigest()
    if observed_sha256 != _PINNED_SCHEMA_REGISTRY_SHA256:
        return RegistryDefinitionIndexResult(
            code=I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH,
            established_assurances=(),
            index=None,
        )
    try:
        parsed = _parse_accepted_registry_bytes(registry_bytes)
    except (_DuplicateJsonKeyError, ValueError, UnicodeDecodeError):
        return RegistryDefinitionIndexResult(
            code=I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH,
            established_assurances=(),
            index=None,
        )

    json_schemas = parsed.get("json_schemas", {}) if isinstance(parsed, dict) else {}
    table_schemas = parsed.get("table_schemas", {}) if isinstance(parsed, dict) else {}
    if not isinstance(json_schemas, dict) or not isinstance(table_schemas, dict):
        return RegistryDefinitionIndexResult(
            code=I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH,
            established_assurances=(),
            index=None,
        )

    schema_ids = sorted(
        ["json:" + k for k in json_schemas.keys()]
        + ["table:" + k for k in table_schemas.keys()],
        key=lambda s: s.encode("utf-8"),
    )
    if len(set(schema_ids)) != len(schema_ids):
        return RegistryDefinitionIndexResult(
            code=I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH,
            established_assurances=(),
            index=None,
        )

    joined = "\n".join(schema_ids).encode("utf-8") if schema_ids else b""
    logical_sha256 = hashlib.sha256(joined).hexdigest()

    index = RegistryDefinitionIndex(
        registry_file_sha256=observed_sha256,
        schema_ids=tuple(schema_ids),
        json_schema_count=len(json_schemas),
        table_schema_count=len(table_schemas),
        total_schema_count=len(schema_ids),
        schema_ids_logical_sha256=logical_sha256,
    )
    return RegistryDefinitionIndexResult(
        code=I0AResultCode.I0A_REGISTRY_INDEX_MATERIALIZED_A3H,
        established_assurances=(AssuranceLevel.A3_PINNED_GOVERNING_SHA256_VALIDATED,),
        index=index,
    )


def resolve_selected_schema_binding(query, accepted_registry_bytes):
    """Gate unit_kind first, then validate pinned accepted-registry bytes,
    the complete BindingQuery, immutable grammar, accepted-registry
    membership, and exactly one compatible frozen binding."""
    if query.unit_kind != PreparedUnitKind.SNAPSHOT_PUBLICATION:
        return BindingResolutionResult(
            code=I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A,
            established_assurances=(),
            binding=None,
        )

    registry_result = build_accepted_registry_schema_definition_index(
        accepted_registry_bytes
    )
    if registry_result.code != I0AResultCode.I0A_REGISTRY_INDEX_MATERIALIZED_A3H:
        return BindingResolutionResult(
            code=I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH,
            established_assurances=(),
            binding=None,
        )

    if not isinstance(query, BindingQuery) or not isinstance(
        query.content_schema_id, str
    ):
        return BindingResolutionResult(
            code=I0AResultCode.ERR_BINDING_QUERY_INVALID,
            established_assurances=(),
            binding=None,
        )
    if query.content_schema_id.startswith("i0a:"):
        return BindingResolutionResult(
            code=I0AResultCode.ERR_BINDING_QUERY_INVALID,
            established_assurances=(),
            binding=None,
        )
    paired_fields = (
        query.paired_target_role,
        query.paired_target_content_schema_id,
        query.paired_target_canonical_target_path,
    )
    if query.sidecar_of_object_ordinal_is_null:
        if any(f is not None for f in paired_fields):
            return BindingResolutionResult(
                code=I0AResultCode.ERR_BINDING_QUERY_INVALID,
                established_assurances=(),
                binding=None,
            )
    else:
        if any(f is None for f in paired_fields):
            return BindingResolutionResult(
                code=I0AResultCode.ERR_BINDING_QUERY_INVALID,
                established_assurances=(),
                binding=None,
            )

    candidate_bindings_for_role = tuple(
        b for b in _FROZEN_PRODUCTION_BINDINGS if b.role == query.role
    )
    if not candidate_bindings_for_role:
        return BindingResolutionResult(
            code=I0AResultCode.ERR_BINDING_QUERY_INVALID,
            established_assurances=(),
            binding=None,
        )
    lexical_result = validate_normalized_relative_path(
        query.canonical_target_path, candidate_bindings_for_role[0].target_grammar_id
    )
    matches_any_grammar = False
    for candidate in candidate_bindings_for_role:
        r = validate_normalized_relative_path(
            query.canonical_target_path, candidate.target_grammar_id
        )
        if r.code == I0AResultCode.I0A_VALID_A1_PATH:
            matches_any_grammar = True
            break
    if not matches_any_grammar:
        if lexical_result.code == I0AResultCode.ERR_PATH_LEXICAL_INVALID:
            return BindingResolutionResult(
                code=I0AResultCode.ERR_PATH_LEXICAL_INVALID,
                established_assurances=(),
                binding=None,
            )
        return BindingResolutionResult(
            code=I0AResultCode.ERR_PATH_GRAMMAR_MISMATCH,
            established_assurances=(),
            binding=None,
        )

    if query.content_schema_id not in registry_result.index.schema_ids:
        return BindingResolutionResult(
            code=I0AResultCode.STOP_SCHEMA_REFERENCE_UNRESOLVED,
            established_assurances=(),
            binding=None,
        )

    match_input = _BindingSetResolutionInput(
        query=query, candidate_bindings=_FROZEN_PRODUCTION_BINDINGS
    )
    match_result = _resolve_compatible_binding_set(match_input)
    if match_result.code != _PrivateBindingMatchCode.PRIVATE_BINDING_MATCH_EXACTLY_ONE:
        return BindingResolutionResult(
            code=I0AResultCode.STOP_CONTENT_SCHEMA_TARGET_BINDING_INVALID,
            established_assurances=(),
            binding=None,
        )

    return BindingResolutionResult(
        code=I0AResultCode.I0A_BINDING_RESOLVED_A1,
        established_assurances=(
            AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
            AssuranceLevel.A1_REGISTRY_BINDING_RESOLVED,
        ),
        binding=match_result.matching_bindings[0],
    )
