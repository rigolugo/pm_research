"""REV23 Finding 4 I0A -- closed assurance/result types and total canonical
typed-byte constructors.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Governing sections: Finding 4 SS3.4, 5.1, 5.3-5.5

This module owns no path grammar, no accepted-registry parsing, and no
frozen binding table. It performs no filesystem, network, subprocess,
environment, or logging side effects.
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Sequence, Tuple

__all__ = [
    "AssuranceLevel",
    "I0AResultCode",
    "TypedCellTag",
    "StructuralRelationSchemaId",
    "TypedCell",
    "TypedFieldSpec",
    "ValidationResult",
    "CanonicalBytesResult",
    "DigestResult",
    "canonical_typed_cell_bytes",
    "canonical_typed_row_bytes",
]


class AssuranceLevel(Enum):
    A0_NONE = "A0_NONE"
    A1_LEXICAL_PATH_SHAPE = "A1_LEXICAL_PATH_SHAPE"
    A1_REGISTRY_BINDING_RESOLVED = "A1_REGISTRY_BINDING_RESOLVED"
    A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS = "A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS"
    A2_DESCRIPTOR_SET_COMPLETE = "A2_DESCRIPTOR_SET_COMPLETE"
    A3_EXACT_LENGTH_AND_SHA256_RECONCILED = "A3_EXACT_LENGTH_AND_SHA256_RECONCILED"
    A3_PINNED_GOVERNING_SHA256_VALIDATED = "A3_PINNED_GOVERNING_SHA256_VALIDATED"
    A3_STRUCTURAL_SIDECAR_PAIR_RECONCILED = "A3_STRUCTURAL_SIDECAR_PAIR_RECONCILED"
    A4_DECODED_LOGICAL_ROWS_VALIDATED = "A4_DECODED_LOGICAL_ROWS_VALIDATED"
    A5_FILESYSTEM_FACTS_VALIDATED = "A5_FILESYSTEM_FACTS_VALIDATED"
    A6_STRUCTURAL_SCHEMA_COMPLETE = "A6_STRUCTURAL_SCHEMA_COMPLETE"
    A6_DESCRIPTOR_SELECTED_SCHEMA_COMPLETE = "A6_DESCRIPTOR_SELECTED_SCHEMA_COMPLETE"
    A7_PREPARED_OBJECT_FULL = "A7_PREPARED_OBJECT_FULL"
    A8_PREPARED_UNIT_FULL = "A8_PREPARED_UNIT_FULL"


class I0AResultCode(Enum):
    I0A_BYTES_CONSTRUCTED_A0 = "I0A_BYTES_CONSTRUCTED_A0"
    I0A_DIGEST_CONSTRUCTED_A0 = "I0A_DIGEST_CONSTRUCTED_A0"
    I0A_VALID_A1_PATH = "I0A_VALID_A1_PATH"
    I0A_BINDING_RESOLVED_A1 = "I0A_BINDING_RESOLVED_A1"
    I0A_VALID_A2_SINGLE = "I0A_VALID_A2_SINGLE"
    I0A_VALID_A2_SET = "I0A_VALID_A2_SET"
    I0A_VALID_A3_EXACT = "I0A_VALID_A3_EXACT"
    I0A_PINNED_GOVERNING_BYTES_VALIDATED_A3H = "I0A_PINNED_GOVERNING_BYTES_VALIDATED_A3H"
    I0A_REGISTRY_INDEX_MATERIALIZED_A3H = "I0A_REGISTRY_INDEX_MATERIALIZED_A3H"
    I0A_VALID_A3_STRUCTURAL_SIDECAR = "I0A_VALID_A3_STRUCTURAL_SIDECAR"
    I0A_VALID_A4_INTERNAL_RELATION = "I0A_VALID_A4_INTERNAL_RELATION"
    I0A_VALID_A3_A4_STRUCTURAL_OBJECT = "I0A_VALID_A3_A4_STRUCTURAL_OBJECT"
    I0A_VALID_A6_STRUCTURAL = "I0A_VALID_A6_STRUCTURAL"
    I0A_VALID_A6_SELECTED = "I0A_VALID_A6_SELECTED"
    ERR_PATH_LEXICAL_INVALID = "ERR_PATH_LEXICAL_INVALID"
    ERR_PATH_GRAMMAR_MISMATCH = "ERR_PATH_GRAMMAR_MISMATCH"
    ERR_CANONICAL_TAG_INVALID = "ERR_CANONICAL_TAG_INVALID"
    ERR_CANONICAL_TYPE_MISMATCH = "ERR_CANONICAL_TYPE_MISMATCH"
    ERR_CANONICAL_NON_NFC = "ERR_CANONICAL_NON_NFC"
    ERR_CANONICAL_UINT_RANGE = "ERR_CANONICAL_UINT_RANGE"
    ERR_CANONICAL_SHA256_FORMAT = "ERR_CANONICAL_SHA256_FORMAT"
    ERR_CANONICAL_BYTES_FORMAT = "ERR_CANONICAL_BYTES_FORMAT"
    ERR_CANONICAL_FIELD_NAME_INVALID = "ERR_CANONICAL_FIELD_NAME_INVALID"
    ERR_CANONICAL_FIELD_ORDER_INVALID = "ERR_CANONICAL_FIELD_ORDER_INVALID"
    ERR_CANONICAL_ROW_ARITY = "ERR_CANONICAL_ROW_ARITY"
    ERR_DIGEST_INPUT_INVALID = "ERR_DIGEST_INPUT_INVALID"
    ERR_CANONICAL_JSON_INVALID = "ERR_CANONICAL_JSON_INVALID"
    ERR_GOVERNING_PACKAGE_BYTES_MISMATCH = "ERR_GOVERNING_PACKAGE_BYTES_MISMATCH"
    ERR_BINDING_QUERY_INVALID = "ERR_BINDING_QUERY_INVALID"
    ERR_DESCRIPTOR_CLOSED_FIELD_INVALID = "ERR_DESCRIPTOR_CLOSED_FIELD_INVALID"
    ERR_ROLE_DISPOSITION_INVALID = "ERR_ROLE_DISPOSITION_INVALID"
    ERR_ROLE_CARDINALITY_INVALID = "ERR_ROLE_CARDINALITY_INVALID"
    ERR_ORDINAL_SEQUENCE_INVALID = "ERR_ORDINAL_SEQUENCE_INVALID"
    ERR_CANONICAL_TARGET_DUPLICATE = "ERR_CANONICAL_TARGET_DUPLICATE"
    ERR_SIDECAR_RELATION_INVALID = "ERR_SIDECAR_RELATION_INVALID"
    ERR_LOGICAL_HASH_NULLABILITY_INVALID = "ERR_LOGICAL_HASH_NULLABILITY_INVALID"
    ERR_PHYSICAL_EXPECTATION_INVALID = "ERR_PHYSICAL_EXPECTATION_INVALID"
    ERR_PHYSICAL_SIZE_MISMATCH = "ERR_PHYSICAL_SIZE_MISMATCH"
    ERR_PHYSICAL_SHA256_MISMATCH = "ERR_PHYSICAL_SHA256_MISMATCH"
    ERR_LOGICAL_ROWS_INVALID = "ERR_LOGICAL_ROWS_INVALID"
    ERR_LOGICAL_SHA256_MISMATCH = "ERR_LOGICAL_SHA256_MISMATCH"
    ERR_SELECTED_SCHEMA_INVALID = "ERR_SELECTED_SCHEMA_INVALID"
    ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED = "ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED"
    ERR_PAIRED_TARGET_DESCRIPTOR_MISMATCH = "ERR_PAIRED_TARGET_DESCRIPTOR_MISMATCH"
    ERR_STRUCTURAL_MEMBER_SET_INVALID = "ERR_STRUCTURAL_MEMBER_SET_INVALID"
    ERR_PREDECESSOR_RULE_INVALID = "ERR_PREDECESSOR_RULE_INVALID"
    ERR_COVERAGE_STATE_INVALID = "ERR_COVERAGE_STATE_INVALID"
    ERR_PLAN_UNIT_CROSS_MEMBER_MISMATCH = "ERR_PLAN_UNIT_CROSS_MEMBER_MISMATCH"
    ERR_PREPARED_UNIT_ID_MISMATCH = "ERR_PREPARED_UNIT_ID_MISMATCH"
    ERR_CLAIM_SEMANTIC_SCHEMA_MISMATCH = "ERR_CLAIM_SEMANTIC_SCHEMA_MISMATCH"
    STOP_UNIT_KIND_NOT_ACCEPTED_I0A = "STOP_UNIT_KIND_NOT_ACCEPTED_I0A"
    STOP_SCHEMA_REFERENCE_UNRESOLVED = "STOP_SCHEMA_REFERENCE_UNRESOLVED"
    STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A = "STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A"
    STOP_CONTENT_SCHEMA_TARGET_BINDING_INVALID = "STOP_CONTENT_SCHEMA_TARGET_BINDING_INVALID"
    STOP_FILESYSTEM_FACTS_OUT_OF_SCOPE = "STOP_FILESYSTEM_FACTS_OUT_OF_SCOPE"
    STOP_PAYLOAD_LOGICAL_VALIDATION_OUT_OF_SCOPE = "STOP_PAYLOAD_LOGICAL_VALIDATION_OUT_OF_SCOPE"


class TypedCellTag(Enum):
    STRING = "STRING"
    UINT = "UINT"
    BOOL = "BOOL"
    SHA256 = "SHA256"
    BYTES = "BYTES"
    NULL = "NULL"


class StructuralRelationSchemaId(Enum):
    PREPARED_CLAIM_OBJECT_RELATION = "i0a:prepared_claim_object_relation"
    PREPARED_PLANNED_OBJECT_RELATION = "i0a:prepared_planned_object_relation"
    PREPARED_OBJECT_DESCRIPTOR_RELATION = "i0a:prepared_object_descriptor_relation"


@dataclass(frozen=True)
class TypedCell:
    name: str
    type_tag: TypedCellTag
    value: object


@dataclass(frozen=True)
class TypedFieldSpec:
    name: str
    type_tag: TypedCellTag


@dataclass(frozen=True)
class ValidationResult:
    code: I0AResultCode
    established_assurances: Tuple[AssuranceLevel, ...]


@dataclass(frozen=True)
class CanonicalBytesResult:
    code: I0AResultCode
    established_assurances: Tuple[AssuranceLevel, ...]
    value: Optional[bytes]


@dataclass(frozen=True)
class DigestResult:
    code: I0AResultCode
    established_assurances: Tuple[AssuranceLevel, ...]
    digest_sha256: Optional[str]


_SHA256_HEX_LENGTH = 64
_HEX_DIGITS = set("0123456789abcdef")


def _is_lowercase_hex(text: str) -> bool:
    if not isinstance(text, str):
        return False
    return len(text) > 0 or text == ""


def _is_sha256_hex(text: object) -> bool:
    if not isinstance(text, str):
        return False
    if len(text) != _SHA256_HEX_LENGTH:
        return False
    return all(ch in _HEX_DIGITS for ch in text)


def _is_bytes_hex(text: object) -> bool:
    if not isinstance(text, str):
        return False
    if len(text) % 2 != 0:
        return False
    return all(ch in _HEX_DIGITS for ch in text)


def _is_nfc(text: str) -> bool:
    return unicodedata.normalize("NFC", text) == text


def _is_canonical_uint(value: object) -> bool:
    # A canonical UINT is a Python int, non-negative, and not a bool
    # (bool is a subclass of int in Python and must be rejected as a
    # type mismatch rather than silently accepted as an integer).
    if isinstance(value, bool):
        return False
    if not isinstance(value, int):
        return False
    return value >= 0


def _scalar_type_matches_tag(tag: TypedCellTag, value: object) -> bool:
    if tag is TypedCellTag.STRING:
        return isinstance(value, str)
    if tag is TypedCellTag.UINT:
        return isinstance(value, int) and not isinstance(value, bool)
    if tag is TypedCellTag.BOOL:
        return isinstance(value, bool)
    if tag is TypedCellTag.SHA256:
        return isinstance(value, str)
    if tag is TypedCellTag.BYTES:
        return isinstance(value, str)
    if tag is TypedCellTag.NULL:
        return value is None
    return False


def _encode_cell_value(tag: TypedCellTag, value: object) -> object:
    # Returns the exact JSON-native value to place at key "v".
    if tag is TypedCellTag.NULL:
        return None
    return value


def _cell_precondition_error(
    cell: TypedCell, expected: TypedFieldSpec
) -> Optional[I0AResultCode]:
    if not isinstance(cell.name, str) or cell.name != expected.name or not _is_nfc(cell.name):
        return I0AResultCode.ERR_CANONICAL_FIELD_NAME_INVALID
    if cell.type_tag != expected.type_tag:
        return I0AResultCode.ERR_CANONICAL_TAG_INVALID
    if not _scalar_type_matches_tag(cell.type_tag, cell.value):
        return I0AResultCode.ERR_CANONICAL_TYPE_MISMATCH
    if cell.type_tag is TypedCellTag.STRING and not _is_nfc(cell.value):
        return I0AResultCode.ERR_CANONICAL_NON_NFC
    if cell.type_tag is TypedCellTag.UINT and not _is_canonical_uint(cell.value):
        return I0AResultCode.ERR_CANONICAL_UINT_RANGE
    if cell.type_tag is TypedCellTag.SHA256 and not _is_sha256_hex(cell.value):
        return I0AResultCode.ERR_CANONICAL_SHA256_FORMAT
    if cell.type_tag is TypedCellTag.BYTES and not _is_bytes_hex(cell.value):
        return I0AResultCode.ERR_CANONICAL_BYTES_FORMAT
    return None


def _build_cell_json_bytes(cell: TypedCell) -> bytes:
    import json as _json

    obj = {
        "n": cell.name,
        "t": cell.type_tag.value,
        "v": _encode_cell_value(cell.type_tag, cell.value),
    }
    text = _json.dumps(
        obj,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=False,
    )
    return text.encode("utf-8")


def canonical_typed_cell_bytes(
    cell: TypedCell, expected: TypedFieldSpec
) -> CanonicalBytesResult:
    """Total A0 constructor for one expected field name/tag and canonical
    scalar encoding."""
    error = _cell_precondition_error(cell, expected)
    if error is not None:
        return CanonicalBytesResult(
            code=error,
            established_assurances=(),
            value=None,
        )
    return CanonicalBytesResult(
        code=I0AResultCode.I0A_BYTES_CONSTRUCTED_A0,
        established_assurances=(),
        value=_build_cell_json_bytes(cell),
    )


def canonical_typed_row_bytes(
    cells: Sequence[TypedCell], expected_fields: Sequence[TypedFieldSpec]
) -> CanonicalBytesResult:
    """Total A0 row constructor. Exact field name/order is checked before
    tags; equal-tag swaps are field-order errors, not tag errors."""
    if len(cells) != len(expected_fields):
        return CanonicalBytesResult(
            code=I0AResultCode.ERR_CANONICAL_ROW_ARITY,
            established_assurances=(),
            value=None,
        )

    # Field name/order at the first differing ordinal.
    for cell, expected in zip(cells, expected_fields):
        if not isinstance(cell.name, str) or cell.name != expected.name:
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_FIELD_ORDER_INVALID,
                established_assurances=(),
                value=None,
            )

    # Tag, type, normalization/range/format at the first differing ordinal.
    for cell, expected in zip(cells, expected_fields):
        if cell.type_tag != expected.type_tag:
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_TAG_INVALID,
                established_assurances=(),
                value=None,
            )
        if not _scalar_type_matches_tag(cell.type_tag, cell.value):
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_TYPE_MISMATCH,
                established_assurances=(),
                value=None,
            )
        if cell.type_tag is TypedCellTag.STRING and not _is_nfc(cell.value):
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_NON_NFC,
                established_assurances=(),
                value=None,
            )
        if cell.type_tag is TypedCellTag.UINT and not _is_canonical_uint(cell.value):
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_UINT_RANGE,
                established_assurances=(),
                value=None,
            )
        if cell.type_tag is TypedCellTag.SHA256 and not _is_sha256_hex(cell.value):
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_SHA256_FORMAT,
                established_assurances=(),
                value=None,
            )
        if cell.type_tag is TypedCellTag.BYTES and not _is_bytes_hex(cell.value):
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_BYTES_FORMAT,
                established_assurances=(),
                value=None,
            )

    # Field-name lexical validity (NFC) is checked last for the row
    # constructor per the accepted ordered_error_precedence.
    for cell, expected in zip(cells, expected_fields):
        if not _is_nfc(cell.name):
            return CanonicalBytesResult(
                code=I0AResultCode.ERR_CANONICAL_FIELD_NAME_INVALID,
                established_assurances=(),
                value=None,
            )

    row_bytes = b",".join(_build_cell_json_bytes(cell) for cell in cells)
    row_array = b"[" + row_bytes + b"]"
    return CanonicalBytesResult(
        code=I0AResultCode.I0A_BYTES_CONSTRUCTED_A0,
        established_assurances=(),
        value=row_array,
    )
