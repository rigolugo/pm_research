"""REV23 Finding 4 I0A -- pure fixed-hash reconciliation of caller-supplied
governing bytes.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Governing section: canonical effective hash set

This module performs no filesystem, network, subprocess, Git, or project
import side effects. It never reads bytes itself; the caller supplies the
exact governing bytes and this module only recomputes and compares hashes.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

from .canonical import AssuranceLevel, I0AResultCode, ValidationResult

__all__ = [
    "GoverningPackageBytes",
    "validate_governing_package_bytes",
]

# Pinned accepted effective hashes (Revision 23 with Amendments 01-03 and
# Finding 4; see project_context/PROJECT_STATE.md and
# implementation_handoffs/local_curl_rev23_i0/authorization_audit/
# rev23_finding4_i0a/AUTHORIZATION_MANIFEST.json governing_hashes).
_PINNED_SPECIFICATION_SHA256 = (
    "e52f70bb243bc431880c2eaabba7403f7a5d786b70d8a5e903b9026b4bde7a76"
)
_PINNED_SCHEMA_REGISTRY_SHA256 = (
    "c9e8fe1b2c64f64e9cefd76e820c9589708723485ff7e54f4f69e3fe4ed49689"
)
_PINNED_REQUEST_AUTHORIZATION_CONTRACT_SHA256 = (
    "926d1503f20965f2573e2b24d79e747438254f77200b2060bcb741f6279556d0"
)
_PINNED_GOVERNING_MANIFEST_SHA256 = (
    "8cd3c6c93b6f1bba1906b1b2b3f67f6e87846991368bb34b5da52044adbc1f38"
)
_PINNED_ACCEPTED_CHECKSUM_INVENTORY_SHA256 = (
    "be9fe20717a0dc54bd7c73558ea201eb90265bd760e1f7fb78202654cca533f9"
)


@dataclass(frozen=True)
class GoverningPackageBytes:
    spec_bytes: bytes
    registry_bytes: bytes
    request_authorization_bytes: bytes
    manifest_bytes: bytes
    accepted_checksum_inventory_bytes: bytes


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_governing_package_bytes(
    value: GoverningPackageBytes,
) -> ValidationResult:
    """Recompute the five pinned complete-file SHA-256 values. This is
    fixed-hash assurance, not generic A3 expected-length reconciliation."""
    observed = (
        (_sha256_hex(value.spec_bytes), _PINNED_SPECIFICATION_SHA256),
        (_sha256_hex(value.registry_bytes), _PINNED_SCHEMA_REGISTRY_SHA256),
        (
            _sha256_hex(value.request_authorization_bytes),
            _PINNED_REQUEST_AUTHORIZATION_CONTRACT_SHA256,
        ),
        (_sha256_hex(value.manifest_bytes), _PINNED_GOVERNING_MANIFEST_SHA256),
        (
            _sha256_hex(value.accepted_checksum_inventory_bytes),
            _PINNED_ACCEPTED_CHECKSUM_INVENTORY_SHA256,
        ),
    )
    for actual, pinned in observed:
        if actual != pinned:
            return ValidationResult(
                code=I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH,
                established_assurances=(),
            )
    return ValidationResult(
        code=I0AResultCode.I0A_PINNED_GOVERNING_BYTES_VALIDATED_A3H,
        established_assurances=(AssuranceLevel.A3_PINNED_GOVERNING_SHA256_VALIDATED,),
    )
