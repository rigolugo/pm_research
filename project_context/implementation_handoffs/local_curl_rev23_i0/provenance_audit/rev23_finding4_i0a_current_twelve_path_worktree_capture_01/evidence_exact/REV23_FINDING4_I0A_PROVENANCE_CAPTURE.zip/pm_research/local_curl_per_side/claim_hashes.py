"""REV23 Finding 4 I0A -- total fixed A0 hash constructors only; validators
own semantic invariants.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Governing sections: Finding 4 SS5.1, 5.4-5.6

This module performs no filesystem, network, or subprocess side effects and
never imports finding4_registry.py or prepared_evidence.py.
"""

from __future__ import annotations

import hashlib
from typing import Sequence

from .canonical import (
    CanonicalBytesResult,
    DigestResult,
    I0AResultCode,
    TypedCell,
    TypedCellTag,
    TypedFieldSpec,
    canonical_typed_row_bytes,
)

__all__ = [
    "hash_typed_relation",
    "compute_claim_scope_sha256",
    "compute_acquisition_race_scope_sha256",
    "compute_ordered_relation_logical_sha256",
    "compute_snapshot_claim_semantic_sha256",
]


def _join_row_bytes(rows: Sequence[CanonicalBytesResult]) -> DigestResult:
    for row in rows:
        if row.code != I0AResultCode.I0A_BYTES_CONSTRUCTED_A0 or row.value is None:
            return DigestResult(
                code=I0AResultCode.ERR_DIGEST_INPUT_INVALID,
                established_assurances=(),
                digest_sha256=None,
            )
    if rows:
        joined = b"\n".join(row.value for row in rows)
    else:
        joined = b""
    return DigestResult(
        code=I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0,
        established_assurances=(),
        digest_sha256=hashlib.sha256(joined).hexdigest(),
    )


def hash_typed_relation(rows: Sequence[CanonicalBytesResult]) -> DigestResult:
    """A0 LF-join constructor over already-constructed successful row
    bytes; no relation-order or uniqueness assurance."""
    return _join_row_bytes(rows)


def compute_ordered_relation_logical_sha256(
    ordered_rows: Sequence[CanonicalBytesResult],
) -> DigestResult:
    """A0 LF-join constructor; order/uniqueness/schema assurance remains
    with validator."""
    return _join_row_bytes(ordered_rows)


def _resolve_nullable_expected_fields(
    cells: Sequence[TypedCell],
    base_fields: Sequence[TypedFieldSpec],
    nullable_names,
) -> Sequence[TypedFieldSpec]:
    """Fields whose declared domain is 'SHA256 or NULL' (etc.) are encoded
    as a NULL-tagged typed cell when the semantic value is absent and as
    their non-null tag otherwise (see typed_cell_contract: 't=NULL and
    v=null; no typed null using another tag'). The expected tag for such a
    field position is resolved from the actual supplied cell's tag only
    when that cell is NULL; a non-NULL cell is still checked against the
    field's declared non-null tag, so a genuinely wrong tag is still
    ERR_CANONICAL_TAG_INVALID."""
    if len(cells) != len(base_fields):
        return base_fields
    resolved = []
    for cell, field in zip(cells, base_fields):
        if field.name in nullable_names and getattr(cell, "type_tag", None) is not None:
            if cell.type_tag == TypedCellTag.NULL:
                resolved.append(TypedFieldSpec(name=field.name, type_tag=TypedCellTag.NULL))
                continue
        resolved.append(field)
    return tuple(resolved)


def _project_and_hash(
    cells: Sequence[TypedCell],
    expected_fields: Sequence[TypedFieldSpec],
    nullable_names=frozenset(),
) -> DigestResult:
    expected_fields = _resolve_nullable_expected_fields(
        cells, expected_fields, nullable_names
    )
    row_result = canonical_typed_row_bytes(cells, expected_fields)
    if row_result.code != I0AResultCode.I0A_BYTES_CONSTRUCTED_A0:
        return DigestResult(
            code=row_result.code,
            established_assurances=(),
            digest_sha256=None,
        )
    return DigestResult(
        code=I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0,
        established_assurances=(),
        digest_sha256=hashlib.sha256(row_result.value).hexdigest(),
    )


_CLAIM_SCOPE_FIELDS = (
    TypedFieldSpec(name="schema_version", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="spec_revision", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="unit_kind", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="subject_family", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="subject_sequence", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(
        name="expected_predecessor_commit_sha256", type_tag=TypedCellTag.SHA256
    ),
    TypedFieldSpec(name="object_claims_logical_sha256", type_tag=TypedCellTag.SHA256),
)


_CLAIM_SCOPE_NULLABLE_FIELDS = frozenset({"expected_predecessor_commit_sha256"})


def compute_claim_scope_sha256(cells: Sequence[TypedCell]) -> DigestResult:
    """Exact eight-field/name/tag A0 projection constructor."""
    return _project_and_hash(cells, _CLAIM_SCOPE_FIELDS, _CLAIM_SCOPE_NULLABLE_FIELDS)


_ACQUISITION_RACE_SCOPE_FIELDS = (
    TypedFieldSpec(name="schema_version", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="spec_revision", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="fence_sequence", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(
        name="canonical_acquisition_target_path", type_tag=TypedCellTag.STRING
    ),
    TypedFieldSpec(
        name="expected_predecessor_commit_sha256", type_tag=TypedCellTag.SHA256
    ),
)


_ACQUISITION_RACE_SCOPE_NULLABLE_FIELDS = frozenset(
    {"expected_predecessor_commit_sha256"}
)


def compute_acquisition_race_scope_sha256(cells: Sequence[TypedCell]) -> DigestResult:
    """Exact six-field/name/tag A0 projection constructor; no
    FENCE_ACQUIRED reachability claim."""
    return _project_and_hash(
        cells, _ACQUISITION_RACE_SCOPE_FIELDS, _ACQUISITION_RACE_SCOPE_NULLABLE_FIELDS
    )


_SNAPSHOT_CLAIM_SEMANTIC_FIELDS = (
    TypedFieldSpec(name="schema_version", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="spec_revision", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="audit_family", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="snapshot_sequence", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(
        name="previous_snapshot_file_sha256", type_tag=TypedCellTag.SHA256
    ),
    TypedFieldSpec(
        name="previous_publication_commit_file_sha256", type_tag=TypedCellTag.SHA256
    ),
    TypedFieldSpec(name="total_row_count", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(name="duplicate_key_count", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(name="first_key_canonical_json", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="last_key_canonical_json", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(
        name="partition_entries_semantic_logical_sha256", type_tag=TypedCellTag.SHA256
    ),
    TypedFieldSpec(
        name="ordered_relation_logical_sha256", type_tag=TypedCellTag.SHA256
    ),
    TypedFieldSpec(name="capture_coverage_state", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(
        name="covered_through_fence_sequence", type_tag=TypedCellTag.UINT
    ),
    TypedFieldSpec(
        name="capture_coverage_relation_logical_sha256", type_tag=TypedCellTag.SHA256
    ),
)


_SNAPSHOT_CLAIM_SEMANTIC_NULLABLE_FIELDS = frozenset(
    {
        "previous_snapshot_file_sha256",
        "previous_publication_commit_file_sha256",
        "first_key_canonical_json",
        "last_key_canonical_json",
        "covered_through_fence_sequence",
        "capture_coverage_relation_logical_sha256",
    }
)


def compute_snapshot_claim_semantic_sha256(cells: Sequence[TypedCell]) -> DigestResult:
    """Exact sixteen-field/name/tag A0 projection constructor."""
    return _project_and_hash(
        cells, _SNAPSHOT_CLAIM_SEMANTIC_FIELDS, _SNAPSHOT_CLAIM_SEMANTIC_NULLABLE_FIELDS
    )
