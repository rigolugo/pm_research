"""Unexecuted static test source for
pm_research.local_curl_per_side.claim_hashes.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Cases sourced from I0A_STATIC_TEST_CASE_MATRIX.json: T018-T022, T033, T035,
T076, T096-T098, T101-T103, T144-T145.

Statically encodes both non-null SHA256 and NULL nullable-domain cases for
every digest helper that has a nullable field:
- compute_claim_scope_sha256: expected_predecessor_commit_sha256 (NULL at
  subject_sequence 0)
- compute_acquisition_race_scope_sha256: expected_predecessor_commit_sha256
  (NULL at fence_sequence 0)
- compute_snapshot_claim_semantic_sha256: previous_snapshot_file_sha256 and
  previous_publication_commit_file_sha256 (NULL at snapshot_sequence 0),
  alongside non-null SHA256 cells for
  partition_entries_semantic_logical_sha256, ordered_relation_logical_sha256,
  and capture_coverage_relation_logical_sha256 in the same fixture.

Authorization: REV23_FINDING4_I0A_IMPLEMENTATION_AUTHORING_01.
Test execution is NOT authorized. This file is authored source only.
"""

from pm_research.local_curl_per_side.canonical import (
    CanonicalBytesResult,
    I0AResultCode,
    TypedCell,
    TypedCellTag,
)
from pm_research.local_curl_per_side.claim_hashes import (
    compute_acquisition_race_scope_sha256,
    compute_claim_scope_sha256,
    compute_ordered_relation_logical_sha256,
    compute_snapshot_claim_semantic_sha256,
    hash_typed_relation,
)

_RUN_ID = "run_" + "a" * 64
_EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
_CLAIM_SCOPE_DIGEST = "0348081d83a0330b39a368bb6c8e199251600318c9d8394e48e7ce6186f2cb58"
_RACE_SCOPE_DIGEST = "14a998bd9680a50b5c3919ab3476f85117613ec58d82358c1c0b68417cb7e0c8"
_SNAPSHOT_CLAIM_SEMANTIC_DIGEST = (
    "851f6d56df534e6da9b98e2006bf1b77fbd570079ac90be772b8051b7cd3f23e"
)

_PINNED_CLAIM_SCOPE_ROW_UTF8 = (
    b'[{"n":"schema_version","t":"STRING","v":"local_curl_prepared_claim_scope.v23"},'
    b'{"n":"spec_revision","t":"UINT","v":23},'
    b'{"n":"run_id","t":"STRING","v":"' + _RUN_ID.encode("utf-8") + b'"},'
    b'{"n":"unit_kind","t":"STRING","v":"SNAPSHOT_PUBLICATION"},'
    b'{"n":"subject_family","t":"STRING","v":"capture"},'
    b'{"n":"subject_sequence","t":"UINT","v":0},'
    b'{"n":"expected_predecessor_commit_sha256","t":"NULL","v":null},'
    b'{"n":"object_claims_logical_sha256","t":"SHA256","v":'
    b'"1413e3c93549f962e04dbbda85abad039ee727a036aee195a94196affb7ea1d1"}]'
)


# --- hash_typed_relation -----------------------------------------------


def test_t018_empty_rows_hash_to_empty_sha256():
    result = hash_typed_relation(())
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.established_assurances == ()
    assert result.digest_sha256 == _EMPTY_SHA256


def test_t035_non_success_row_returns_err_digest_input_invalid():
    bad_row = CanonicalBytesResult(
        code=I0AResultCode.ERR_CANONICAL_TYPE_MISMATCH,
        established_assurances=(),
        value=None,
    )
    result = hash_typed_relation((bad_row,))
    assert result.code == I0AResultCode.ERR_DIGEST_INPUT_INVALID
    assert result.digest_sha256 is None


def test_t144_one_nonempty_row_hashes_to_pinned_digest():
    row = CanonicalBytesResult(
        code=I0AResultCode.I0A_BYTES_CONSTRUCTED_A0,
        established_assurances=(),
        value=_PINNED_CLAIM_SCOPE_ROW_UTF8,
    )
    result = hash_typed_relation((row,))
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.digest_sha256 == _CLAIM_SCOPE_DIGEST


# --- compute_ordered_relation_logical_sha256 ----------------------------


def test_t021_empty_ordered_rows_hash_to_empty_sha256():
    result = compute_ordered_relation_logical_sha256(())
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.digest_sha256 == _EMPTY_SHA256
    assert result.established_assurances == ()


def test_t145_one_nonempty_ordered_row_hashes_to_pinned_digest():
    row = CanonicalBytesResult(
        code=I0AResultCode.I0A_BYTES_CONSTRUCTED_A0,
        established_assurances=(),
        value=_PINNED_CLAIM_SCOPE_ROW_UTF8,
    )
    result = compute_ordered_relation_logical_sha256((row,))
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.digest_sha256 == _CLAIM_SCOPE_DIGEST


# --- compute_claim_scope_sha256 -----------------------------------------

_VALID_CLAIM_SCOPE_CELLS = (
    TypedCell(
        name="schema_version",
        type_tag=TypedCellTag.STRING,
        value="local_curl_prepared_claim_scope.v23",
    ),
    TypedCell(name="spec_revision", type_tag=TypedCellTag.UINT, value=23),
    TypedCell(name="run_id", type_tag=TypedCellTag.STRING, value=_RUN_ID),
    TypedCell(
        name="unit_kind", type_tag=TypedCellTag.STRING, value="SNAPSHOT_PUBLICATION"
    ),
    TypedCell(name="subject_family", type_tag=TypedCellTag.STRING, value="capture"),
    TypedCell(name="subject_sequence", type_tag=TypedCellTag.UINT, value=0),
    # Nullable-domain field (SHA256 or NULL): NULL branch at subject_sequence 0.
    TypedCell(
        name="expected_predecessor_commit_sha256",
        type_tag=TypedCellTag.NULL,
        value=None,
    ),
    TypedCell(
        name="object_claims_logical_sha256",
        type_tag=TypedCellTag.SHA256,
        value="1413e3c93549f962e04dbbda85abad039ee727a036aee195a94196affb7ea1d1",
    ),
)

# Same fixture with the nullable predecessor field in its non-null SHA256
# branch, exercising the other side of the SHA256-or-NULL domain.
_VALID_CLAIM_SCOPE_CELLS_WITH_PREDECESSOR = (
    _VALID_CLAIM_SCOPE_CELLS[0],
    _VALID_CLAIM_SCOPE_CELLS[1],
    _VALID_CLAIM_SCOPE_CELLS[2],
    _VALID_CLAIM_SCOPE_CELLS[3],
    _VALID_CLAIM_SCOPE_CELLS[4],
    TypedCell(name="subject_sequence", type_tag=TypedCellTag.UINT, value=1),
    TypedCell(
        name="expected_predecessor_commit_sha256",
        type_tag=TypedCellTag.SHA256,
        value="b" * 64,
    ),
    _VALID_CLAIM_SCOPE_CELLS[7],
)

_SWAPPED_RUN_ID_UNIT_KIND_CLAIM_SCOPE_CELLS = (
    TypedCell(
        name="schema_version",
        type_tag=TypedCellTag.STRING,
        value="local_curl_prepared_claim_scope.v23",
    ),
    TypedCell(name="spec_revision", type_tag=TypedCellTag.UINT, value=23),
    TypedCell(
        name="unit_kind", type_tag=TypedCellTag.STRING, value="SNAPSHOT_PUBLICATION"
    ),
    TypedCell(name="run_id", type_tag=TypedCellTag.STRING, value=_RUN_ID),
    TypedCell(name="subject_family", type_tag=TypedCellTag.STRING, value="capture"),
    TypedCell(name="subject_sequence", type_tag=TypedCellTag.UINT, value=0),
    TypedCell(
        name="expected_predecessor_commit_sha256",
        type_tag=TypedCellTag.NULL,
        value=None,
    ),
    TypedCell(
        name="object_claims_logical_sha256",
        type_tag=TypedCellTag.SHA256,
        value="1413e3c93549f962e04dbbda85abad039ee727a036aee195a94196affb7ea1d1",
    ),
)


def test_t019_valid_claim_scope_cells_null_predecessor_hashes_to_pinned_digest():
    result = compute_claim_scope_sha256(_VALID_CLAIM_SCOPE_CELLS)
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.established_assurances == ()
    assert result.digest_sha256 == _CLAIM_SCOPE_DIGEST


def test_claim_scope_non_null_predecessor_sha256_branch_succeeds():
    # Nullable-domain field exercised in its non-null SHA256 branch: still
    # a total A0 construction, distinct digest from the NULL-branch case.
    result = compute_claim_scope_sha256(_VALID_CLAIM_SCOPE_CELLS_WITH_PREDECESSOR)
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.established_assurances == ()
    assert result.digest_sha256 is not None
    assert result.digest_sha256 != _CLAIM_SCOPE_DIGEST


def test_t033_swapped_run_id_unit_kind_returns_err_canonical_field_order_invalid():
    result = compute_claim_scope_sha256(_SWAPPED_RUN_ID_UNIT_KIND_CLAIM_SCOPE_CELLS)
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_ORDER_INVALID
    assert result.digest_sha256 is None
    assert result.established_assurances == ()


def test_t101_removed_ordinal_seven_returns_err_canonical_row_arity():
    truncated = _VALID_CLAIM_SCOPE_CELLS[:7]
    result = compute_claim_scope_sha256(truncated)
    assert result.code == I0AResultCode.ERR_CANONICAL_ROW_ARITY
    assert result.digest_sha256 is None
    assert result.established_assurances == ()


# --- compute_acquisition_race_scope_sha256 -------------------------------

_VALID_RACE_SCOPE_CELLS = (
    TypedCell(
        name="schema_version",
        type_tag=TypedCellTag.STRING,
        value="local_curl_acquisition_race_scope.v23",
    ),
    TypedCell(name="spec_revision", type_tag=TypedCellTag.UINT, value=23),
    TypedCell(name="run_id", type_tag=TypedCellTag.STRING, value=_RUN_ID),
    TypedCell(name="fence_sequence", type_tag=TypedCellTag.UINT, value=0),
    TypedCell(
        name="canonical_acquisition_target_path",
        type_tag=TypedCellTag.STRING,
        value=(
            "artifacts/local_curl_per_side/runs/"
            + _RUN_ID
            + "/capture/commit_fence_history/00000000000000000000"
        ),
    ),
    # Nullable-domain field (SHA256 or NULL): NULL branch at fence_sequence 0.
    TypedCell(
        name="expected_predecessor_commit_sha256",
        type_tag=TypedCellTag.NULL,
        value=None,
    ),
)


def test_t020_valid_race_scope_cells_null_predecessor_hashes_to_pinned_digest():
    result = compute_acquisition_race_scope_sha256(_VALID_RACE_SCOPE_CELLS)
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.digest_sha256 == _RACE_SCOPE_DIGEST
    assert result.established_assurances == ()


def test_t102_extra_appended_field_returns_err_canonical_row_arity():
    extended = _VALID_RACE_SCOPE_CELLS + (
        TypedCell(name="extra", type_tag=TypedCellTag.STRING, value="x"),
    )
    result = compute_acquisition_race_scope_sha256(extended)
    assert result.code == I0AResultCode.ERR_CANONICAL_ROW_ARITY
    assert result.digest_sha256 is None
    assert result.established_assurances == ()


# --- compute_snapshot_claim_semantic_sha256 -------------------------------

_VALID_SNAPSHOT_CLAIM_CELLS = (
    TypedCell(
        name="schema_version",
        type_tag=TypedCellTag.STRING,
        value="local_curl_snapshot_publication_claim_semantic.v23",
    ),
    TypedCell(name="spec_revision", type_tag=TypedCellTag.UINT, value=23),
    TypedCell(name="run_id", type_tag=TypedCellTag.STRING, value=_RUN_ID),
    TypedCell(name="audit_family", type_tag=TypedCellTag.STRING, value="capture"),
    TypedCell(name="snapshot_sequence", type_tag=TypedCellTag.UINT, value=0),
    # Nullable-domain fields (SHA256 or NULL): both NULL at snapshot_sequence 0.
    TypedCell(
        name="previous_snapshot_file_sha256", type_tag=TypedCellTag.NULL, value=None
    ),
    TypedCell(
        name="previous_publication_commit_file_sha256",
        type_tag=TypedCellTag.NULL,
        value=None,
    ),
    TypedCell(name="total_row_count", type_tag=TypedCellTag.UINT, value=1),
    TypedCell(name="duplicate_key_count", type_tag=TypedCellTag.UINT, value=0),
    TypedCell(name="first_key_canonical_json", type_tag=TypedCellTag.STRING, value="[0]"),
    TypedCell(name="last_key_canonical_json", type_tag=TypedCellTag.STRING, value="[0]"),
    # Non-null SHA256 cells in the same fixture, alongside the NULL cells
    # above, per the required both-branches coverage.
    TypedCell(
        name="partition_entries_semantic_logical_sha256",
        type_tag=TypedCellTag.SHA256,
        value="bef068f484d8b9c230dae13031b96c4e4b7ae58a16fd08ff348f6f0d0299b58c",
    ),
    TypedCell(
        name="ordered_relation_logical_sha256",
        type_tag=TypedCellTag.SHA256,
        value="04a2d181e51a4e87f94abc693c3276d204b24e40090fa1a541da30820fb21627",
    ),
    TypedCell(
        name="capture_coverage_state",
        type_tag=TypedCellTag.STRING,
        value="CAPTURE_THROUGH_FENCE_SEQUENCE",
    ),
    TypedCell(name="covered_through_fence_sequence", type_tag=TypedCellTag.UINT, value=0),
    TypedCell(
        name="capture_coverage_relation_logical_sha256",
        type_tag=TypedCellTag.SHA256,
        value="04a2d181e51a4e87f94abc693c3276d204b24e40090fa1a541da30820fb21627",
    ),
)


def test_t022_valid_snapshot_claim_cells_hashes_to_pinned_digest():
    result = compute_snapshot_claim_semantic_sha256(_VALID_SNAPSHOT_CLAIM_CELLS)
    assert result.code == I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0
    assert result.established_assurances == ()
    assert result.digest_sha256 == _SNAPSHOT_CLAIM_SEMANTIC_DIGEST


def test_t103_removed_ordinal_fifteen_returns_err_canonical_row_arity():
    truncated = _VALID_SNAPSHOT_CLAIM_CELLS[:15]
    result = compute_snapshot_claim_semantic_sha256(truncated)
    assert result.code == I0AResultCode.ERR_CANONICAL_ROW_ARITY
    assert result.digest_sha256 is None
    assert result.established_assurances == ()


# --- T076, T096, T097, T098 --------------------------------------------


def test_t076_swapped_run_id_unit_kind_second_pinned_instance_returns_err_canonical_field_order_invalid():
    # T076 shares the swapped_run_id_unit_kind_claim_scope_cells fixture
    # with T033 but is a distinct pinned case ID with its own coverage
    # record and full-payload assertion.
    result = compute_claim_scope_sha256(_SWAPPED_RUN_ID_UNIT_KIND_CLAIM_SCOPE_CELLS)
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_ORDER_INVALID
    assert result.established_assurances == ()
    assert result.digest_sha256 is None


def _with_blanked_uint_cell_zero(cells):
    # Pinned mutation pair applied to ordinal 0: name -> "" and
    # type_tag -> UINT (value retained). The blanked name no longer
    # matches the projection's expected field-name sequence, so the
    # field-order check fires before any tag/type check.
    mutated = TypedCell(name="", type_tag=TypedCellTag.UINT, value=cells[0].value)
    return (mutated,) + tuple(cells[1:])


def test_t096_blanked_first_cell_returns_err_canonical_field_order_invalid():
    result = compute_claim_scope_sha256(
        _with_blanked_uint_cell_zero(_VALID_CLAIM_SCOPE_CELLS)
    )
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_ORDER_INVALID
    assert result.established_assurances == ()
    assert result.digest_sha256 is None


def test_t097_blanked_first_race_cell_returns_err_canonical_field_order_invalid():
    result = compute_acquisition_race_scope_sha256(
        _with_blanked_uint_cell_zero(_VALID_RACE_SCOPE_CELLS)
    )
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_ORDER_INVALID
    assert result.established_assurances == ()
    assert result.digest_sha256 is None


def test_t098_blanked_first_snapshot_claim_cell_returns_err_canonical_field_order_invalid():
    result = compute_snapshot_claim_semantic_sha256(
        _with_blanked_uint_cell_zero(_VALID_SNAPSHOT_CLAIM_CELLS)
    )
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_ORDER_INVALID
    assert result.established_assurances == ()
    assert result.digest_sha256 is None
