"""Unexecuted static test source for pm_research.local_curl_per_side.canonical.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Cases sourced from I0A_STATIC_TEST_CASE_MATRIX.json: T002, T003, T026-T032,
T034, T084-T085, T099-T100.

Authorization: REV23_FINDING4_I0A_IMPLEMENTATION_AUTHORING_01.
Test execution is NOT authorized. This file is authored source only.
"""

from pm_research.local_curl_per_side.canonical import (
    AssuranceLevel,
    I0AResultCode,
    TypedCell,
    TypedCellTag,
    TypedFieldSpec,
    canonical_typed_cell_bytes,
    canonical_typed_row_bytes,
)

_RUN_ID_VALUE = "run_" + "a" * 64


# --- canonical_typed_cell_bytes -------------------------------------------


def test_t002_valid_string_cell_constructs_pinned_bytes():
    cell = TypedCell(name="run_id", type_tag=TypedCellTag.STRING, value=_RUN_ID_VALUE)
    expected = TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.I0A_BYTES_CONSTRUCTED_A0
    assert result.established_assurances == ()
    assert result.value == (
        b'{"n":"run_id","t":"STRING","v":"' + _RUN_ID_VALUE.encode("utf-8") + b'"}'
    )
    assert len(result.value) == 102


def test_t026_tag_mismatch_returns_err_canonical_tag_invalid():
    cell = TypedCell(name="run_id", type_tag=TypedCellTag.UINT, value=1)
    expected = TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_TAG_INVALID
    assert result.established_assurances == ()
    assert result.value is None


def test_t027_type_mismatch_returns_err_canonical_type_mismatch():
    cell = TypedCell(name="run_id", type_tag=TypedCellTag.STRING, value=1)
    expected = TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_TYPE_MISMATCH
    assert result.value is None
    assert result.established_assurances == ()


def test_t028_non_nfc_string_returns_err_canonical_non_nfc():
    cell = TypedCell(name="x", type_tag=TypedCellTag.STRING, value="e\u0301")
    expected = TypedFieldSpec(name="x", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_NON_NFC
    assert result.value is None
    assert result.established_assurances == ()


def test_t029_negative_uint_returns_err_canonical_uint_range():
    cell = TypedCell(name="n", type_tag=TypedCellTag.UINT, value=-1)
    expected = TypedFieldSpec(name="n", type_tag=TypedCellTag.UINT)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_UINT_RANGE
    assert result.value is None
    assert result.established_assurances == ()


def test_t030_bad_sha256_returns_err_canonical_sha256_format():
    cell = TypedCell(name="h", type_tag=TypedCellTag.SHA256, value="ABC")
    expected = TypedFieldSpec(name="h", type_tag=TypedCellTag.SHA256)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_SHA256_FORMAT
    assert result.value is None
    assert result.established_assurances == ()


def test_t031_bad_bytes_returns_err_canonical_bytes_format():
    cell = TypedCell(name="b", type_tag=TypedCellTag.BYTES, value="not-bytes")
    expected = TypedFieldSpec(name="b", type_tag=TypedCellTag.BYTES)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_BYTES_FORMAT
    assert result.value is None
    assert result.established_assurances == ()


def test_t032_empty_field_name_returns_err_canonical_field_name_invalid():
    cell = TypedCell(name="", type_tag=TypedCellTag.STRING, value="x")
    expected = TypedFieldSpec(name="", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_NAME_INVALID
    assert result.value is None
    assert result.established_assurances == ()


def test_t084_multi_fault_prefers_field_name_over_tag_and_type():
    # empty name (invalid) + UINT tag mismatch + non-integer value: field
    # name is checked first in ordered_error_precedence.
    cell = TypedCell(name="", type_tag=TypedCellTag.UINT, value="not-an-int")
    expected = TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_NAME_INVALID
    assert result.established_assurances == ()


def test_t099_wrong_field_name_returns_err_canonical_field_name_invalid():
    cell = TypedCell(
        name="wrong_name", type_tag=TypedCellTag.STRING, value=_RUN_ID_VALUE
    )
    expected = TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_FIELD_NAME_INVALID
    assert result.established_assurances == ()


def test_t100_correct_name_wrong_tag_returns_err_canonical_tag_invalid():
    cell = TypedCell(name="run_id", type_tag=TypedCellTag.UINT, value=23)
    expected = TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING)
    result = canonical_typed_cell_bytes(cell, expected)
    assert result.code == I0AResultCode.ERR_CANONICAL_TAG_INVALID
    assert result.established_assurances == ()


# --- canonical_typed_row_bytes ---------------------------------------------

_CLAIM_SCOPE_CELLS = (
    TypedCell(
        name="schema_version",
        type_tag=TypedCellTag.STRING,
        value="local_curl_prepared_claim_scope.v23",
    ),
    TypedCell(name="spec_revision", type_tag=TypedCellTag.UINT, value=23),
    TypedCell(name="run_id", type_tag=TypedCellTag.STRING, value=_RUN_ID_VALUE),
    TypedCell(
        name="unit_kind", type_tag=TypedCellTag.STRING, value="SNAPSHOT_PUBLICATION"
    ),
    TypedCell(name="subject_family", type_tag=TypedCellTag.STRING, value="capture"),
    TypedCell(name="subject_sequence", type_tag=TypedCellTag.UINT, value=0),
    TypedCell(
        name="expected_predecessor_commit_sha256",
        type_tag=TypedCellTag.NULL,
        value=None,
    ),
    TypedCell(
        name="object_claims_logical_sha256",
        type_tag=TypedCellTag.SHA256,
        value="1413e3c93549f962e04dbbda85abad039ee727a036aee195a94196affb7ea1d1",
    ),
)

_CLAIM_SCOPE_FIELD_SPECS = (
    TypedFieldSpec(name="schema_version", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="spec_revision", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="unit_kind", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="subject_family", type_tag=TypedCellTag.STRING),
    TypedFieldSpec(name="subject_sequence", type_tag=TypedCellTag.UINT),
    TypedFieldSpec(name="expected_predecessor_commit_sha256", type_tag=TypedCellTag.NULL),
    TypedFieldSpec(name="object_claims_logical_sha256", type_tag=TypedCellTag.SHA256),
)

_PINNED_CLAIM_SCOPE_ROW_UTF8 = (
    b'[{"n":"schema_version","t":"STRING","v":"local_curl_prepared_claim_scope.v23"},'
    b'{"n":"spec_revision","t":"UINT","v":23},'
    b'{"n":"run_id","t":"STRING","v":"' + _RUN_ID_VALUE.encode("utf-8") + b'"},'
    b'{"n":"unit_kind","t":"STRING","v":"SNAPSHOT_PUBLICATION"},'
    b'{"n":"subject_family","t":"STRING","v":"capture"},'
    b'{"n":"subject_sequence","t":"UINT","v":0},'
    b'{"n":"expected_predecessor_commit_sha256","t":"NULL","v":null},'
    b'{"n":"object_claims_logical_sha256","t":"SHA256","v":'
    b'"1413e3c93549f962e04dbbda85abad039ee727a036aee195a94196affb7ea1d1"}]'
)


def test_t003_valid_claim_scope_row_constructs_pinned_bytes():
    result = canonical_typed_row_bytes(_CLAIM_SCOPE_CELLS, _CLAIM_SCOPE_FIELD_SPECS)
    assert result.code == I0AResultCode.I0A_BYTES_CONSTRUCTED_A0
    assert result.established_assurances == ()
    assert result.value == _PINNED_CLAIM_SCOPE_ROW_UTF8


def test_t034_empty_cells_wrong_arity_returns_err_canonical_row_arity():
    result = canonical_typed_row_bytes(
        (), (TypedFieldSpec(name="x", type_tag=TypedCellTag.STRING),)
    )
    assert result.code == I0AResultCode.ERR_CANONICAL_ROW_ARITY
    assert result.value is None
    assert result.established_assurances == ()


def test_t085_arity_mismatch_precedes_type_mismatch():
    cells = (TypedCell(name="unit_kind", type_tag=TypedCellTag.UINT, value="not-an-int"),)
    expected_fields = (
        TypedFieldSpec(name="run_id", type_tag=TypedCellTag.STRING),
        TypedFieldSpec(name="unit_kind", type_tag=TypedCellTag.STRING),
    )
    result = canonical_typed_row_bytes(cells, expected_fields)
    assert result.code == I0AResultCode.ERR_CANONICAL_ROW_ARITY
    assert result.established_assurances == ()
