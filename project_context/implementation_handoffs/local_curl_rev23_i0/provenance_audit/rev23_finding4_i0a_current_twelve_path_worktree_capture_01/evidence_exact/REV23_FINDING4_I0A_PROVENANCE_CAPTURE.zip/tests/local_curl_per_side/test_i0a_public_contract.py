"""Unexecuted static test source for the pm_research.local_curl_per_side
public contract: exports, private-symbol exclusion, enum result/assurance
domains, and the two static schema-identity closure checks.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Cases sourced from I0A_STATIC_TEST_CASE_MATRIX.json: T154-T155, plus the
exact_package___all__, exact_private_symbol_exclusion, exact_enum_domains,
exact_success_result_assurance_map, and schema_identity_closure_expected
fixtures.

Authorization: REV23_FINDING4_I0A_IMPLEMENTATION_AUTHORING_01.
Test execution is NOT authorized. This file is authored source only.
"""

import pm_research.local_curl_per_side as i0a
from pm_research.local_curl_per_side.canonical import AssuranceLevel, I0AResultCode
from pm_research.local_curl_per_side import finding4_registry as _registry
from pm_research.local_curl_per_side.finding4_registry import (
    PreparedObjectRole,
    PreparedUnitKind,
    PublicationMode,
)

_EXPECTED_ALL = sorted(
    [
        "AcceptedRegistryLogicalValidationInput",
        "AssuranceLevel",
        "BindingQuery",
        "BindingResolutionResult",
        "CanonicalBytesResult",
        "DescriptorSetInput",
        "DigestResult",
        "FilesystemClaimKind",
        "FilesystemValidationRequest",
        "FrozenPathGrammarId",
        "FullPreparedObjectValidationRequest",
        "FullPreparedUnitValidationRequest",
        "GoverningPackageBytes",
        "I0AInputUnitKind",
        "I0AResultCode",
        "PhysicalPayloadResult",
        "PreparedObjectDescriptor",
        "PreparedObjectRole",
        "PreparedUnitKind",
        "PreparedUnitStructureInput",
        "PublicationMode",
        "RegistryDefinitionIndex",
        "RegistryDefinitionIndexResult",
        "SchemaBinding",
        "SelectedJsonPayloadInput",
        "StructuralJsonMemberInput",
        "StructuralMemberName",
        "StructuralRelationSchemaId",
        "StructuralRelationValidationInput",
        "TypedCell",
        "TypedCellTag",
        "TypedFieldSpec",
        "UnitContext",
        "ValidationResult",
        "build_accepted_registry_schema_definition_index",
        "canonical_typed_cell_bytes",
        "canonical_typed_row_bytes",
        "compute_acquisition_race_scope_sha256",
        "compute_claim_scope_sha256",
        "compute_ordered_relation_logical_sha256",
        "compute_snapshot_claim_semantic_sha256",
        "dispatch_i0a_unit_validation",
        "hash_typed_relation",
        "reconcile_physical_payload",
        "resolve_selected_schema_binding",
        "validate_filesystem_facts",
        "validate_full_prepared_object",
        "validate_full_prepared_unit",
        "validate_governing_package_bytes",
        "validate_normalized_relative_path",
        "validate_payload_logical_representation",
        "validate_prepared_descriptor_set",
        "validate_prepared_object_descriptor",
        "validate_prepared_unit_structure",
        "validate_selected_json_payload",
        "validate_structural_json_member",
        "validate_structural_relation",
    ]
)

_EXCLUDED_FINDING4_REGISTRY_PRIVATE_SYMBOLS = (
    "_BindingSetResolutionInput",
    "_DuplicateJsonKeyError",
    "_PrivateBindingMatchCode",
    "_PrivateBindingMatchResult",
    "_parse_accepted_registry_bytes",
    "_reject_duplicate_json_object_pairs",
    "_reject_json_constant",
    "_reject_json_non_integer_number",
    "_resolve_compatible_binding_set",
    "_FROZEN_PRODUCTION_BINDINGS",
)

_EXCLUDED_PREPARED_EVIDENCE_PRIVATE_SYMBOLS = (
    "_DescriptorSetInvariantInput",
    "_DescriptorSetInvariantSummary",
    "_PrivateDescriptorSetInvariantCode",
    "_PrivateDescriptorSetInvariantResult",
    "_validate_descriptor_set_invariants",
)


def test_package_all_matches_pinned_57_symbol_contract():
    assert sorted(i0a.__all__) == _EXPECTED_ALL
    assert len(i0a.__all__) == 57


def test_package_all_symbols_are_all_importable_from_package():
    for name in i0a.__all__:
        assert hasattr(i0a, name), name


def test_private_finding4_registry_symbols_excluded_from_package_all():
    for name in _EXCLUDED_FINDING4_REGISTRY_PRIVATE_SYMBOLS:
        assert name not in i0a.__all__


def test_private_prepared_evidence_symbols_excluded_from_package_all():
    for name in _EXCLUDED_PREPARED_EVIDENCE_PRIVATE_SYMBOLS:
        assert name not in i0a.__all__


def test_no_underscore_prefixed_symbol_in_package_all():
    for name in i0a.__all__:
        assert not name.startswith("_")


# --- enum domain closure -----------------------------------------------

_EXPECTED_ASSURANCE_LEVELS = (
    "A0_NONE",
    "A1_LEXICAL_PATH_SHAPE",
    "A1_REGISTRY_BINDING_RESOLVED",
    "A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS",
    "A2_DESCRIPTOR_SET_COMPLETE",
    "A3_EXACT_LENGTH_AND_SHA256_RECONCILED",
    "A3_PINNED_GOVERNING_SHA256_VALIDATED",
    "A3_STRUCTURAL_SIDECAR_PAIR_RECONCILED",
    "A4_DECODED_LOGICAL_ROWS_VALIDATED",
    "A5_FILESYSTEM_FACTS_VALIDATED",
    "A6_STRUCTURAL_SCHEMA_COMPLETE",
    "A6_DESCRIPTOR_SELECTED_SCHEMA_COMPLETE",
    "A7_PREPARED_OBJECT_FULL",
    "A8_PREPARED_UNIT_FULL",
)


def test_assurance_level_enum_domain_is_exact():
    actual = tuple(member.value for member in AssuranceLevel)
    assert actual == _EXPECTED_ASSURANCE_LEVELS


def test_i0a_result_code_enum_has_fifty_six_members():
    assert len(list(I0AResultCode)) == 56


_EXPECTED_SUCCESS_ASSURANCE_MAP = {
    I0AResultCode.I0A_BYTES_CONSTRUCTED_A0: (),
    I0AResultCode.I0A_DIGEST_CONSTRUCTED_A0: (),
    I0AResultCode.I0A_VALID_A1_PATH: (AssuranceLevel.A1_LEXICAL_PATH_SHAPE,),
    I0AResultCode.I0A_BINDING_RESOLVED_A1: (
        AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
        AssuranceLevel.A1_REGISTRY_BINDING_RESOLVED,
    ),
    I0AResultCode.I0A_VALID_A2_SINGLE: (
        AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
        AssuranceLevel.A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS,
    ),
    I0AResultCode.I0A_VALID_A2_SET: (
        AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
        AssuranceLevel.A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS,
        AssuranceLevel.A2_DESCRIPTOR_SET_COMPLETE,
    ),
    I0AResultCode.I0A_VALID_A3_EXACT: (
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
    ),
    I0AResultCode.I0A_PINNED_GOVERNING_BYTES_VALIDATED_A3H: (
        AssuranceLevel.A3_PINNED_GOVERNING_SHA256_VALIDATED,
    ),
    I0AResultCode.I0A_REGISTRY_INDEX_MATERIALIZED_A3H: (
        AssuranceLevel.A3_PINNED_GOVERNING_SHA256_VALIDATED,
    ),
    I0AResultCode.I0A_VALID_A3_STRUCTURAL_SIDECAR: (
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
        AssuranceLevel.A3_STRUCTURAL_SIDECAR_PAIR_RECONCILED,
    ),
    I0AResultCode.I0A_VALID_A4_INTERNAL_RELATION: (
        AssuranceLevel.A4_DECODED_LOGICAL_ROWS_VALIDATED,
    ),
    I0AResultCode.I0A_VALID_A3_A4_STRUCTURAL_OBJECT: (
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
        AssuranceLevel.A4_DECODED_LOGICAL_ROWS_VALIDATED,
    ),
    I0AResultCode.I0A_VALID_A6_STRUCTURAL: (
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
        AssuranceLevel.A6_STRUCTURAL_SCHEMA_COMPLETE,
    ),
    I0AResultCode.I0A_VALID_A6_SELECTED: (
        AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
        AssuranceLevel.A1_REGISTRY_BINDING_RESOLVED,
        AssuranceLevel.A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS,
        AssuranceLevel.A2_DESCRIPTOR_SET_COMPLETE,
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
        AssuranceLevel.A6_DESCRIPTOR_SELECTED_SCHEMA_COMPLETE,
    ),
}


def test_success_result_assurance_map_is_pinned_and_complete():
    assert len(_EXPECTED_SUCCESS_ASSURANCE_MAP) == 14
    for code, tup in _EXPECTED_SUCCESS_ASSURANCE_MAP.items():
        assert isinstance(code, I0AResultCode)
        assert isinstance(tup, tuple)


# --- T154 / T155: schema identity closure -----------------------------------

_SELECTED_CONTENT_SCHEMA_DOMAIN_UNION = (
    "json:audit_snapshot_manifest",
    "json:capture_payload_intent_v23",
    "json:fence_event_v23",
    "json:fence_unit_manifest_v23",
    "json:final_artifact_inventory",
    "json:finalization_marker_v23",
    "json:sha256_sidecar",
    "json:snapshot_current_view_commit_v23",
    "json:snapshot_publication_claim_semantic_v23",
    "json:snapshot_publication_commit_v23",
    "json:stop_artifact_inventory",
    "table:authorization_use_events",
    "table:canonical_compatibility_analysis",
    "table:capture_events",
    "table:snapshot_partition",
    "table:strict_audit_analysis",
)


def test_t154_selected_schema_union_is_subset_of_frozen_binding_union():
    # STATIC_CONTRACT_SELECTED_SCHEMA_SUBSET: union(selected_content_schema
    # _domain) must be an exact subset of the frozen production binding
    # schema-ID union (itself accepted-registry-membership-checked
    # elsewhere by resolve_selected_schema_binding/T005/T006).
    frozen_union = set(
        b.content_schema_id for b in _registry._FROZEN_PRODUCTION_BINDINGS
    )
    selected_union = set(_SELECTED_CONTENT_SCHEMA_DOMAIN_UNION)
    assert selected_union.issubset(frozen_union)
    assert selected_union == frozen_union


def test_t155_role_matrix_and_frozen_binding_schema_identity_agree():
    # STATIC_CONTRACT_SCHEMA_IDENTITY_AGREEMENT: the frozen production
    # binding table's schema-ID union must exactly equal the pinned
    # selected-schema union (no legacy alias, no extra, no missing).
    frozen_union = set(
        b.content_schema_id for b in _registry._FROZEN_PRODUCTION_BINDINGS
    )
    pinned_union = set(_SELECTED_CONTENT_SCHEMA_DOMAIN_UNION)
    assert frozen_union - pinned_union == set()
    assert pinned_union - frozen_union == set()


def test_frozen_production_binding_table_has_pinned_cardinality():
    assert len(_registry._FROZEN_PRODUCTION_BINDINGS) == 79
    assert len(set(b.binding_id for b in _registry._FROZEN_PRODUCTION_BINDINGS)) == 79


# --- T147-T152: explicit static-contract case-ID records ---------------
# (Each restates, under its own pinned case ID, an assertion already
# exercised by a supplementary test above; per instruction, given here
# as an independent, explicitly labeled coverage record.)


def test_t147_package_all_matches_exact_pinned_fixture():
    assert sorted(i0a.__all__) == _EXPECTED_ALL


def test_t148_private_symbols_excluded_from_package_all():
    for name in _EXCLUDED_FINDING4_REGISTRY_PRIVATE_SYMBOLS:
        assert name not in i0a.__all__
    for name in _EXCLUDED_PREPARED_EVIDENCE_PRIVATE_SYMBOLS:
        assert name not in i0a.__all__


def test_t149_enum_domains_match_exact_pinned_fixture():
    actual = tuple(member.value for member in AssuranceLevel)
    assert actual == _EXPECTED_ASSURANCE_LEVELS
    assert len(list(I0AResultCode)) == 56


def test_t150_import_graph_has_no_cycles_and_no_prohibited_edge():
    # canonical.py is the acyclic graph's root: it must not expose any
    # symbol originating from the other five candidate modules in its own
    # module namespace. No filesystem read; uses only the already-imported
    # module object's attribute namespace.
    import pm_research.local_curl_per_side.canonical as _canonical_mod

    prohibited_module_names = {
        "finding4_registry",
        "prepared_evidence",
        "governing_package",
        "claim_hashes",
    }
    assert not (vars(_canonical_mod).keys() & prohibited_module_names)
    assert _canonical_mod.__name__ == "pm_research.local_curl_per_side.canonical"


def test_t151_success_result_assurance_map_matches_pinned_fixture():
    assert len(_EXPECTED_SUCCESS_ASSURANCE_MAP) == 14
    for code in (
        I0AResultCode.I0A_VALID_A2_SET,
        I0AResultCode.I0A_VALID_A6_SELECTED,
    ):
        assert code in _EXPECTED_SUCCESS_ASSURANCE_MAP


def test_t152_result_payload_contracts_are_closed_dataclasses():
    from pm_research.local_curl_per_side.canonical import (
        CanonicalBytesResult,
        DigestResult,
        ValidationResult,
    )
    import dataclasses as _dataclasses

    assert {f.name for f in _dataclasses.fields(ValidationResult)} == {
        "code",
        "established_assurances",
    }
    assert {f.name for f in _dataclasses.fields(CanonicalBytesResult)} == {
        "code",
        "established_assurances",
        "value",
    }
    assert {f.name for f in _dataclasses.fields(DigestResult)} == {
        "code",
        "established_assurances",
        "digest_sha256",
    }


# --- T160/T161: NORMAL_FINAL_MARKER matrix closure ----------------------


def test_t160_normal_final_marker_replay_binding_matches_frozen_table():
    matches = [
        b
        for b in _registry._FROZEN_PRODUCTION_BINDINGS
        if b.binding_id
        == "BINDING_NORMAL_FINAL_MARKER_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_DA8169FC7783"
    ]
    assert len(matches) == 1
    b = matches[0]
    assert b.role == PreparedObjectRole.NORMAL_FINAL_MARKER
    assert b.unit_kind == PreparedUnitKind.NORMAL_FINALIZATION
    assert b.publication_mode == PublicationMode.SINGLE_AUTHORITATIVE_FILE
    assert b.target_grammar_id == _registry.FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_00
    assert b.content_schema_id == "json:finalization_marker_v23"
    assert b.logical_sha256_nullability == "NON_NULL"
    assert b.sidecar_rule == "EXACTLY_ONE_NORMAL_FINAL_MARKER_SIDECAR"
    # NORMAL_FINALIZATION is excluded from I0A's reachable unit-kind domain.
    assert b.unit_kind != PreparedUnitKind.SNAPSHOT_PUBLICATION


def test_t161_normal_final_marker_stop_binding_matches_frozen_table():
    matches = [
        b
        for b in _registry._FROZEN_PRODUCTION_BINDINGS
        if b.binding_id
        == "BINDING_NORMAL_FINAL_MARKER_NORMAL_FINALIZATION_SINGLE_AUTHORITATIVE_FILE_AD75320BD2A9"
    ]
    assert len(matches) == 1
    b = matches[0]
    assert b.role == PreparedObjectRole.NORMAL_FINAL_MARKER
    assert b.unit_kind == PreparedUnitKind.NORMAL_FINALIZATION
    assert b.publication_mode == PublicationMode.SINGLE_AUTHORITATIVE_FILE
    assert b.target_grammar_id == _registry.FrozenPathGrammarId.TARGET_NORMAL_FINAL_MARKER_01
    assert b.content_schema_id == "json:finalization_marker_v23"
    assert b.logical_sha256_nullability == "NON_NULL"
    assert b.sidecar_rule == "EXACTLY_ONE_NORMAL_FINAL_MARKER_SIDECAR"
    assert b.unit_kind != PreparedUnitKind.SNAPSHOT_PUBLICATION
