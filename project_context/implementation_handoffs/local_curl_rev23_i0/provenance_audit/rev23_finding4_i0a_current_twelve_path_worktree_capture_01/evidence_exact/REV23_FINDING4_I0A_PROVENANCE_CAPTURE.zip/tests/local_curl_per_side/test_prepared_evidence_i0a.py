"""Unexecuted static test source for
pm_research.local_curl_per_side.prepared_evidence.

Scope: REV23_FINDING4_I0A_SCOPE_REVISION_08
Cases sourced from I0A_STATIC_TEST_CASE_MATRIX.json: T008, T010-T011,
T039-T040, T045-T050, T067, T088, T090-T092, T104, T112-T113.

This file covers descriptor validation, physical payload reconciliation,
accepted-registry logical-representation scoping, internal structural
relation validation, and unit-kind-gate boundaries with exact pinned
fixtures. Full eight-member complete-unit structural fixtures (T126-T143)
and full descriptor-set claim-semantic binding fixtures beyond the cases
below are not transcribed here; see the handoff note for follow-up.

Authorization: REV23_FINDING4_I0A_IMPLEMENTATION_AUTHORING_01.
Test execution is NOT authorized. This file is authored source only.
"""

from pm_research.local_curl_per_side.canonical import (
    AssuranceLevel,
    I0AResultCode,
    StructuralRelationSchemaId,
)
from pm_research.local_curl_per_side.finding4_registry import (
    PreparedObjectRole,
    PreparedUnitKind,
    PublicationMode,
    UnitContext,
)
from pm_research.local_curl_per_side.prepared_evidence import (
    AcceptedRegistryLogicalValidationInput,
    PreparedObjectDescriptor,
    StructuralRelationValidationInput,
    reconcile_physical_payload,
    validate_payload_logical_representation,
    validate_prepared_object_descriptor,
    validate_structural_relation,
)

_RUN_ID = "run_" + "a" * 64
_PREP_ID = "prep_e0c141d97d078cfc958c0a8098e65fafbd79ab317325e0eb525cb5ccf308bec1"
_VALID_UNIT_CONTEXT = UnitContext(
    unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION,
    subject_family="capture",
    subject_sequence=0,
)
_EXCLUDED_UNIT_CONTEXT = UnitContext(
    unit_kind=PreparedUnitKind.FENCE_ACQUIRED, subject_family=None, subject_sequence=0
)
_EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"


# --- validate_prepared_object_descriptor ------------------------------------


def _valid_history_manifest_descriptor() -> PreparedObjectDescriptor:
    return PreparedObjectDescriptor(
        object_ordinal=1,
        object_role=PreparedObjectRole.HISTORY_MANIFEST,
        content_schema_id="json:audit_snapshot_manifest",
        publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER,
        durable_source_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/prepared_evidence/SNAPSHOT_PUBLICATION/" + _PREP_ID
            + "/objects/0000000001.bin"
        ),
        canonical_target_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/capture/audit_snapshot_history/00000000000000000000/audit_snapshot_manifest.json"
        ),
        file_size_bytes=120,
        file_sha256="81c43f45c70d0c436a1b9c06a6172baea7c6efd87f3ac471e1540d5933747056",
        logical_sha256="9d0efe673aa7532275b733723afb24eaaad97dceb622dee30e1a64c7d8838c03",
        sidecar_of_object_ordinal=None,
    )


def test_t008_valid_history_manifest_descriptor_returns_a2_single():
    result = validate_prepared_object_descriptor(
        _valid_history_manifest_descriptor(), _VALID_UNIT_CONTEXT
    )
    assert result.code == I0AResultCode.I0A_VALID_A2_SINGLE
    assert result.established_assurances == (
        AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
        AssuranceLevel.A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS,
    )


def test_t039_negative_file_size_returns_err_descriptor_closed_field_invalid():
    base = _valid_history_manifest_descriptor()
    descriptor = PreparedObjectDescriptor(
        object_ordinal=base.object_ordinal,
        object_role=base.object_role,
        content_schema_id=base.content_schema_id,
        publication_mode=base.publication_mode,
        durable_source_path=base.durable_source_path,
        canonical_target_path=base.canonical_target_path,
        file_size_bytes=-1,
        file_sha256=base.file_sha256,
        logical_sha256=base.logical_sha256,
        sidecar_of_object_ordinal=None,
    )
    result = validate_prepared_object_descriptor(descriptor, _VALID_UNIT_CONTEXT)
    assert result.code == I0AResultCode.ERR_DESCRIPTOR_CLOSED_FIELD_INVALID
    assert result.established_assurances == ()


def test_t040_wrong_publication_mode_returns_err_role_disposition_invalid():
    descriptor = PreparedObjectDescriptor(
        object_ordinal=0,
        object_role=PreparedObjectRole.PARTITION_PAYLOAD,
        content_schema_id="table:capture_events",
        publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER,
        durable_source_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/prepared_evidence/SNAPSHOT_PUBLICATION/" + _PREP_ID
            + "/objects/0000000000.bin"
        ),
        canonical_target_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/capture/partitions/"
            "part_baca56ed5f9d54828f86231ed320e5ffc0500f7ee74a3aafa92b4f1e82177d63.parquet"
        ),
        file_size_bytes=35,
        file_sha256="3a2b73a11c72dc923e86f194de03f39b05cdeb05e0d0e642dd0a529ed4726750",
        logical_sha256="b472da67c0017c932aae0b3d62e1abc68ac37ed27ad94c12a82d7f8a36b144d9",
        sidecar_of_object_ordinal=None,
    )
    result = validate_prepared_object_descriptor(descriptor, _VALID_UNIT_CONTEXT)
    assert result.code == I0AResultCode.ERR_ROLE_DISPOSITION_INVALID
    assert result.established_assurances == ()


def test_t045_sidecar_with_nonnull_logical_hash_returns_err_logical_hash_nullability_invalid():
    descriptor = PreparedObjectDescriptor(
        object_ordinal=2,
        object_role=PreparedObjectRole.HISTORY_MANIFEST_SIDECAR,
        content_schema_id="json:sha256_sidecar",
        publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER,
        durable_source_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/prepared_evidence/SNAPSHOT_PUBLICATION/" + _PREP_ID
            + "/objects/0000000002.bin"
        ),
        canonical_target_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/capture/audit_snapshot_history/00000000000000000000/audit_snapshot_manifest.sha256"
        ),
        file_size_bytes=290,
        file_sha256="d6d73ba43c3aa8585ca8bf7e456487db3b64fd3525fe1e7c8e16e031dc13f324",
        logical_sha256="2879bc96367006608be9cb53140f418beea921167b44154baa2c776d682a695d",
        sidecar_of_object_ordinal=1,
    )
    result = validate_prepared_object_descriptor(descriptor, _VALID_UNIT_CONTEXT)
    assert result.code == I0AResultCode.ERR_LOGICAL_HASH_NULLABILITY_INVALID
    assert result.established_assurances == ()


def test_t088_excluded_unit_returns_stop_unit_kind_not_accepted_i0a():
    descriptor = PreparedObjectDescriptor(
        object_ordinal=-1,
        object_role=PreparedObjectRole.HISTORY_MANIFEST,
        content_schema_id="json:audit_snapshot_manifest",
        publication_mode=PublicationMode.ATOMIC_BUNDLE_MEMBER,
        durable_source_path="/absolute",
        canonical_target_path="/absolute",
        file_size_bytes=-1,
        file_sha256="BAD",
        logical_sha256=None,
        sidecar_of_object_ordinal=None,
    )
    result = validate_prepared_object_descriptor(descriptor, _EXCLUDED_UNIT_CONTEXT)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


# --- reconcile_physical_payload ---------------------------------------------


def test_t010_valid_exact_payload_returns_a3_exact():
    result = reconcile_physical_payload(
        3,
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        b"abc",
    )
    assert result.code == I0AResultCode.I0A_VALID_A3_EXACT
    assert result.established_assurances == (
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
    )
    assert result.observed_size_bytes == 3
    assert result.observed_sha256 == (
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    )


def test_t046_invalid_expectation_returns_err_physical_expectation_invalid_and_nulls():
    result = reconcile_physical_payload(-1, "bad", b"")
    assert result.code == I0AResultCode.ERR_PHYSICAL_EXPECTATION_INVALID
    assert result.observed_size_bytes is None
    assert result.observed_sha256 is None
    assert result.established_assurances == ()


def test_t047_size_mismatch_returns_err_physical_size_mismatch_with_observations():
    result = reconcile_physical_payload(
        4,
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        b"abc",
    )
    assert result.code == I0AResultCode.ERR_PHYSICAL_SIZE_MISMATCH
    assert result.observed_size_bytes == 3
    assert result.observed_sha256 is not None
    assert result.established_assurances == ()


def test_t048_sha256_mismatch_returns_err_physical_sha256_mismatch_with_observations():
    result = reconcile_physical_payload(3, "0" * 64, b"abc")
    assert result.code == I0AResultCode.ERR_PHYSICAL_SHA256_MISMATCH
    assert result.observed_size_bytes == 3
    assert result.observed_sha256 == (
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    )
    assert result.established_assurances == ()


def test_t091_uppercase_hash_and_negative_size_returns_err_physical_expectation_invalid():
    result = reconcile_physical_payload(-1, "BAD", b"a")
    assert result.code == I0AResultCode.ERR_PHYSICAL_EXPECTATION_INVALID
    assert result.observed_size_bytes is None
    assert result.observed_sha256 is None
    assert result.established_assurances == ()


# --- validate_payload_logical_representation --------------------------------


def test_t092_registry_bytes_mismatch_returns_err_governing_package_bytes_mismatch():
    value = AcceptedRegistryLogicalValidationInput(
        schema_id="table:snapshot_partition",
        decoded_rows=None,
        expected_logical_sha256="BAD",
        accepted_registry_bytes=b"\x00",
    )
    result = validate_payload_logical_representation(value)
    assert result.code == I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH
    assert result.established_assurances == ()


def test_t112_internal_schema_id_returns_err_selected_schema_invalid():
    value = AcceptedRegistryLogicalValidationInput(
        schema_id="i0a:prepared_claim_object_relation",
        decoded_rows=(),
        expected_logical_sha256=_EMPTY_SHA256,
        accepted_registry_bytes=b"\x00",
    )
    result = validate_payload_logical_representation(value)
    assert result.code == I0AResultCode.ERR_SELECTED_SCHEMA_INVALID
    assert result.established_assurances == ()


# --- validate_structural_relation -------------------------------------------


def test_t011_empty_internal_relation_returns_a4_internal_relation():
    value = StructuralRelationValidationInput(
        schema_id=StructuralRelationSchemaId.PREPARED_CLAIM_OBJECT_RELATION,
        decoded_rows=(),
        expected_logical_sha256=_EMPTY_SHA256,
    )
    result = validate_structural_relation(value)
    assert result.code == I0AResultCode.I0A_VALID_A4_INTERNAL_RELATION
    assert result.established_assurances == (
        AssuranceLevel.A4_DECODED_LOGICAL_ROWS_VALIDATED,
    )


def test_t049_unknown_row_shape_returns_err_logical_rows_invalid():
    value = StructuralRelationValidationInput(
        schema_id=StructuralRelationSchemaId.PREPARED_CLAIM_OBJECT_RELATION,
        decoded_rows=({"unknown": 1},),
        expected_logical_sha256=_EMPTY_SHA256,
    )
    result = validate_structural_relation(value)
    assert result.code == I0AResultCode.ERR_LOGICAL_ROWS_INVALID
    assert result.established_assurances == ()


def test_t050_empty_rows_wrong_expected_hash_returns_err_logical_sha256_mismatch():
    value = StructuralRelationValidationInput(
        schema_id=StructuralRelationSchemaId.PREPARED_CLAIM_OBJECT_RELATION,
        decoded_rows=(),
        expected_logical_sha256="0" * 64,
    )
    result = validate_structural_relation(value)
    assert result.code == I0AResultCode.ERR_LOGICAL_SHA256_MISMATCH
    assert result.established_assurances == ()


# --- validate_structural_json_member (partial: T013, T036, T071, T094,
# T106, T114, T051 -- fully fixture-verified; remaining cases in this
# function's 29-case domain are tracked as NOT_YET_ENCODED in the
# handoff reconciliation, not silently passed) --------------------------

from pm_research.local_curl_per_side.prepared_evidence import (
    StructuralJsonMemberInput,
    StructuralMemberName,
    validate_structural_json_member,
)

_STRUCTURAL_PREP_ID = "prep_e0c141d97d078cfc958c0a8098e65fafbd79ab317325e0eb525cb5ccf308bec1"
_STRUCTURAL_UNIT_CONTEXT = UnitContext(
    unit_kind=PreparedUnitKind.SNAPSHOT_PUBLICATION,
    subject_family="capture",
    subject_sequence=0,
)


def _canonical_json_bytes(obj) -> bytes:
    # The accepted contract's canonical JSON persistence rule: UTF-8, no
    # BOM, compact separators, lexicographic key order, no whitespace, no
    # final LF. Pure in-memory construction from embedded literals; no
    # filesystem or project-module access.
    return json.dumps(
        obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")


# Pinned CLAIM_SCOPE.json content for prep_e0c141d...8bec1 (embedded
# literal, deterministically canonicalized at test-definition time).
_CLAIM_SCOPE_OBJECT_CLAIMS = (
    {"object_ordinal": 0, "object_role": "PARTITION_PAYLOAD", "content_schema_id": "table:capture_events", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/partitions/part_baca56ed5f9d54828f86231ed320e5ffc0500f7ee74a3aafa92b4f1e82177d63.parquet"},
    {"object_ordinal": 1, "object_role": "HISTORY_MANIFEST", "content_schema_id": "json:audit_snapshot_manifest", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/audit_snapshot_history/00000000000000000000/audit_snapshot_manifest.json"},
    {"object_ordinal": 2, "object_role": "HISTORY_MANIFEST_SIDECAR", "content_schema_id": "json:sha256_sidecar", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/audit_snapshot_history/00000000000000000000/audit_snapshot_manifest.sha256"},
    {"object_ordinal": 3, "object_role": "HISTORY_INDEX", "content_schema_id": "table:snapshot_partition", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/audit_snapshot_history/00000000000000000000/snapshot_partitions.parquet"},
    {"object_ordinal": 4, "object_role": "PUBLICATION_MARKER", "content_schema_id": "json:snapshot_publication_commit_v23", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/audit_snapshot_history/00000000000000000000/PUBLICATION_COMMITTED.json"},
    {"object_ordinal": 5, "object_role": "PUBLICATION_MARKER_SIDECAR", "content_schema_id": "json:sha256_sidecar", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/audit_snapshot_history/00000000000000000000/PUBLICATION_COMMITTED.sha256"},
    {"object_ordinal": 6, "object_role": "CURRENT_GENERATION_MANIFEST", "content_schema_id": "json:audit_snapshot_manifest", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/current_view_generations/00000000000000000000/audit_snapshot_manifest.json"},
    {"object_ordinal": 7, "object_role": "CURRENT_GENERATION_MANIFEST_SIDECAR", "content_schema_id": "json:sha256_sidecar", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/current_view_generations/00000000000000000000/audit_snapshot_manifest.sha256"},
    {"object_ordinal": 8, "object_role": "CURRENT_GENERATION_INDEX", "content_schema_id": "table:snapshot_partition", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/current_view_generations/00000000000000000000/snapshot_partitions.parquet"},
    {"object_ordinal": 9, "object_role": "CURRENT_GENERATION_MARKER", "content_schema_id": "json:snapshot_current_view_commit_v23", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/current_view_generations/00000000000000000000/CURRENT_VIEW_COMMITTED.json"},
    {"object_ordinal": 10, "object_role": "CURRENT_GENERATION_MARKER_SIDECAR", "content_schema_id": "json:sha256_sidecar", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/current_view_generations/00000000000000000000/CURRENT_VIEW_COMMITTED.sha256"},
    {"object_ordinal": 11, "object_role": "LEGACY_CURRENT_MANIFEST", "content_schema_id": "json:audit_snapshot_manifest", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/audit_snapshot_manifest.json"},
    {"object_ordinal": 12, "object_role": "LEGACY_CURRENT_MANIFEST_SIDECAR", "content_schema_id": "json:sha256_sidecar", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/audit_snapshot_manifest.sha256"},
    {"object_ordinal": 13, "object_role": "LEGACY_CURRENT_INDEX", "content_schema_id": "table:snapshot_partition", "canonical_target_path": "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/snapshot_partitions.parquet"},
)

_CLAIM_SCOPE_OBJECT = {
    "expected_predecessor_commit_sha256": None,
    "object_claims": list(_CLAIM_SCOPE_OBJECT_CLAIMS),
    "object_claims_logical_sha256": (
        "1413e3c93549f962e04dbbda85abad039ee727a036aee195a94196affb7ea1d1"
    ),
    "run_id": _RUN_ID,
    "schema_version": "local_curl_prepared_claim_scope.v23",
    "spec_revision": 23,
    "subject_family": "capture",
    "subject_sequence": 0,
    "unit_kind": "SNAPSHOT_PUBLICATION",
}


def _claim_scope_sidecar_payload_bytes() -> bytes:
    sidecar_obj = {
        "target_file_sha256": (
            "2cdc358ea585b61a04123b30fa83424c9d76cd2507d1716cf3a944b2742da769"
        ),
        "target_path": (
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/prepared_evidence/SNAPSHOT_PUBLICATION/" + _STRUCTURAL_PREP_ID
            + "/CLAIM_SCOPE.json"
        ),
    }
    return _canonical_json_bytes(sidecar_obj)


def _claim_scope_paired_json_bytes() -> bytes:
    # The exact canonical CLAIM_SCOPE.json paired target, constructed
    # deterministically from the embedded _CLAIM_SCOPE_OBJECT literal --
    # used only as an opaque blob for physical (length/SHA-256)
    # reconciliation of the paired target on the sidecar code path.
    return _canonical_json_bytes(_CLAIM_SCOPE_OBJECT)


def test_t013_and_t071_valid_claim_scope_sidecar_returns_a3_structural_sidecar():
    value = StructuralJsonMemberInput(
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        run_id=_RUN_ID,
        prepared_unit_id=_STRUCTURAL_PREP_ID,
        member_name=StructuralMemberName.CLAIM_SCOPE_SHA256,
        payload_bytes=_claim_scope_sidecar_payload_bytes(),
        expected_file_size_bytes=335,
        expected_file_sha256=(
            "dc748bdcd6bcb8221beccba9b99ecd143ccb25f2ef9f51b6798ceb1d16654d28"
        ),
        paired_target_bytes=_claim_scope_paired_json_bytes(),
        paired_target_expected_file_size_bytes=4779,
        paired_target_expected_file_sha256=(
            "2cdc358ea585b61a04123b30fa83424c9d76cd2507d1716cf3a944b2742da769"
        ),
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_STRUCTURAL_SIDECAR
    assert result.established_assurances == (
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
        AssuranceLevel.A3_STRUCTURAL_SIDECAR_PAIR_RECONCILED,
    )


def test_t113_empty_internal_relation_second_pinned_instance_returns_a4_internal_relation():
    # T113 shares the internal_empty_claim_relation_input fixture with
    # T011 but is a distinct pinned case ID and gets its own independent
    # coverage record and assertion path per the accepted matrix.
    value = StructuralRelationValidationInput(
        schema_id=StructuralRelationSchemaId.PREPARED_CLAIM_OBJECT_RELATION,
        decoded_rows=(),
        expected_logical_sha256=_EMPTY_SHA256,
    )
    result = validate_structural_relation(value)
    assert result.code == I0AResultCode.I0A_VALID_A4_INTERNAL_RELATION
    assert result.established_assurances == (
        AssuranceLevel.A4_DECODED_LOGICAL_ROWS_VALIDATED,
    )


def test_t094_missing_paired_target_returns_err_paired_target_physical_proof_required():
    value = StructuralJsonMemberInput(
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        run_id=_RUN_ID,
        prepared_unit_id=_STRUCTURAL_PREP_ID,
        member_name=StructuralMemberName.CLAIM_SCOPE_SHA256,
        payload_bytes=_claim_scope_sidecar_payload_bytes(),
        expected_file_size_bytes=335,
        expected_file_sha256=(
            "dc748bdcd6bcb8221beccba9b99ecd143ccb25f2ef9f51b6798ceb1d16654d28"
        ),
        paired_target_bytes=None,
        paired_target_expected_file_size_bytes=None,
        paired_target_expected_file_sha256=None,
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED
    assert result.established_assurances == ()


def test_t114_wrong_sidecar_target_path_returns_err_selected_schema_invalid():
    # Sidecar JSON's target_path field does not equal the independently
    # derived path (mutated fixture: expected_file_sha256/size recomputed
    # for the mutated bytes; payload otherwise identical field-shape).
    mutated_sidecar_obj = {
        "target_file_sha256": (
            "2cdc358ea585b61a04123b30fa83424c9d76cd2507d1716cf3a944b2742da769"
        ),
        "target_path": (
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/prepared_evidence/SNAPSHOT_PUBLICATION/" + _STRUCTURAL_PREP_ID
            + "/WRONG_MEMBER_NAME.json"
        ),
    }
    mutated_sidecar = _canonical_json_bytes(mutated_sidecar_obj)
    import hashlib as _hashlib

    value = StructuralJsonMemberInput(
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        run_id=_RUN_ID,
        prepared_unit_id=_STRUCTURAL_PREP_ID,
        member_name=StructuralMemberName.CLAIM_SCOPE_SHA256,
        payload_bytes=mutated_sidecar,
        expected_file_size_bytes=len(mutated_sidecar),
        expected_file_sha256=_hashlib.sha256(mutated_sidecar).hexdigest(),
        paired_target_bytes=_claim_scope_paired_json_bytes(),
        paired_target_expected_file_size_bytes=4779,
        paired_target_expected_file_sha256=(
            "2cdc358ea585b61a04123b30fa83424c9d76cd2507d1716cf3a944b2742da769"
        ),
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_SELECTED_SCHEMA_INVALID
    assert result.established_assurances == ()


def test_t036_malformed_claim_scope_json_returns_err_canonical_json_invalid():
    payload = b"{"
    value = StructuralJsonMemberInput(
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        run_id=_RUN_ID,
        prepared_unit_id=_STRUCTURAL_PREP_ID,
        member_name=StructuralMemberName.CLAIM_SCOPE_JSON,
        payload_bytes=payload,
        expected_file_size_bytes=1,
        expected_file_sha256=(
            "021fb596db81e6d02bf3d2586ee3981fe519f275c0ac9ca76bbcf2ebb4097d96"
        ),
        paired_target_bytes=None,
        paired_target_expected_file_size_bytes=None,
        paired_target_expected_file_sha256=None,
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_CANONICAL_JSON_INVALID
    assert result.established_assurances == ()


def test_t106_excluded_unit_returns_stop_unit_kind_not_accepted_i0a():
    value = StructuralJsonMemberInput(
        unit_context=UnitContext(
            unit_kind=PreparedUnitKind.FENCE_ACQUIRED,
            subject_family=None,
            subject_sequence=0,
        ),
        run_id=_RUN_ID,
        prepared_unit_id="prep_71a336a604cd8cecb45f5bfe962fd166d44ba44c4e1bdf12068bc8b41a353a64",
        member_name=StructuralMemberName.PREPARATION_PLAN_JSON,
        payload_bytes=b"{",
        expected_file_size_bytes=1,
        expected_file_sha256="00",
        paired_target_bytes=None,
        paired_target_expected_file_size_bytes=None,
        paired_target_expected_file_sha256=None,
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


# --- validate_filesystem_facts -----------------------------------------

from pm_research.local_curl_per_side.prepared_evidence import (
    FilesystemClaimKind,
    FilesystemValidationRequest,
    validate_filesystem_facts,
)


def test_t015_symlink_free_claim_always_stops_out_of_scope():
    request = FilesystemValidationRequest(
        claim_kind=FilesystemClaimKind.SYMLINK_FREE_REGULAR_FILE,
        claimed_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/capture/audit_snapshot_history/00000000000000000000/PUBLICATION_COMMITTED.json"
        ),
        caller_asserted_value=True,
    )
    result = validate_filesystem_facts(request)
    assert result.code == I0AResultCode.STOP_FILESYSTEM_FACTS_OUT_OF_SCOPE
    assert result.established_assurances == ()


def test_t066_canonical_target_reopened_claim_always_stops_out_of_scope():
    request = FilesystemValidationRequest(
        claim_kind=FilesystemClaimKind.CANONICAL_TARGET_REOPENED,
        claimed_path=(
            "artifacts/local_curl_per_side/runs/" + _RUN_ID
            + "/capture/audit_snapshot_history/00000000000000000000/PUBLICATION_COMMITTED.json"
        ),
        caller_asserted_value=True,
    )
    result = validate_filesystem_facts(request)
    assert result.code == I0AResultCode.STOP_FILESYSTEM_FACTS_OUT_OF_SCOPE
    assert result.established_assurances == ()


# --- private _validate_descriptor_set_invariants (white-box) ----------

from pm_research.local_curl_per_side.prepared_evidence import (
    _DescriptorSetInvariantInput,
    _DescriptorSetInvariantSummary,
    _PrivateDescriptorSetInvariantCode,
    _validate_descriptor_set_invariants,
)


def test_t043_duplicate_canonical_target_returns_private_canonical_target_duplicate():
    summaries = (
        _DescriptorSetInvariantSummary(
            object_ordinal=0,
            object_role=PreparedObjectRole.PARTITION_PAYLOAD,
            canonical_target_path="same/path",
            is_sidecar=False,
            sidecar_of_object_ordinal=None,
        ),
        _DescriptorSetInvariantSummary(
            object_ordinal=1,
            object_role=PreparedObjectRole.HISTORY_MANIFEST,
            canonical_target_path="same/path",
            is_sidecar=False,
            sidecar_of_object_ordinal=None,
        ),
    )
    value = _DescriptorSetInvariantInput(
        summaries=summaries,
        expected_role_counts={
            PreparedObjectRole.HISTORY_MANIFEST: 1,
            PreparedObjectRole.PARTITION_PAYLOAD: 1,
        },
    )
    result = _validate_descriptor_set_invariants(value)
    assert (
        result.code
        == _PrivateDescriptorSetInvariantCode.PRIVATE_DESCRIPTOR_SET_CANONICAL_TARGET_DUPLICATE
    )
    assert result.summaries is None


def test_t146_valid_one_partition_summaries_returns_private_invariants_valid():
    summaries = (
        _DescriptorSetInvariantSummary(
            object_ordinal=0,
            object_role=PreparedObjectRole.PARTITION_PAYLOAD,
            canonical_target_path=(
                "artifacts/local_curl_per_side/runs/" + _RUN_ID
                + "/capture/partitions/"
                "part_baca56ed5f9d54828f86231ed320e5ffc0500f7ee74a3aafa92b4f1e82177d63.parquet"
            ),
            is_sidecar=False,
            sidecar_of_object_ordinal=None,
        ),
    )
    value = _DescriptorSetInvariantInput(
        summaries=summaries,
        expected_role_counts={PreparedObjectRole.PARTITION_PAYLOAD: 1},
    )
    result = _validate_descriptor_set_invariants(value)
    assert (
        result.code
        == _PrivateDescriptorSetInvariantCode.PRIVATE_DESCRIPTOR_SET_INVARIANTS_VALID
    )
    assert result.summaries == summaries


# ======================================================================
# Self-contained embedded fixtures (standard-library reconstruction only;
# every reconstructed artifact is length- and SHA-256-asserted against its
# pinned Revision 08 value before use; no canonical-file read at
# test-execution time).
# ======================================================================

import base64 as _b64
import copy as _copy
import hashlib as _hl
import json as _json
import zlib as _zlib

_PE_REGISTRY_PINNED_LEN = 864789
_PE_REGISTRY_PINNED_SHA256 = (
    "c9e8fe1b2c64f64e9cefd76e820c9589708723485ff7e54f4f69e3fe4ed49689"
)
_PE_REGISTRY_B64_ZLIB = (
    "eNrsvQtz4kiyMPpX9DnujTgnPrsNfrXdPbsRNJZtdjD48PBMb0dfhQBh6wwgFkF3ezfmv9/MrIeqpJIoMH71ELvR"
    "Y6RSPTKzsjKz8vGfHX8wCOdhNPFH3nQWTYPZPAxibxqNwv7Dzoedi2brU+383G148Jfn3rqtz96N22rX2h333Gt+"
    "+odb7XiVxrnXav62s7vjj0ZeNAm8fjSZz/z+fOfDf3aCb/5o4eMY0F+nVbu8dFvwbaVe95oN1wmHQ2cQxvNw0p97"
    "8dyf49eLyfxv5Y9Oo9nxki+uu/VOzWt3Kp38r/4OX/mTByeezxb9+WLmj5xwAhMIYZUPThg77U7zRozt3cLsYVnt"
    "Tqtb7XRblbpXa9xW6rVzWMos8ONo4o396TSc3OFCqs3Gea1Taza8m0qtxSaCzyfR3JvPwru7YBYMYI3KPPkI0J3a"
    "oNq8vqm78Pbg6NRL9cqndFVpe+1a47Lu8nH+3N3pNH8FPFy7lXa35V67DYCN27quNWDaG5jL0dmJlx0hdzp/IoTi"
    "xWgOZBP0g0Ew6QfQneza+Rb059HMeQiD0SB26s0qTLPabdW9lntTr3wGSMPKq/Vuu3brOr1gGM0CxFrYn+/P76Hr"
    "+2g0cEZ+LxjFMGVCISeiLzvBD6Ct0YMDpObA6NFs4ADliiEn/jiAT4IfU/gNM/EnAyfqxcHsG/z4I3jYi4O5c+/H"
    "90HsBP9a+CNoPAomd/N7hzpmdOwg2UKLcMKeOoNo7IcTeEnk5hC5xU68GDvzyGHfw0uYi7r8UXQX9oEIcTia6ni6"
    "mEOvw1kE3z1MoeV/wSch7r9ohvuGbUcvHOzSOP/tBLCVYE/ufAUoUKcxgOA/OzBM+E1sK0Ceg33D7144QlIfA/ku"
    "ZsEYvnbmwWyMIzjUYwwtpyEMTHOYAQSCeI6baRrFNDZfc9Bf4C+HVvTRqTWA2lrdG9z3bbcOdOGeO7TPwx4tSSUb"
    "FbkAFA46wJza6KbltuG/8F596l7fdD57lVar8jn1ptGEfr3fao3z5m/eTbOW+VQb9atA6s4HgM7uDlHFh+WbiKMQ"
    "mgrQaKAgOJbevTs6O0ZSiBYzonve1lPA+E5DiKcgxBMIYZwL9vZ/FBDBJmnhvD41O1cwhPgJ/Er51XBrnSu3pTzJ"
    "WzzwGLl4IwdLFgxLmD3sBaPwLuyNkMITYnQWkzi8mwDVdDsXe6dO7wFQrgIgaTz1w5nnw+oe4jB+11/MZrhkesqX"
    "+xWYhw8HzRC2ldf35z7sEmRel004XxrAZmB61V8rl653XWnULtx2B5jG7cHhu/+Nkdr/s9P3GSIArjC04AZlmA9M"
    "A3ZkQHtkpw0Dh5MA9/dwAYdB4Ez9/h/+XeBwdhLNEFK4N73ZYsSWMZ6OAtjewxAg0L6q7B0cn3x04v59MPb3YuAo"
    "4TDsO7Po+z7f2vsxvIFx+oKl+KM4om0VIocFRITDoP/Qp+7F+INg7kOXAwc+hdcx8pzxYu4zWoGG4Zh+jpCRwbk8"
    "WPQJQzezCFrHwFhET71FOELsASpojt4sGEJDhNSHu+hbMJvA6eXx1p4cDjCwFNrxvQ+L/yngHYeDABbxJFBmYPLE"
    "EABZAp/XblRu2lcgwdxUWh2266qVRtWt1yv0owLc5xw50Lvx4FFA7vuTaEKnzLrgngV3IEvRuWWEspNIiTAlAWvn"
    "+z184oCABMIih6IKfJjXAKcROJIQHeBDkwHywJVR0YPzdkA7BiYawgL/zQ6/FEqiqQ9s7MPYn/0xiL5PdhRWEwMJ"
    "wdI8YEkg7AYzQtk+yrw+l4D9BSxz/5fZAlne34ndjLKo+Xcwi+AocMYosgTfYDFxAZJk/zEA7lsYfA+efRNE8Xxv"
    "SPNnMHO+z8I5Sk7/C/IE/kYJCchlHPZRdADhKxwsApCuRg9pNAGyAYF7+MqJFnOEoMO7BtwA4HT0BT8AWXhiKlB2"
    "CMpsDpkdRSTwIYMTj4N5KTZBGPUQff58Hoyn0OiX1BNE7D78DewXyTDeF6zYUxryl56A8qoHz+0JgsKBCcHXcwSi"
    "v5jfRzMB/xdjh7NgDycmjx/5cdRDWrDclLfHlaSLBFyFXNIGzC+G3pVPujeDYOLeq51+m8YuTmFTmAVWA9rldBZC"
    "v6CgA6rgcNjHVsxi4RkbrLx9jz+lj1J20rxytFsj2FHAVIhXIzi9bweHm0KoAOV+9iV7sTLuSnuAJYmImJbONkU8"
    "j6bysHpuFA3DGaiSMMg4nKNRQkxKANEWdyX5pUKFWcTlgXOTuGNbjv/HYxYWJum8m/ozkMLm+XhTJE7lQ2ZUyaD0"
    "yGFjoGQSjb4RrSKXSpjM695vcv7cCpUj9RgA+TSoIjCSRWM5og4PEEpxlkVqPETyhreKGYWy8jGTwG1TeEGL4KQP"
    "syR07zNritfz+B8DT2+wHF0npVIevoQ5K+H3KUztJmrL8yINra04aUesllpYIfDQ0SFkxt8yuL4QOj3ADyiqq59x"
    "rxmZK+7AZQhkJhYBSDP8Noc+ZsQVVrLMg+X7Dw3xOftvOvInKr5+FllSkKIAUp5AybZiGqRPhrt59EcwWQFzyznn"
    "nmGFy5Ulhuc9gWcFr/kYX3HzAmktYlWkgnWQTUe9fSJzvYpoJEmG64+KXOoPoQsnsy2pO35Ll0a4PakQTvbsCEXH"
    "36bJBDej9uMRW9t6I8OH/hRNtm9lS6dYVsF2xpZPjiOPrfUns8ZtFi10XhqAtinkiKN4P5gMphHaBeJ7fxqsov7p"
    "1w19hLx5YxlkAymx499n7M57Fsbs3UsqHtE0mMRkMucstE2Acs45b7XF8oH4EE1QM4Dp/iSajbnJwrgFCxCxcaRL"
    "Qaz3oPgqzPzvFopk3vm6xbINlnMh/3Q4VoYBvG0x/FwYTuAuPxk8HZaDH/3RYhAM7Hbx8cEWxRtAsQr050Ct1f7d"
    "4nazuH2O3SvGeJw9yYThN2TFVZCVjyXdkGSE29OhCWb7LZj4k37wBLh5K6Y+dU9JeDiyRSG+kg82eYMl7LLyDw/0"
    "QN8LJ9MFNJigz0n0JNvpxVCWGHq4MUeihDinLSrLCV9dEZVmED8hQhPPhJ9xC74GfGYh/LR7NESIItgZ894idrOI"
    "zQXvE2I0jkZsNGwXs5G32NzoNjXC+OlQqjCDLU6fCqdmID8dUmfBXTDhrrlPqGz8lVFqAvFTIpRdFNgZCHJvwIwo"
    "Nd0TvqhW+QTYXcxYAOKExZsuc0CRAH9CjC4AHONgKxVteINm4fp0OJRaLwXmYfzW9gh9Kn5bCOunQzHzbrBjuyer"
    "3Kts2a6J7RK4N4bNeTSFV/gfrx8Ngr/v37Rcr9VteJRc4AKDiWv/ZEF+F5Va3T3P2bMikCyaBLkBZM+Lq0mkRHNh"
    "DF0wK4oAk5FimUiwAXTeJ8uOhkXhu65Fow39cIQYvfcng1F+IEJirmUT26iRwQqlbwiRgLIFBWvSbUQcfguc7+H8"
    "XsKaYy538yXIN2AvFUjxKvAlWtGjYPItGAF3WY4uyhuB36TxlrvWl7W1i7nmYC0cJq586cARjIvRVlW034zgfEYM"
    "LjO+v74d5/didPwEDGSYm7U7+wobzAwtOwzBd7GMct5/B13h7e3kDjHF5uJNQKwAnCwJfp7P/Ekc4rIFvw+DjJgS"
    "++NEGGNBxSnMCDdW5h0m8UQ5Jj4KJ9YPToMhWz+v5k7wLaTsMx+BZz2AjIGpTHDOASatGAVxzEObiR3CPMYRyiLz"
    "yGHrpmbZi2G5NB1DSUx7nnjJA9Dl95j04g4zCK2Ill+G/jgcPYCMGM3/vs+ioOOJP43vo7l3H8aIbtg/4kmMUh8a"
    "gg5K8PFN91O9VmUiSLV5fV3rdHIPrzLjgfz7DPb4ALobK0vqsYfh7A5CMSRP53LJSW508jmlJbo1f2bYsXIzAuR5"
    "4Hp6CxKenYQdcjA5vQVyOltJ873D3XQduXi5F5H0b08dhhvDe7OyIZA0XfQwVQIdioxPr7Nhn4Ay8gKgt7Tx5LSR"
    "yR7ybKSQai5DJbZs4mVIIQcfr4ImtgziL8ggknMLh1zi2r+lhCekBG7OyuBjo+Sw9ADg+HLG4WzGEPhWUQwzGfn9"
    "gLALqs4eDwhCq++3gK+PO5DSapzkUu6nPh4s+P2WCF6SCDZ5GojUjIgWL1lbnHseiFSTtzX3Nwu1cggLBNUaenDu"
    "Az8Fvp/ndBAb4jVQh8CbhtpNaZqbopd83rKlmL8UP1lV/tiSx08hc2yMTraMZMtI1lFUt9Tx5lXXBNH7v8i/KWlv"
    "Lt7Vm6uPiP9oAlAeAoiBjgaAAAfzUAnCit8yKSQ0EIeTu1GgqzZ7dAGaIOL5ieILpwreoSeTKIvHPKG1p6fQF0nl"
    "ZUNWL4KnCJZvvz6KslbkJVt1+I3zlWqzcVGvVTspT5/kea1xC0pMs/V5meclls1gkAEaGI6AMpPKG9J0mJcmHIup"
    "jAPnDgskAHmL73Jz01iSAXO92ZeEpdJFQgkI+8kCuB+ejEm2YC1/abSY7Y2DcQ8wlT1pMuuV/l8fnTxXJBaCKz+x"
    "9gMsJcMViySi2QZ8JFYgkqW5pLdk8rrI5HGS61LKwOdbzvGWOccq7ovrEMeWY/ylOIaQU/c14XZFYxi6rkrRU+RT"
    "pDSQ6WtLSgApmsSo5uTd0TJKwboyBGmBWubS90JelVS/oH/vww5YxNB2ijVUIlimXDSNi80+OhPQI/AKejTckxkv"
    "cxxlU3fVqoefVkbtee1kOaTxSGVXIYmkpzTyc5a9dk7STdZw4nNmPMjJxJPIya6YkFRfsszimoxXVKJmqY66GdSv"
    "pI1qSMeIoV3p4m4ggTUo4BUxBgO6wskg+PGRZRJnrADLEyLr4P/FAlRyXVSWpCC25VvoO1wlpoy+8kNZKmc506AZ"
    "PZ3qaqaZpPaedUAvHLxOfxRhfUKYM6avQlCFE6D+2WJKW23mT/r3WauYUu8QIeKHMwCa8IvW0oKJWOZnZh7hBIsW"
    "zv3ZXTB3FANS3rkgcJGJnzhNFdikvv79suxBdrduMD4r4eoEk7twYj75nxdd1VJ5r3pwqBZXBRq1leDOHA6GwuS4"
    "xRDcEGJAMowwBxxlZl2FZRdz5VdwHBNzlGMwtYRWCfIUPxJeaG/pMH8EIs2VTNfOf6qxwaS2sdx0L4TIg6NTJ1Xx"
    "lRSI4wNRMnvvOxxg0fekEGxsvxNTR4EJjWY4r423+/l8ShVmF7F12RQZARiMWK1oAXNK5o/BaoX7kYpB4xUE6tk8"
    "buu5WSYXgnvR4OGR5xuDXVKEJQdv+XBeG3WG6sk/y4nGTzIJ1NXOMwUgVgnfDQBcGyliT3iGzh+RLCbFGKTRQUfc"
    "M1sZwrt7LPDB97yjlLTfJKq43F8A15WRpVS6NJReXGJEyt1EVJCJ+Jl/Ryd6fkWLl95f8gY/ThW9RFNgtACZfzSn"
    "vB6OffJfVi8Ck4D0RmEscqQYc8KYoL2OpVgDsP7LW8Tihjx/15VQiExuo/27u1nATb4p9ugDYbIMyR+llowGFUfc"
    "9z6sfeMsE3Kwg5RbaWYByzunVaPJaPOz8Bu0lZZcoMrhLBor3QwRyVTZpufP+wbjnnJ/reNTdC6Bwm7eCzdpHgYe"
    "h1cE0WwAr/XuMw091rDA9otCi74pa+eZ/DDv84sN7cGSnFEwuAvUsjQvv50ZRWK5cDS+zYN81wJH1JbWkX25gG37"
    "LZJvdSgZt/EkmH+PZn94JhQ8fi+vivO826Cnw/rbxPC+xDC/hylO+GRELv/yWZCsHPhxMN/s1gbZSZZQZeJFpMlW"
    "P8uuTnAuSrIBKO3wroP/JTC+3dhPurFTCH7E1ubg297IvpYb2Vyfwae8ixVUoPuobiXw55LAU77B62KPxb7R1JN4"
    "d/ZTjyG4cBtV1+s2ap2l3lpIqgwYPHOQhmAOJsAFoPYhYcfOyF9M+vfCE6ePSSpHDDFoc4a9vMiq15v2Co5GQcIC"
    "WONch2DulBMN6RY545tD69wTsfFqwj9LX2D9QBVQYuDrRxHBHmsDwv970WKCV70Po8gfFJ8HDLeImEcp5I8ioOUe"
    "XVsSesUk9Dj/rtUph6bm8al5eO0+yQ+C/H4fTBxGa5Xq/3RrLfecnyXR/B5krxAkwdKWoF4VQYmzTEfx87AlI3Hl"
    "R05uyWvLr+xIKkk2MPLDsSd0iGLGJT7a6wWUcnJLam+M1IypDDUCeE62lkeDS/jblgq3DG8VYmPPSBPdKodvXzkk"
    "RD4Pm1IpZ6sVbpnOCqSDzjNreALwI06/TUCjHV9kvD3dXi+hbdb5YNM0t0Sq2pLclretQme2NyucvMRa251Kq+Oe"
    "78uQ0C2VvRXG9tx3OiYyW8LEtlS25WVIZM8Sc5u+2P6po235YleOs90Ey/jXwp/5BE+PYjLtkMjCZ0mQgW2Q9JEb"
    "HMKCQRzyQFD9r14qVAv4Txz+O8D1MLeAxYwSJrBa0OQZEE9hAUFSyQ3L8xRExVKCBYlCQQtxJpYkAVZxEGwaMesi"
    "+DnjpIt27TZCOi9COg21J46NToLu9oHkPcCvF/vD4A7obfDWY4rEROffI+cbHboOd0dcIVJWACNZlsGVKg25R2Ah"
    "+dOy7OnycEoR7vvC0UMYSClDKP+vEj9pjw1lTcVOUToQN4OOnybSTsKQB93No7l9+h8bJCTx4xrkHoMGnuqWQmAx"
    "qDKw2BlIcPaBxhS/NRrt4RGXbOTnxc0w/IFFYYNJNGYy/WYjibNAfARK4kWvP/Lj2EsguGRrHCrs91VvkSwanOPS"
    "/tnpfrlUskeIIYTdoIVloej5s5m/8mZRq2nut9ybeuXz0nq8yY3KkM5GkFEehGiblydtY5nR/H4/oJwpPA+ZVg40"
    "P2WvTKSm510lQhiGs3j+0QHhC+/ck/K8prYAdEx0AsJ5RIlctVxoXJ37KFzrgVyYSkbvQZMHOiJnXeowpr3HimXO"
    "7wPYhmzpLJvKCnnVdEhsumTwKvSy/A7uBSjGUNh0Sw6PM+PoVPAXKc2uREeJ6t4pyD9f3fUCdFiVVNc3JIDA52WR"
    "t2z8r8fGUxRjx8RfgGa2jPxpGTn98MTnS4vEb8XAt8o/DDh+GsLZyoN/QTZCWb3X5CJbSeTtUIwZzU9COluR5K/D"
    "S+AJ4Gn+sM8esB9PmGLrhRROogSao1jjU+TPEn2voyNMI6DRB0p89u29Nw7mPoDMXxUTSfIjJX3iS1tqxwuAfS8k"
    "n5f+H0Ai5CE0wy2xJJFCGhf7qbwhWTSk4LcmFvAn+9MD4N0Fs+ksnKyceS412VeJG1jpXtyPpsCt+FwxOUKy5qfY"
    "JlnIrowmrDQGi/GCbyGlNtz/hYLk/wAi+/v+L/I1PaTiJfVK7dprV5s3rlXQS+IpJPoyRjEIvzidKPl9P4uX2E9L"
    "OOLu55HObzxIDFHn8QM7c4XIl0B+LtzjTSxnD5ejFiCZBegzgYfW/Sxa3N2rp6Y8BlXnPRuykMATeCr2dpN4Uxe3"
    "Di99DHnYRba8fgIxCEtvkCQeJ92sSwjudaXRqVV/Elah+8mmAlzfPu/4slo0724mtUp+IyaAe5oZ2ND66zOT5ZZF"
    "/YVZ1E3Lvam02LXfTb3S+FnkGf5iT5VznTB20hAAdE4X859I2BHNvenInzyLuJMhoS1D+cszFPfcPl/c6ycE5rUd"
    "e/zBz6chSaZBaHw+piHIZMsx/sIcg++u/V/YHx6Lbht55dLg7+96IfEPea9AnpOoebCk5R92biv12nmlA5QkSar5"
    "6R9uteNdu9ef3BaZykw0de2wIL6YIYaPGjuld++u98ofneu/jYLJf2nTfcen+t9ZQymvuyTKqQF8x9Gcl/EwkKMB"
    "lSmK4wGIPKyPRZz5M5Y9do/F/PUe8EIgqdCT3c4corChnUEQ92fhFIb6KHtFwymFpxAJoHgk++o9KF+84w09Tisg"
    "NuHdRihCZXKYSTJ6+polCSUSlBlHi1k/MND/kxI9mpHDyR1R2ICVXCIFLUDf8A9DIIdgd4c38sbRACd/7rarrdpN"
    "p9kCFaoOhAYUd92td2peu3oFOhX0nkAuuRCb+vN7jBJ65rNXmwwPZcLRVjkLtD7CeTC2+lzDvtKBzMJO23rmPzB4"
    "Y1Ae213QnCKgMMIpDrT9gJE9wcSptKu1GtBnPxxT3eO7cI63ZNAaCDN2urVG5/BAljmJwztWbZnU76TcARuEEZ4c"
    "XeU+DuIMtu0s5NTFpk5Z8tmk2AMnC3chMnzRe/3q+EMgaG4+x5AygoBgPg7mbBcLZXyINhrvDK9HkaDDiTNB1gPn"
    "iPgQ/hsQpxaGeU+BeKoUFUZjim2uT8+Bj5EFclBmISJhgL7yixmChQOQ6Ft8P79H1sDBLTsSpaypJd75VjrN61rV"
    "+9RtnNddzq53nXatcQk/K93OVbNV64Becet6F7W6u4tIPHdb8Pvcu625v3mdSuvS7VhOKilkJovkMWbtyQm13G7b"
    "9WrX191O5RPMod3stqqu2r/5W321iDHYO/9aYKJopfY3jqDxaw5fNKipY6DK6mFwqse4Pp9/9kBw4IC6m99nv6Xz"
    "W3wnRJdoaOgiVj9W5kOqMnLeOT8McOLDWfRv2H2HpT1qMvbns/AHLcuwASSnUkdQjWnITlccxjhTDu7sYLq0TsXW"
    "+aGR0KkcjayafCja3EpHImF+NPRS+8WnW0i6nae5xLC0eKgtQ2TqF5nG4/twime9rHWln61MBk4RmV7MkfOeMWYa"
    "X0bV80jyEwrYTqiRHu8PHiY+yqMZAeZu5mMA10dx05cD+3EEPGx+78sP1Ncx84BICghmhIjkc1GGVhyX+gENMja6"
    "ne8648VoHoLsTbxgMSE8OmOWc53EoyS+UJwqmWHp3Y8gyfzK3wCF9cIBHF6WZ9osiKPRQj0OEO1sjxUsmu6v6dtv"
    "AeLHn8A36PQBoKBhcWksektABRg+sVTp7sTwiA47f64oncOSotkc6wpi/NWSAMcCV390KOG+f6pDyUtWXtXi+Fn1"
    "VT5Dtlj7MK50cJqpqqAKvnU0ZpYBgf/H+184rwCKtskXWDYFTFcw6c8CPybaYV0I3pTxqsl1ojGX53shTPJwQScg"
    "lYkDKf4jnAKkgOD31dQwJAHGTJh7ZFqG93sc7eOAtiywr9wqnzrKVsU7urgxXzkKx1xv55Gf3CvYd5NIbDE4WgPr"
    "gGKAtlhEUYRNAqXVgYz7Y1um5pWUqeHJX563Sg2ngefIVpRe38+crIivdcVcRewrj6F23XrWHKPPmNCmCLHbfDY5"
    "+WzSQHvidDaCKhQKW6GqOS+MhiQS/EBLezgHXX6SFDtn508OXeQkWXkxQkBQI9YQRzP/+x5ZCUTOrbXqnrOsXbhh"
    "//0se1vt62etc54mvlVyE2mEV5iMxQTKx2EFxO1ogHpzFBZmJc3w3Jzt8wqOSaE4wnT2mMooB4wDztSfZd/osEU8"
    "Ca/2eL9aaTQbtWql7lWb1zeVTu1TrV7rfPbc80vXu3WrnWar7bXc24PyqltFCasZLigJWW5QzZPLK+TLn9z/3OGl"
    "GZ1Swk5ps0VuZhHIMjGmxYSv9vrR9EGECRSkLJKmNSwT6rG8YWkcdFt1r939dNNqVt12GzDR6LQq1Q7BvbSF+8pw"
    "R64TL3rQRx8+9ASkdai33P/puu1O2/tHu9nw4EfttlKngiQq/MunW/ivCn9x9Hj4y8O5AQTIxpmHifZNs9F2vSu3"
    "cu62PPd3Aj/6fGlbYcuC1kAFyzTq3VP9Uy/4QTAn7+BVcbE9DZ4KFcZTgV0QeudepX6Jl5VX1zpjer9Fwaoo4De3"
    "A88f3WFQ7f1Y2wUU7QVy2f5Vp3PjtTuVThepHaBeBaGoktkEB4/HAGqAi/j1IILnNX1SLNzP58z0uohT7gNiI3jf"
    "Dg40hADVN4AvtTreTbNeq37eFPj/ahsASH0S4yUdj2zUgExSqNuqJbm6tsB+DLBJCgVFLwnIEUBXNOX0ZTRC+LJ5"
    "67Yatcald1Op/loBRey60qhdgLBKqDi0QEV2NnLRHp+0ZvxeOuRSL9qNeHtG8JfPPeVId5XmAlrzaIk9gGerN2rE"
    "ma6tc9tjoDbOgmefj8k7Tn1C5gz42+9TNHG8L2ymntKQv1xWsLMYnjYdv9iC1iORoq7JdLyh5Sgx3DC8D/ODzZwT"
    "Pp80WAtLxp7s7vHt1iJTYWRfWqfFMCckMHW2yZmL3BEM5FEP+OM3f8k1i5i14mCkfMiyTpv3vGGYp1lI4q5jkWD9"
    "QNgt82ec9Lep+eqC1j6XhHueFIn1BsuXcZLkiTfZH5f0/0LLWsHsn6s99HL63NySyHoij+fMg+W4OTo7KcBNur8n"
    "m/g8+iOYrDDtYpLSe9v0pDGiUfuxKShjX08+WY+JwWuRtaGfTc1X7Jj9YDKgywf0l50Gq/B9levjRKjqRi7QC8bZ"
    "+JokO+g9oBWBRXh4M//7SjU2inhnuuOnW4IyzKpFQooWkHSbuLA/3SKCH/3RAu+5rHBwfGCzArXP55i5FfRXnPpz"
    "wF6Lf9nMKWvs8ulWAJo+6IPoAfq4aSf9bFJuFvKM/MPDnGEeJRiwT6VZbBQ19fiE80/0vk0A3tjh02IgRKsV6qnc"
    "uPO4deT29oQLoHp0OBq2i9nIj0OCscunW4GC6o0twdzn060BBJxgwm1Tm+Cc5h6fcv5MfrQ7u4qF5nSnTzjrxWQe"
    "joPH7tpsN083ZXnEUEAmWnI3RvOFXT/diphKZ0c4VvYG3uXGZjyPpvCKYgXQhYqioL1H1zXZYPWGTa7j7cxetKJH"
    "Acgqo2hqEe3CvHPhm0Lzp9bpM65jmRS3DAvmztYJH3vHghOBDeBC2AWYh47LMGW82oumPuxVdpkY0hXA3L/DVAdf"
    "Vxvnl6E/DkcPwACi+d/TATWywrh8ohcZv+l+qteqFe4ldH1d63QkARfm2WNlzCkZ3otPV1yZfDFelz3n/IrDmb4U"
    "R8+8hom+HlAWxpB8yY9N2OQcXw5/z4EQUXnyWxh89xJZN85FSbXbarmNDsvssIxbaL1vil1sasqvCaovR3Mbm+pr"
    "AueL8A2LEEYxNM8K70kvC/FYJIfQ/d2V1PFFsTyPmv0zgazabFzA6d1JicvJ81rjFvZqs/VZp/1+NBmOcM0Gmezp"
    "prBRml46Lj4vWrWiDzzJ0BtdraDKfY2UXybW+8mCl3MW+UTBzKbC0cs4xmYW9LSxvE8Sb2peiQSMvXnN8edOfxTF"
    "C0pbgxdB6O4YTubBbLagNC890N76LOb+xVAku3uU3bO4yw3N9DHxiSvANxuqt+bcxcUrFWe3p5/ii92cbteeZr4n"
    "+ApR1kk4NTe2mOeeP9ba0xeWbyXJzaMIuaC/tecoU4EZOn+8ub6g85VnrLibGlxBl5y5S630pr7WsY1pqY70X94i"
    "FsJxVgjNa7myhKKNzzMa7f+id59p6LGGBQLLNKk1x9M41c6NsJwE8+/R7A/P1P/jAbrqgvJ8jldaknEpIjHfcyxJ"
    "2UFxMN8Elsw9v8RiNoqh1HIegSOuzP5kor1Yla6qL1Xlv645CrONsfo00irKfuqmjQuKq1ay9n/JlLbRmPJzTmij"
    "CuTqM6F02zJdZEgZHVP6NEeW3uZ54GSc3auAWGKu1aoc2dwAGcoiveycXxig7BnxAtP2pBfPAyZ1Ji8MFJR6X0C+"
    "2/REXwMUX9tpZJrUk8DpOU1qGgjXFBv+tfBnPoXtepRYzTZlLKV/jr6TPJf0sUQhTw+27qTfoJmPbD6zMEYNcjTy"
    "YAZe7A+DO4DIYC0FN9PLI2aU/LmRYIBUd5uZ2KPNhVo3j5kTv+Qjexil87MA2MHRaRHAsl0+YoLxokdlbbz5/SwA"
    "qh0NlkUJHTpcyTO7DGb786jOxKpzVJ3G9lvuTb3yOeOI9qXYv+zrJkfc6AGgD/WK/AULpml0BXxCDKTGezr404+k"
    "WE7az05doqHV0wz9dKulS9dli81p9CQDb3SpMvKdPXhEtLvawVpV6XgAOAhd395742DuY/zM2oH3Sh9rzsScymBt"
    "2GS7etba5hq55lZb//oC1dY3QsebKff9CupJv0w56ZfBQU494y9Lq+R+fakquS8JJ71M65elleC+vkhV0JeBkFVZ"
    "ym3RwG3RwG3RwG3RwG3RwG3RwG3RwG3RwDdSNPDZaga+0cp5r6Lq289SEO2NVvh601Ws3nKlpddZYui1F9h5NQVm"
    "XrDGyisoM/K6Km28rmITr6PewqsoOfCyGfefO+n8innXE61EdA3bJUKRHj7vdi72TqHPP4IHlgkHno1AFu5HoExM"
    "70Et6cK3qCbSP8TuuKUDU85PAi8QWdx3JnhIhRPky4oyI1TcyQItDzGV1ZsHd/CnwyoK3weo2tCaQHl7iB3+/qO0"
    "LsGEgnEgbS9+THInDoo6HPB1n2j7w84uaTsfWJXiSeTEU79PgwNCAP+TO2805DZFAoziQeTJ/PkJtQKokIPXXbQv"
    "ur/XOl6JYUb9jp2zH5KWVBaATmFiA/D2Di8aP+zwHuA14guAPKekKDsfSmicm4Xf4DwhusWnicJDA3iDaOyHZDii"
    "fVNtnrteqYS9Jb/LpZJ3fHamPas1gPnWzlHdFT3CVHrR4GGfcQk4LeHfWVKpDUGISVH3/MEAOEocDD4KjWo+QGMe"
    "M4nAERyjIkv4SNDduqg6RydHp84nPw5Ojqg3DrA9OFup7O0e+YZiEQJ461N8sKA9CUXxES+16uz93cFFOfpmJh+s"
    "pIWiW1M5ZDjUE9MGojWcLNh30DgVOslqzCFgHCESSQKdJN0gMUVzsS39EWjr97MgcDgCWdnWPQSTADeTxJhqnMwG"
    "4SIENxiE1SqQFqowdhIacgQNfUSanvnfVURI1QDtOCIBJkyS5uFBK04/veDe/xYyk69OQUjR5SOvf3CIqdv792S8"
    "Y2VtM2ZLbo632AG8BedVzCAAfHERYIX0GWrwuhzTB3LZ+YAGopwGaLZmEhjiKAl6LJ4p7afUAQA048nCGXxO6nnB"
    "NiWbygTOUHgeTLGqBqN4JzEx5FDkR0Y42I7pEryG5th/SNGlUy2V96rlQ7RUTeZ7wUQnU7Jw6HOnnqhILdKb1Af2"
    "2GZmtEbE5U+nfA7Krigf7AFUe3Cu0FxN8xd1QBICSniSwDSxFCKeP038Z0tRRori6Z0Fp+DHHFqWAHDv3jHO/SQE"
    "t2tHbrsqYZaP9qrcxvZqKZBJjzoRigNvS4SbZmu72GTCOBgve66tBanHdIzm05ABRXKJYRwvArFzCL2/gYriNrsd"
    "ieLdHXmeehrb5Ks0y/8Cr41mR+od7Kqp07xBiRJA1wcs47UFZs77sEN+e+Yp/FlMprIZCuIpWfLg9NHC5MGp16ld"
    "44QMUuXB6Vas3IqVW7FyK1ZuxcqtWLkVK7di5Vas/LnFymbnym15jWbjn26r+WjhUu8tK1+ivZeuzv7P3w5Od7ay"
    "5lbW3MqaW1lzK2tuZc2trLmVNbey5s8oa9YaHbfV6t6gtFmvdBvVK69y/al22W0CDSMsjOIkb+n+XnVvyOEBiL7V"
    "Ub7MCpec3KLvE1hL4I9pIsnYIuoHhaBgPA2Zy+S1W2l3W+41JpGvNRAs9W67dovRA4rgiALP3SxaTDFiYO6g3yoT"
    "iuTaSbadO/43PxwRQlMrb3UbDfLd4evJX3m6pVe5gG7Y+p931ZqTmxSUpYDHALIKEH5rVW5uYC3CAJ0Lg3TDt7ds"
    "Qpd7nrtENv9lq/LCoTeJvDnud/R5/iD69ZqN+mev22i57Wb9lq2T9it3pPNumjfdOnMVwpUyXl48aebnpaauVb1a"
    "kmwZuB9MZxwpCM7Rj2NnOgORW2T9YF5AY/gE3YcA0qPwLsRTidwmP+yIPB8O8kLobwidkf6APkElFouAf5bh3XTk"
    "P+wl2oSapfUj+x7UgUS5rTQq9c//VMkB0GoiEwork1mfPTHZHJqKF7D8EHSbPHqCuYQAnJmWSpoW8UAxio4oW5Ei"
    "Qh4FISCTHE1t8o9zPu2fY1lT3sypncegsoIwgmQjvHv3FaAk0GQxHcmw4iQhBVRd8ZedcChmTzNWp4hUljP1AE4v"
    "Bz7tRfN7jCtqQxu1+adm50pppka3GFo3G7JP5WnDraF9AZV6BqHDUgkOLpilN4WzlW3f/+yoWHGvbzqfvUqrVfkM"
    "AK18woGg51xGgBjX1qW2bDShsfdbrXHe/A02GNBGXp98SfBa/IW7K5gsxjELWgWBKpjJXAYe2xNMNOKH6Jedynnl"
    "Bjn/tduBPzsVD49uFzDXrTCSzTRw67XLGpzppnefmuefvXP3xm2cE2AKmnYb7e4NejWaR2l3Wt1qB5aqWlnEkkAg"
    "AE4RJKuA9XfrCB8QrT3p5qt6+HYbN63mrdugNsdsot3OxalCptXyCfMMVkfk2ZwC2AwLGSLZadUuL12MaavU65yO"
    "EG7Jcx70CzK0q3aDoSjkgjugaQsm4h2dnXid5q9uw1MRzLxNvatK2+OBj6zDxLTmAV9D19jzGvPXrNRaBV8pk+Kt"
    "1Lkx91Nv4o9pbtnpAH6uMUeMMgtt4GS1QtBW5cwvACEClHtbOyeUADpa7do/qSf0Pc3eHCeP0zY/epM9wOnxEtmG"
    "2lhIfqobsNx/6sOEcuhprXHRbF3TaQgw6jbc328E22dfdavk7q4QvlCyeAsgnBpIzSg6M2ds8QK2E3ECD44JQNqu"
    "kH2JgpWfSL3KTzyq6+6tW1eeoYOv2/Z+dT8rD1nnzU//gMGRTmptpBz+GKEL87y+yXwg33idzzduweu6+zuQUKbn"
    "m1atmv2Mnpp7ZK9kb+pDII2LWqPWST9HhaJ54bUqjUt8xajarV41FfQpD2mLwNbyzmvtDnDpTup1rQ0Yrl6ln/6O"
    "rIBoxKP3sEZiCUBg6LOucXN1gyRsWAgRYpNRsyRPOpb1o4a3aJa+RW/r2wP8B60It0f4zzF9QkEgrDAPNs8ko0wU"
    "7R1lHpquuaNNEHVOFtC4AMZAQ6hdjvnmRtjXgO5ZMi/GHACAXSYdyqdCcmzD3qhd1KriTaZfzJuZ4pY86pv7pmNw"
    "wi0/o0SveAy2bukR289Yn6bWulaeqDtcMjRUVVvn1Oqm2a5RVDkcF0A3gELBN2A/11gYc7fNzixtPtV6Ex8bF5Kg"
    "uXjSEjqZyetv1EWIN6bF6EPweVaA99brsJCitSWrMRpuvkjVQ9O9lJMp9a1634Kfy0MAj81qy+UwkY+rIA50cUZS"
    "q1C6kwIvs3doRJI9E5YcBymIIlTUPaikKBRDgLR1S6Km56mCp8c2O9JQtgEcfZ5HgRx0YJobcdFzeUPBFRn0MJar"
    "VWFilrFxImvmfUHT0xeTnYPWiH5oC9ZeFyxFa7dkJam2yxcix122mEzDHAxl2skH2uIzzZYszNB++eJkn/riLBvT"
    "Ai3byulZtpcP2HmXHK15zQsWq286VtmWdjqz8XIRXED/slJDXAG7anMh3NBVUpGIKxBGVShP8zFoMewRi56UmkVm"
    "NFbXCbMKoKxfwkO7Wjqgfw/p3yP695j+PaF/39O/p/TvGekkJfqXvi3Tt+VDpucwTYbpLfQvfVumb8v07QF9e0Df"
    "HtC3LLeTPsutkP5EQnp+uKmijBZL8rLP9lXlxpU9s2dIr1JmZ4+EfA0vWt6NfJxI4tWm26omOU9TwnLx26yIrcjA"
    "7WoNJ1ThvDMdTppV55U2OTaB9Nwv6s1KhwgS/votNbnUywyVU1QuC46e5W95o+mA4YpZCzhelpkYTOaFtGlBn98I"
    "5KuR5/MLJdPcuOYmbD3yAVmflJ9II/wg09vRC+j1otltKB1eV+q4J5j8ZaK3zFxZ7q1cIC5dPCpPXDNFokqIWMyI"
    "UXHyABsx8xpMUTG27RK7Yg/qdaZftT0xiHwnV8g1MOXVMrKZR38EEy/o30dS07mAoT5Vqr8KOxMqbbgPUrsClVaO"
    "qq8Zm7eEXcpyqZsm0ybJ5IlitDJZStmAlFtm/jBFRUpmo0lGBv2MrDqgaGeMftpLvgz1HDS+13ev1oTrxrp5MN1I"
    "FBOl6eOdhfFO40sSrpo9i4zH0MoqwdJzBx2+kCRAy7uj9GfEXRDUpOSJcwiYHiNjVJEuCYGNLiYyo03SrLuVBj2q"
    "o4FGUDTfDGKIRGNCLpvGEz3Ud0TKtpFr1UjbMwotGfQSt5jpGV8vzljNeoCpyaWk5jELrSdGqyLjJ5X01tXFQWrh"
    "thUrrrzNLPpMPbDPm9coFSpueSLnGxPFKlXsEU/2sqdzPNzDNaANelVDzRMtn+JQ42kJPsn7rzpmzmBH/e3BgZcX"
    "QC8bpCP56UUH5oqKbk5WjGRKPE96Zlr0JTt6ULdHoRgZWoMMbcCoKpcI1UbtAqaMQDFlEKf8aEy39dJJ0l0uyHtF"
    "2dOJ3FPfpBO7s52X30V6bhkzv+xJ+BMkD6SF6apS75AlI3nHcgkyWV1lUYVNcU4gr2QmNZ1FmEhPmQ5HdauJiQhT"
    "M9PfJcauIctdduSlDXZrGOfU7oSJpI8+j/5d6pTmVhWkGfYX5x2A3Iva7yAzAoNvKG87V61m9/LKYyW62kj1SGCm"
    "AUW+NGYmEuSkm8gwgaKLpbFRR7uudcx2MO2lmIm4kTa9k5Yv44eNyk37qtlJvSQbGDeIXbnVXxkPqDSAkJq/6W1V"
    "O2aqLTfnsZwt4hMNOnqa5iTNHMBGyRpkkTX6Hcsrp3yUmzs623R5Bul3PO1vMnNROZz4eDjksyLJQU0jJOGkJd8U"
    "p49MgiuTQP6GvAxZJmxE0Czdc3j26bOX9CkbwF4VXydvgSO6HtomGdetIqP7zHNxylElQUgtVkpLKG/83vES80Tz"
    "uknzg3MA+SVIxiAINOEnI/r0TgYirZ13XWYy5fl9pbSKnhKgyAgRiYyifNBW5byGF26fveZvDeWek391Cecy3Rue"
    "d8lyAXwb5EEjPpLS9ZhGMTlmFRihUtLSkKI8kphQ3BKSZxIpWfCaAKuAFH1FUqsxL0DwhmTCLFUrCCcw2iXvVuQZ"
    "Rzm62qzXa21+Bov9LLiRB6L9r4gmjUeJp3JlLHu5NkSafBJEJvhPhNI015BIZfPSqIQvSPkW8ZnoufrHRihFvTiY"
    "ffN1mV1I2op1ra2rA+KJoGeNksVLe4qWjzTS1ihWUXLkKtRidQLdDJyVqiTEv+LZIMi0BXuv0k7tEBOXTolnBokq"
    "JXWpHUbfJ8q3WaEQoN0iywHlJgcNolO7QFm9CjRab17K9+dAt9CEcE1CYKWDD5jvC28jNxomvVc0egHiK6AXYn+Z"
    "N0KDpYNDvk6qgibPshQDcBSJuVqcQQjkGl410PRX18lfdi42a85rI5dOdDUDzNFdqB9wf78vy/ovnNtTAGMJ/PMR"
    "Z0MN69NaDh3Zgh8TG8PBGM01PS9JHtdsdhRlhv+Uf2o9iQS/aiF1vPjMCiUgRZx3q5uSajjrTozBCnGaZ6jmCsdT"
    "AoHL3XI+15sVUnU4FqUemH3kwTngVist5VUNpKHfcUrdTzA6o6DrSutXNs/MQ6UHQVRw1rot0UYOXfC2uA8xIWMH"
    "fF6575Su6+5lpfpZkr4ytZw3+d+KKX1Cq6qAuFcju1bOY6Uz9jrZi1qNlWXvlX4UDqEsxvA08w0duvovpY2By8AZ"
    "+IlbcQreqngUTEj5MvNMaa+yQhRtYEbN1ufcF3lfSoIwPJXfGPdTkjEe97uAvULvElxbcUYXZ4znmA7kVJZ/4tOG"
    "Wg/IS/OKPRAkc6oxmGpAqOPPAjRSzGZU8YT7c6BsjuYRcTFyg1Bu4znpgZZTY2LW5+t6rfEr6hWfaufnLpMnUHy+"
    "7NYrLTGvWttj14OMYvHm1EPJObGSXVXaV6lHtWZy06JMdBT4cSCMYNxdVAK+8onZOhtNdHG76eqrVCwOETNKp7Ut"
    "XcUyKVYZnSqrTlE1Lk1fYtd60tmInKjM2hFXivRpCztIL/Axj2aOVel12HZ4KYXkbgWn9ulzB8gSbzcI1ufdG+IZ"
    "rrhYVsBeqdc/J/eHnYyw4FXOm9KpSjn+ASAYyTH5hrFlqnbI7rKgLRfyvOav+EE2567xxp9f1H4C9HrVVvKAXQkA"
    "7aMMh4JJO3nH79jppXLRzl5e1Ny61CVRhye+qb1sVK4NHzY/tWGb1dFq8Q95Oc9eAbVfcCc3fnf8qd6s/po0MF8o"
    "Ja+vKiCddUxv+IdAxM1zNuF0k2v3vFZhPafsyHrn5pfp/gtb0SDiYpe/+58us1RVWgA1vK5a3kPiESHBp71nN7Wm"
    "bmDjdpqAM5EC+LbWrEtmnqUoSYNyIP2eSkIwG0OQP+/sdWG6mxWnrtCtIbiAgpaynrnk25FZz4bdTpq/egdJwonN"
    "OaF8VWKxDF6YSWQvLrByW2HRmlqSixUTYdBw01k0j/rRiFuxgoEYbL/8TvQGf5bFnwfij0PSkH5tNH9rZDvjZTAV"
    "axhHdBo78gX2WS7TVm6i4HSpvjRSdn52bp1pqriWgauAQuHvckS+XcZW8Eq0UnGealVK+ko8PowtmcOQzpFT5GeI"
    "7kXnX6GIMpbKesgbhfcPpPs/3UrdYtbS9q4Qhwg9+w5nKEVU+7wgoTglLmotdGVuQQ9ep60EDIgQRA9OuA7z9GtI"
    "V20Q5ck8zP3s+UjcSi6rBgnpwf0dmCc7Qy7clhBsKi0QcjrcUwUHBj3hHMkQdDAAD6gZis1binjqQ65vfGVVO9NO"
    "MuQAkyZUepjnH0S9YNhRID0LHulQMAZ4L2YBBRSIaM9khqbQst3cOLelQWsF8W8wlUnkaR4qFKDP8vCoV5ZeoZeK"
    "6X3lhiQuxsWM5x0VCMx7SW5Ln5rXihNRUSttP2XbAZHSaAgfaI4LB3F85vNakuzul8m2AsWapJx3cZ3TSFxZUxRD"
    "ytBIWzSRqGAmU7//B94Qw+j8Mkm3EmOIBomrKCO7wB9AKm5eXCQ2PGaRa6lhHairqZ4L0syntBXWMmzX7l7jeV4B"
    "ukYbCn7mVrhfrXxKFu4ORyn3I+koVxGcM9AMYKnIHUAUa1y6qn+G8LJI5iaf8YC5arN1QycsPxhUBwx+VGgNCYTa"
    "Hr9B+S97GtHTlJ+n/pDzHPYw8Y1TrnXoTRK7lXnFDv3U0/PUjuUPhfMbXwEvpLQZRwSqwwBHdghihuYUlc+65Ffz"
    "cBwALMfTlb+kUyV9V8acATPYYI9TgGEP0ZlJApA9UvgxFz+CH1NWm69gfha8WNb0pkJ0X3aCyYCthXwEEOzyyX0U"
    "z9XfWL9D++1TnUeSXcbB/D6SOSOk6CSLk1JisNkfVAJw5kPrgEd8UkaPmeFxgDcZ6YcUgQNQL3hDJxeV0xsEwmuU"
    "NyW7j/EN70S+EZ38axHM1Hai0AcvudRHDiqLh+zu9LDoH5XJ3GFVT4GupNDBCjiSX8TY/0FUB/BBB82YEuP4Uyzi"
    "hI8pw5d8MwuQT/ajxQShj3MZjWCW8Zh+9dFckTRegNzrAXeFefHV9hfxPBrzCjgxZbiL/ggD8XoW8BQ2/Deg7gcQ"
    "2+RbOIsmY6Wf+Sj2QPVPPDJ2KeMcrUWUNOEKmvqIZaJTHiU0qF41m3aS2BLqYaduqnRPsDeWbWD7DSJi7le5BJca"
    "mXJrnfSoOMP2fEyho94UpRygb0Bi8bj7XcbvLs9TkH3FPP7EwaidO7ckrR4cwgmNtpXEK7BCVwXswkx+YZy5GvlO"
    "x592FmpOJ66Ku6Qzbr5id0fYU26tHqpSo5cN4vvHVHErGYHTEtaFHvAbUBYuTtZ7QQrqU7QHkdcBigwJjbDfKTdX"
    "9gxOAu0HgbBea3fk02Qk9psTHPshSVOL0211SbZofpJWejlFfNwiOxneiPL3F6ADoMhiXLvIx5TdR9ga01AtJnbh"
    "vfhPhf79hP+e0AUsszXysTEjCo8k6Gkb5lY4mIuoulQcWipSi5Jf6OovVVPVwqWEK6/iQ5wSwLO9jIFdEm8WejQz"
    "9revajeqL3K7+6lar7Tb2Xhr1WFZicFSHqsqZKVRvWq21LdSVaw3f0MTa6ZBomgaXrG9zKlEeSPkOOA2qMTJN1kA"
    "kFvmaKTuX5Yli3ap/iE7tpTr53SsKxs0lYmmXUMZlr1SE8vIoFY1MatQr5UvyZYv7qAqnQ5uO67fcLO7eJgzSSXC"
    "IDdFjh42rD5OPuo2xGc7u3kZiXBiICq3xISVOcVaDT6e3EINI2AgSjwMmGCeWOxBzG4zXQs1pwZqKnQly/MoVCt1"
    "unMUuuDSWC4ZPqX0pVr4uP1FXUF+npPEKZ7aa75iyKZnUTTUfX81xTg/yl29vWFhD9zGo0Q3sefSwKN4gMFMwsFC"
    "8UrsNuTlCbVTg645OlO0oNCpiD1MrCxsCFZLUGofic6SXKG0y3qNSx6NUUUVFXg57wgrFI/8XjDCj+tNcmml4ETu"
    "aa9n6ck26FzBkq7wqmJpU/gP03vbOLeGe0nXmcam57WLC1i4d9FqXmPjTy4wq2Qs4zftCm4bjxwaSXqAo7NlbKk3"
    "AWZGGjuGzNaQd7HBEdhtos/ENR4YQ0tYsIXT4FeRGMLzZWQuET1uIPd3ija55Fr7tauyGVUwkldw2h16fraITLv2"
    "r3B+VOoo7H1WmYmYfDpcQHHE59PPJubhRCuYnsaNNJ4DnWG4CVkOWrWm+pycA2Qoi1yG6hh9XmuzzYjL5yu44PQv"
    "riko5U7zxjsHvshXhqqqjJBhfTDuJ0vH+/N5MJ7OExnXwI6vapdXZLaRbF7didm3JuZsaKYx6+xr4DbKEYIiZxB7"
    "WOcxSS6RGDpyoiClVxpjIDI2soYbTH9IQfKZqMlMjCGO4SqRhjg1FjTUMwRnPkcwJi4dMNyqcczqs8H//sCEgzgd"
    "KdawYFhaMrq4tFWRhyfEabj0KvsmkQUBQ+zoSlnWeZzcb5XWdfdGmxPzXZWxBdEYeDQorQQqETWVpItiTiLK/hVN"
    "4Fird8/JRqW2UEfi2UyZDQq6x1xwmGOOaqlPWFI5/GvfT38Ws6iHmEfXrrbEgRdOpovkFuGmRFEzIINe0c5AcRX3"
    "dkWr4CsEyi47T4WTCuPKTEYlxxF1HBkgyiit+asUfinLliL8qF+B8jUIUpdUMhqcB6Qq9ynNbgc2syu919SYVSkh"
    "k7uC1nLZa55tiQfgkUH3nF3aKJoFlbcXcyTGlpzbtcZNt6NuTnwtyYMbnhNNX39dhb3UyX2L5169cpP7ngvvea81"
    "isxpdc7nn/cWiCbvlXRRzWug0FFeE35vJgPmc6eRRmKqGxbVT1Iq92YDmqvXuOyoN+aCR95QzDepEDMAtHazXgzW"
    "JLoxt0mCZ9LP89CowFOr7JxqL90l2cxZPr2rdCtxsLu/u1WGGuPg6aj69M0obyaNUMKeoCs61IbfRDDTg3HmsmZz"
    "HrnwBnSwtvEepda+SgagWFLWIvVdpgx16n1uWfd0P0Re0t9OXg3lAZccwTPvlhdPN3dXVPzdtKB8yqML8CJnExGZ"
    "cem24IDN0j+ab27fg5jvuv/M9N5wO781W7/qom6GYjI+p4rXEuesPM6T+fUa+WdKr1+yMzLOdzloUwXbPMzmpA9m"
    "a+O6Qs6k5eskxKFo1klvOdOms3VJHyzXp7gGVKTzNIVLtbC4Q36XWW9eohNm6h2IIsRygMLQQmH4nL5Dxw1splrP"
    "iOHlxc/RS/0CFygHFcJU99r1ceJtXdQq7766qGVyaU2t8kPXTdsHIzdMCyyKUUkDGt5KPkgN9IB2fY+hhbp9UzEw"
    "b62Z1PjQ17AFhyyJeXnfcF1RfJClEsnrhaGG220K55CzMfTVuaDtV8kSVGld3maoKM97KHnJrUPyTMvQoSA10ySE"
    "MJjWvvPFwXxJMFcILJD/8kW/pVJfrsBnlvWKxLxiCc9CuMuX62xFunxpbpkgVyjDFYtvyyU3e6Ftqby2XFRbLqUt"
    "EdAKZbMisSxXIjMKYwVymIUIZiF95QheKwlQ+bKTWSDKk4WWiUGFEtAS4cda7ikQeYqlnWWCTr6MYy/eFEk2xUKN"
    "jTxjIcrkSDHFAkyu7JIntiyRWJYKK1ZySo7bXLHHnXKO2VzjKje4x3SddEL/0GPM4Hh7Sk9P6RbvFGd1e0adlQjZ"
    "zDDJqhoxly3/bhYE41RyXrrqQAc7jJmVyaiqSKiVywYsE0B8Diwu0VX4F8qdCRJ15RJ25LXWg2aRRYOplvJXm1o2"
    "C40cR1xCiET2F+RYJ+uQJ2616S8oupV7EIi0w+lxWQ2PzKh09SOvRrSHaf/UeNFL7rBAnmSewDgHliIEWVPlWpS2"
    "xC+wVGF8H40GygUoHwmphGzr+hiJvxuP6REDyiyLjQrLKod+aBfEDS/pL/wYyI0ZguVwalI93WievJHXncYMfNDv"
    "Yj48Tbqky810b/RQ7Cstz9/XP00pt+Kny7lVVqwS6yfMSqd48ufRGGtHPmi1adhTvFodR9Rs6Icj9JD8sFS/cc8/"
    "suKVTvBjHsxgKEfxA3aIaB3yA+YVMaM4xuo1H51RgKVX5CXcO5YPwvF7MTT+6MwWE0d4cvPqcDZJrajYpbpkh2e1"
    "wso2fv8+DL5R4akEEIsJ1qOJZliQ6oOt5vdKFq3NyG7hMJe5noiDVgJLnwXoLyWXNHr4iLX4sNrfMp9rZx4ZABAt"
    "5lQBJxyPF6y+IB+WKg/NyG0BxhhEVBPMH8GwDoPH/tifhEMsxiODHfbZnfY+XxSsFtYzkz06sT8OEHywKR3/Dmve"
    "IqfrowPXcDESbFNdN60Yn/Kyh7usM0cOuUs1fzK44nVjGQEhmJzv4fyez9wBRgd45N4NjiGJmzIpOlhTU0LPwgGv"
    "vkgl855mOnRrDCztbhT1MJXWKIqDgceKUaHLPHqSfthxAcQPasleHnDioF8uVqCUESh9f+6PojusAKzVJuJpwWbB"
    "cJd+A/oGi34wg8XMcTPEc3oMzAjvquExq9fU92cDgsv8YZ8cYvdHQA/9h/4oYGBQymYhOezPou/7IjKYyhDjSP/L"
    "HIPfAdRZoVxyZJ0GfSXn1w7eXHtKQjH0kOUlkdDTG8sLxcFc80slB8jDd2PcTuQOylbJShP1/7UIhU+Tj2cFhil7"
    "mIOMChexVKmUCwcrWSVFJEUWVX8kyjGi4EN98uR18Jco1OhhxSryrRYu21N4GiBhUfQ3koQX3/sHxyd4BCATws9Z"
    "8iJR+nfnQwmrKvGQvGZLHyCabGaM/+z8nQbCoWjNomjzlx1RDpNF++LegIFg9d9C/pvtZ/Sa1jvFegm8crSnApw7"
    "fnKvcbt5Czz8x6JPaIRA0QpOMldg4Qn8p9WwWj+s5Kbo5qqCDf7cNcAxb+guyBsnR/gNh5ep7RSdJmZI8P8ftvpS"
    "2jvz94Zf/3Ny9Of/s2NYRQo30GVSSlzZLWZyFyn3lgNLx7g6ysFhQQe45PLJDqOpUeDhjhdMC0C4BzB0oqFgJqIE"
    "IfBTZBjkJE7HpXa1/9HB62leaA4YkNMLJwPOzRxGBYzvUW1y3ucenbBiSNgDs4DK+klOiQzRF13yEnWz0Ked/WUH"
    "QeYI/1M4CQNWHzMcY3nAIValo1yGewRV2RALv4dDqkw3l4W8d/kcdx2F7rBeH8oUIAIkX+CgwheP9rrYAq9kR6ZJ"
    "z5Le0N+Gp4YgckgOAKQrUePcG4BYwcsIJwtX+MArAQJLIKLmtvh8Q0Z/YXEg4hcFzih0I/Z6UjEsOmqUQ1uesqgO"
    "wMkPW48IE+A17gUDhBeWiIaJMAnB4aIyP9dpE8GIkwEc/pPAICns/Pm18GzLHgo5acNTXoj5+cOZB7hdbOdqtQrN"
    "JQq1I0Sb/BKWXSY2b1zfSl8KEKz0EULJ6oPcYpCrfrz6ApeVjly1D1lU8j+PPVfSJwodArnHisJxWEuST8NYUR5n"
    "8tDBw0XwKqy3PnakWCvinfQjBBjOHpaTBa6DKhbzBt9jx6jDKBN2Y+BgVV5S6ERLxjNgR49RfZNciUWBmY+HN7g3"
    "Cw8TjXtu9hB5g6DKHDmsUpqwoKnnDfDqkHvlI5iC+C2fOKkCFrTx+UGcqW4BOi4d7/K9KUxE78HUIreb4EfQZ2Fw"
    "ND2znpI/3yIFRWoWxUuy6mLZqtfu5DGTyYGdRR9vh92b+fLboGAbVpxhLJvlym8DUCsw4tgfBncL4KobYMDKOxhd"
    "WPHKFAOOxg/ZS7xvsJftg1YU7//CdKO/7yd17vYzc32HRrPV+bRUu5YqaEwIinW2+QLGkczCn8sukoAAPsXA+HAe"
    "YOn0AyCucKL8ynQ0C4bQDyLoQ6p6NoZ7zgY7CgNSymrHj6yrzecvpJvFJIRNAvosPFOLd78lwZxjQDOJz79HDoNj"
    "zO3hwYyL7A4ucBdnOViQjM76XAZT3r0qvP/t6Oxk1+EaQDBZjD/kZ0di1nQ0DyHjFSsz8LF3evGw/B7xWkBjbSED"
    "JMtqYcK/aQkHR6dyCaoova/Ix/sp6XnfJGTvCqTFTqrCmHnprHwmqUfaaSBCMp1Z9D3GNQK3C+8m8Fm3c7F3qjQP"
    "B3K12i5m5rvYkVcRjrx+4g0YczCc72txPpvjVudMGztm15rvCqeezpHetOqh2+12d7KaFRp7EeB97gUj87TwIwH9"
    "EvzRQmRMSSnyygOKQwzmiSQic5qIpvJBtinOOGH5BqEmcXOVaJfXibqUFGNxF5H+RuXuKS0nY9K0OayyEOVHS4qa"
    "TJC2HMKEotxBTKhbYoA6pQ/5eb/sxollBPlTI4L8ddBpINahkU3+NZbVnJnQkUdqVmpcihqtBswjWLsBC2naUvVU"
    "vLvtoK7vlDzR0rh1rKak7K6Ca0Y5nrr/LFegfpLp8e2r0n9BjpxiwjaSA/tk09r59jTUEGEjEgn5JkkLS1kv37JU"
    "JGdHmTs5Q5EAy0Cb36sK1yLuqgyQDf8dJBnhEslC797Kp2NlLlx0mOQ4fNh7mKRWavWNAgwLV5I3pGar3magm5FG"
    "zcwHch7QEzAM1iUnFpgllbNyxsHcRx8vnAN74s9m/kPsiHxx5DQp7/UdllSONsEoBKWSPEIQuDRzubydpNo2PBGZ"
    "S/ZohD1MtAAwvKddJDpCDwAAkOLYhuS563BKkmCImd4qaMCR1A48g/WMr0fRdxgoKdPF/EhAe4Xlhqi1+gr4cWOD"
    "Mu8I/2bGZMnD/YF6A66Ah4HQ4x0AB7lsDocIC4Q6QE8yIIko6cmKfSwmytIYpP8gBxveGTziCFN6QmWbYStBxxLE"
    "IfuFCfGbT6bbM0KyQwhywWASL2I+a6KkNP53SBfl40rQMoNLAVT5EAlwNXD27/3JHSNiguAuh+wA/SLZ8bdLREH7"
    "hdBulmGK+acduyyUAXLOnM1KA09yCjziRPWIvt7yuYrLCNOnoXi4TPnNkzNStts3rwAoQFpnDzAq2exOUKZkQ78U"
    "JyTrDQlX+o1fEJHf9mJGLoViEGc6AsaZOPzfh4hmYpyiSQzIcBSXuXXullj+7v2clfLrpd3XM2FhPN7XjOhvZ/4s"
    "Am3JfFeW8tWs7PAtKE0suZs3ITVP3IKQ+iV0smE4i+fsiXS1pOHhRPDz3iSZ4MVOMjzLanFTtFNHizhZceq2N9/K"
    "LT5QwJ62fM+jOUIp+p54XCkqipax3ka+18FXJOJ3ql6jTSZGA4TVm8bSkotG5nOeixEb61Mezmy+zWJ1yRGWlKLX"
    "vsweYRbUYaUEFhOQjU74AnfWOXvc/uY6Q/tWoQuPvvBO76efS8uV/F7eZqK+pKqbq981/mzf5ChD6xwza54YGz8R"
    "CiXQgp26OSVse0inUGIlgc9BzxfhtQmLEVFAb9k0qy2NAKs/YnfyKSQYm3CF3fhOUdqXOhGkBKfU/JYcndh++dm5"
    "dIlW4kA+FKwkvGWAsjtmbaWAQgp+LfF9r+mE3tx59Rp3WPFBtJxYNnggvUbwrHwoyGEIRMvDw9e0z+BliDawQ5lN"
    "1jFhqL3scx/G/V/S6Eg15Ot8xxGx8nGz1H/MlhyKcK2Syl/lMFnrHNCJdnsIWFqUX4KI+ZhIsyvh8/mCqJ9g0Stw"
    "YUp2wpyc0bPjzbtMZDyulUATgK1+45Npa+Vrp3S3zB4V/GsZG3zzt0RL4W0jMZmocMNXR0vn+chNsyHR5e1unLH/"
    "Ixwvxjsfjs6OKbqG/SrtbrfUE22pvEPtbe+mn1gV0Ff6IspACtgpoSL11qw7pvElSOr5NYeC6a6kO5iAspIpaglI"
    "7PzVV9NEzLtmq4s8gy7yLHtoNR6/KdVljU3+QrB81Bnz858t67mirINJebGkv5M1z9mcpiN/9RQAarrKqd//A9NM"
    "i+u9DEkqhdL80R1MZH4/lsl9zfkJYlbEXC0im/NBXinsTL+8cCmvzg78a8aqZq7xBQ8JzSRnUMOPg8FdkNMwr9Z3"
    "qlm67nfq9f18PuWV6rxUnWPzsMmlpYEyxe2lbM2VBtlA3Jy+PllDoepl4WGmfWAjOqSg8xgRZi0JxJK0WOYddKTc"
    "KR+VDvul/un7weHh+2Hv5KR3dBqc+v2jwUnp5Ozs7P2pf1h+//74/eD04PTspHxycnx4ig8GpeH7cr+/s2szLZu9"
    "p0wqCE6Oy8fvewf+8SA4LvmHg7OyXwp6Z4NeMDw89M96paP+++HJyeCk1/MHZ8OTg15wXD47OoL/whdWk1JcrSiJ"
    "hKe6CC8zE+yqqSgwSYGajKKcP7wpK0RGFfNAQPIUZezPlbioFaGsyBQU3Jwc984O3w/OgtPjwfHpWXDSL50MDwBL"
    "pbPj94fl4cHw+PC9X3o/6JcO3h+fBkenR4fvj/vvzw6Oj4a9ctkKN2amopsoThQTRXkVE8X6yZWKD8NVOrA9txTA"
    "+8fHx6fD8mkJ9gRsjWFwOjg4HgaH8PfBwdlxvw87GGB+cHR4EpyWyke98unZwfDwdAC75ujs6L0V4Fc9/pT59Url"
    "UlA+DYLywD8+7MG8+u9Lvg//PQ7ODvze4fHx2WHv4PgMWU6p1Ds5K78/Kh2U+v77cunopPTY+S2h21Kp3zsJznrB"
    "yeHhsB+cAGPrl87KA6Dl0uHx4XB4djQIToB5nB4Phye9g9P++355cFQ6OgC2eHjas5veCzg5GoVHeyXSUuJSIdk7"
    "CEr+Ufmg5B8Ep73T4dnpYXAKiAyG5fcnB8OT49IhvB30TvoHpcOz4Sn8OTw59IP3Qen94empFSQf70RZJBUpq3l/"
    "enJ0dFY69U+PD4Y9vzQY+Aelk9Pe+x48OzvoH/XglX/8/njYOyjD2ff+ZHg2OHp/2j8elgcHfd9qNVaSnLrXy0en"
    "/QO/f1gODsv9s9Nyr+8Pe72zcvD+qHxSKuOE3p+dBCfBUXn4Pjg+OBjA/47Oesc+zO3MZlJvKS6SndQOj1XGIACT"
    "+dJ4aAj3FdEH8Nq7PAVVl97El/WLvf+NKNCQFTT4r8zYu8lZ/d800ANbP1UvAGChxjlCz5n6BRWYqVFpHFZGwbGe"
    "B+Mt8A5Eu3dw8M2Bmjw4BnWpUYrlILTuiQIBPPP3GK8mZvF9ODXogQxbKlbsBFORemgaTRcj9Kh08N7D8YfztCaN"
    "gyBZLeYipJ3TFu99D3pPZSMXZMQ+W9K3OomdzdmMttrxVjt+Qe14JSviUuvhKinht/S+pffN0DtWHEu85GMfWDyS"
    "wHAx6SuxS2/46p0nEMI0ej7Gc+pmLZGRKBHgsaic11v0/wiQGfQW4Qi9g+K4zIATWMrucjiLq643mgeDiVND6C7w"
    "+/eOIBlMW6gmYaDkAwpUdx0zUA0ygQl3RR4vSwl5sxf1pulZXJsUzRLm8i2Y+Dyg7c3Gbwz8KWCfnVWG5SarTNiT"
    "AAHS3F0493qjqOdF1MMdVcKk0iXsAbA6GBsWJqpMEqXOAkojGlGsZfJDXHsxSgM+TblWxC/gmclxlu+jmyxIYxbn"
    "tRZg1ePlEhOkX3QbVV5DvF73bsvv7biGFaisbFkJNB+Rmnf5uVBoPGW5dFPYXGJ/kbaXoxLZXuRO5eOkKCMDwRSp"
    "bGA0jfAy45kokZgI7k2eH8+2AKplCkaFzDVanIV30WhxF+1P8YyPA3/Wv7cju/Re0bqN+7NwOo/3WaE6vlGAcYvS"
    "tO+mD5ZHorL/NKNR6eCkdHJwusR0dHigdoLbVu3ksFSyMj0ZNvpPlbl/hzqT4buWvJfR+D5uLKdZO2elXI5Ke/fB"
    "D+cynDvcthFiaiDMIcTXnhdb9HNw/3UFjWR5G45J+jnAaiUgUeYVbyjVxHDCci3aegMX1bmsYsniep1Kb2Nq8FYn"
    "ryQlX4DB8MTfIJudfcs+xxNmPJ17kwVa9ZLnfcQOsBq2FMzoQ1G/aa1aa8aAAOfqPJPSkTdmwMqEaKcBL0pnwqkU"
    "DljfPR9EPYaMNEgQDw0XTyss3dO6dc+NlUH/MiDSYeGxnwQqgIyp7KhySbxrdOnNDLL7M0FTW986n6B4AYQ2v59F"
    "i7t7L1MEkefTR4MJFtVWwueTd7JmgPpS5yc8EX/6uTITxnJySiQZelLFEky4UiCXfGo267xW0vKhreT+fKisnnOn"
    "AIqrd/Y04UB5d6ap/ZCfBEeRLHP2nk2SIKvdZpOJZ4X9uFJ3NttvhQ5TbMgqA3iGpapKhuEA2i1muVYqx8osyGqP"
    "2XOpYrqzSA706ksL29z/Yn8TRzsPKX0hU3ySO1w2UWZVpCVmL2gZ/TkMqGSWdyaw0WbOOPxBEmiCG0dgGlWrIVDs"
    "vaz6TpSABYyH4Q/4BmtWOpxhskS0IqMsL14JYAymwQSVoNGDKOSSV0Rle+z/nMd+sTpYrLA8PnJgVeFkS4hvjBCt"
    "i3GLtUz9h1HkD7wQdPbJ/HEqcaXbuWq2av+skM2623Y9OGsbHa/avL6udTpp3S/RkJeG1/Oraf3hIg6A5Ob9++wt"
    "dbahQi8qxxUzyFCkfs6k6VJAL2d48VojUvGQ0a8oGpGhKa1Ae+odJe82XKOLhqLUwyzgmyB3ZsLsmsxjGaGqELJ4"
    "adh4aiPDJi7iTcZsaiIvumfL1YReLmieTQLzqePVw1LixW3DJUzWqHrlVn+lOsVepXHutZq/bY7UVyTIzeyM10OO"
    "T0xtJhawwT29bC+9MKnbEzEj+ZtOt+V67Ublpn3VtGDnr4OITDh+I7vvGUjwZ2fnBVSrETWzA7wY394UxpcT+9s/"
    "E7Y0nUu0JpJm5YpFyIHPZXQT8aCti99AbGQGsujvdldtd9Wb2VUGqjUStdxXSdVT46b6sgMyldtqdW+wK6wmfX1T"
    "d8no/Ocjp9RsdGqNrlF+q4CKf8vfbG73qZvtp6P/lajPynjwlPaCF9+uG959q9Iy2wC3bqty6Xqfmt3GeaX1OVcT"
    "KYaWMrkc+lD24lWr2b288i5cUJ68tvs/XfxDn06zVbusNYweDhuciXt90/ns3bTci9rvYkicRgvn1O4kV11v2xjx"
    "xDr69vh9HcdvAdXmEHXCMHI9rtadoSmRiMaiKFHQqqtYI4dPEqLVp+VlUS9rA4v5ZFoYJqp+JmpR5NLNX8dYsuUF"
    "z8YLlGAIM2VbVYZYwzFnLY+cZYmF2Gdr5xVasgVsXGkKN4lNB4XbaJUO0vKK7piTL7rsLhOxNB+dHEQZNbBCTJlZ"
    "QW7Hy7b1KpBaE0NLWNBaXa3gY7Qyd7Ca0GM9n5YfhFYMxfpYtCuOnpUQ1N2w/KqxUJgvsl4XGuEK73JWudtcwwRh"
    "GUFkdtPM2fSFh5lVxcL889SG8ixO3FVnYbvyZ89CZPYXWSEL0UqCgpUT6ZMmx339LpPFbM/5m2MWsJz/65Qpb020"
    "mDuMlh1kwsNR9H0F/QDdIWmAmLyB0A0S5hnEcTRjwV3qS171kfZokrJGdb8c+3CE/HCohB1BabyYL/zR6IEFocXh"
    "N0UYT3wyxRm4Kz1Hxfm86wh5xKGznTrtRYvJwJ89sDw/e5R2B8bkiJK90vlKYU/Mw/P+IaYixQCx6WIuq9vDkqc+"
    "jlk7h18Ymg4jjaf0hnJOOBQDN6FJBX7MQ/SEi966CWy2quFWNfwpVUMb11jD8fN8VYC2O2+7837KnWfpMox5jGZh"
    "TG7Ng4B5IsdvOcHITcu99T41O1eeV+22WqiDsV/u76DEACQNDWoN0H2q9W67dut6XoPpUDeVVuVT3c374rZSr53b"
    "NW64NUzk4HmdVqXRrnGbs6Fhs+GaGsnB9AWZh840tlmc4SP+gKAmfuY2lyu07J4Wam4ru9IXm4VKpqHNQg0fFSIy"
    "014+0Mgp0ywHk/R42cK0RjaLSn1QuCCtbQFhau3oB1uwZu5dsteswjhX3Y7rd2qGy7r9mWC3bl9parHvx441PKK/"
    "DeHClsE8osc8HvSILk1syr675ZzsEX1tCC/W/PARXaZY5iN6Wn+fFDPeNfvZEA6s2Pea3T2OS+UdAhY9vPU6VVsx"
    "citGbsXIpxQjC01DRrV0s6ah7Q7f7vDtDn/KHW6Tzy3Z6PFiPPY3klBarw8o8hKX1ysImMxwPzvZNcv9sY5QfFJC"
    "/42GOKVjD+8jDUbOaDIMZ2O0ZmIO8ZCnKGC9smSjo+BbMPJ6Ht2NMYAx6Uu2GJNpV3w1ieaeYYr/WgSzB5mWQCQJ"
    "17NepT6yEjXzbZCFGWjzAMb7T9HaMkBaFmrLhbXVSpeho6ATkQ8siy+rkY0otfrSiHXtZv7o9KeqW5tDj3R1jwmF"
    "HpyD0h6+cP4IHpwk63k/+CiyAgF3cA5LpY+OABs86WGdFFx4nHNJ/HMxBUvpTvDRjUp2PxckbU9RWY3Chw3wEIfx"
    "az1Rxfz2i6e95tkqcuGOgzn8Ofc9BHeA+bZ9dn3GS7mI0fRJyNvH3PLRVIoDSHMe9aPRTi7s9bQ+lsVCBOEMvJxe"
    "kx6RfL3eg9cDquzf29dG4QVOzEDhLwH1iz7dnCJjHIVJA7yin80WU8oFnNxIspdRD688OYjK5exz+YUAn2wiH5jn"
    "JV/z4ijfwmjkazsxXaln5dIyz1AzRroaZJ0SCkrmJDfAmueCsQZBIc1bnfarbItV6+TqO0dzSrzqdG72y+/KlrUQ"
    "lm25pCYfFRy1FEFfYQVeO35gKWWnWIaNfC1HZN9YCNmvsWZwAc+zAt0StmjVRwHntPrezFxX+zSP/1r1UsiiV+sh"
    "h4snZFFapTDwmlt+W9J3W9J3o870xcLsRkr7vs2qvm9N9S+QLJy/OcBerCV15/86+Xxf9oXWgvTpXPjyXbV05HDf"
    "RadaOoHGhYK5cQAGF0yfnO3NWg/JP1lF/Vscu1oqv3tXLR8uEfRlydzoe8yq8KZPDPLf/NtNq9lpVpt1Mly7t5V6"
    "t9Jxz1lF2wmvbiOGdKajBfwqHzn8zN5jVRRpEAvdBDBYOGWBJuPxrC/oPooDJzueJhX/TQjCH51w7kwCIFuMu2BB"
    "DZY0B/TP5rTkvP1byenBLlnArHwHi0reTVBMhwEne2IajpimhALu0mkMXw5hs+LKpNMmc461UUUEXCSSODI0PiMa"
    "ydqjMMfpyH9wZANmMlrKLkVHG2CVq8kMYuANyAs2YrWsmf14kXpF4UOMvAHBYzWxQqL28SKFnQYoBny09ldcHmtr"
    "u9rarn5u29XS64FiSXrjldO2O267437uHbfyNZJu8nvDEUEgZmJ2g9IB/XtI/x7Rv8f07wn9+57+PaV/z/Dfcon+"
    "pW/L9C1pMKBL0L/0bZm+LdO3Zfq2TN8e0LcH9O0BfcvU/8Rkj5OysprhvC0bHto2PLJteGzb8MS24Xvbhqe2Dc8s"
    "GwI+LRvaYqZsi5myLWbKtpgp22KmbIuZsi1myraYKdti5sAWMwe2mDmwxczB4c/lzL6T2FsODoW2Ymk4CCcOniPA"
    "sVHbFs4DZk3lFfFUe1FSO9E2K0e+InisfNArIuZbPuZFwD1KgBFMB7FGBcojDIZn62MS1fdwMoi+6+ex/BqN6zRl"
    "KVTBImbBHU4PNzfryBHtHd5Fvhk8c0eamd2yISmziZN84MgNv8KoCQD0LG5uqex1atduu1O5vvEaFUre5pYOlIc3"
    "zbZXa1ywF4dqa/cyeXGkvMAs2Zduy8Mkuhf15m+sxbF306pV3exbq4sRjjUjsEbRd5Cph6PIn4OA/WMXiE39bQ+n"
    "tx62tM4msGegCqcA9lneHPtcZ9qP4XPxc/jECfqM95U5op99p/apVq91Pnvu+aXr3cJsm62213JvD8prOr0lRfyI"
    "ZrFiO0uOIUEXGzXJVDIU3lqoxQJWKUapDWVVetcwG+oJQRzOg3H8djiRV6+1O2tfC6skSDvI7ko4//61/NXG10HD"
    "a3J7fGz/LSFs7P8Q6IJPx+FE+WXvSqSKG3K8SqtV+Qw/F5PwX4vA6+GWSrb9WxLAtQxwm7ouEGU6A+6BbpJHEj90"
    "lORHTJxiHCLvrHhiprHWwRJv+mR54kVaHUOT4SgEXnc3ixbTx9XjbFIcVrvavHHNNQlY1qR+NFUtxf4kmpBfO0tc"
    "6OEJ5c2iaJ73Uk2gnqRgwl6J40fAtyc8iPKm0sJ0pfVK7ZrPa1fNOlRpXboY/naBiUtFflT+9CvlUZd9GFallH3I"
    "LsxcTWCTSzWvDyfNVrBkymvNxQalhdiRddNtUWAKUNMoliQv+YwnOEsNrDwIsRw2ikWGZx5W843z3xgiMDZE0bBV"
    "UTed8UxZfwQPsemZoTiMEuBm7Nkmu2vBhPU8wtWqe9PhNRFaGFLbajZ5+KjX6jbET/mnVSbtLAjtEjmnqWCJP13/"
    "brk7nU5GqYziOsl65zWQyy4pYfjuTtu9rjQ6tapXQ+DUQQ5jUagy77FILu5dNFu/IrlrKcfF09SO1oZouVT25bPX"
    "bnZb8Ml1rd3Gae/uwC5v8BzmgJiLeo1CevXsyoSw81qVR8cadpv6LagBV96126mcVzqV1MdWUmGWmpfK4lJ4XUr1"
    "Vr792Q2/hD7i0MLdModjIGMDadPjH7Bsdgj9AuWeSZV/WjOb1VYtGW4+BetkayLWDJ1mSVQcqgkNEqliDnFGXDfA"
    "CC5y+DsjNBuKeuvJkwVjcZCx7BNyaBZozKaBJbd3iO4xfDN2JBv+QPOJI6zY7jA1hAv/IEnDp8QDY5mTeDGJw7sJ"
    "/NHtXOydOqYDkydnhDaS+e99DycTmEC8QItnACLs/szvB3to0JpxEIIQjwsFkMoVUaeIw0QM5vHWBgY9hF4WIx8N"
    "EHee838dso31fbp6/vFfjI7/i2GCk7+TdPvf/23LHjDXaJLbeyc47JX6R0cHZ6fDfrlfPjrzh73hUf/07Oxk2Ds7"
    "ODp47wdH5eDo5Oisd3Z41PePzo7Pzsq996fHB73TY7R0c0m6fuH9o1lrAA+mPPjdRg02hscZWLLt216jiekIanVi"
    "bBe5DCmBB7CfYngQ0STJrJndVfSFXooAHlQW8BzNsqfM5geilOTl8G2WIwmI118z7ABr0ZErQNJDKvk36ur0oWH7"
    "G74e+7M/ALm4S5KHa8xTYUeGUXISldNcxQrm0R/BRHjWcQa7u0MJvVNJgdNpYEXrr5y9mSGdmrCRrRrla6X7LJ81"
    "LTaVwDd5o6fsVZ+LzL1KL1oCX4lW9QBhbI5BhKmseqfCKuApO0GBQPb0MS5mgNls/XEInEg+zaTs5fP7c6XTNbXF"
    "i3bznzlB8lvFxDK7tgapR992GiCfirnfHBKeFdQGsNqmTuYrBjEEuosweJ96fZR9x/39BsaA0YTukSn2PPLjGI8n"
    "nyEu+4VSiZY50zFUipKT2fbwgXzYbbRcUEl4ysHikZW26m5VLCCzANOiz2ZkOhtoJTELp6b2/GfqZAOOXDvvWkzP"
    "+NUS4Nwgv290PPO38LHImoQzvARtysUDReYuLZ5QouQ1Qcds/tZwW1IDtJ2YSK81izBHBI7AESEms8NNam0lx1N2"
    "Np6iszSpnjEvAJQ7v6928xMjqrMAQeHcipRhh103Ef/8C4DyOd7OJJKGJZTE9+qXVHhSooxWl2e4i76DkO6x4xQ2"
    "NGcdqae6uyZ7KdlK6kmWx8hVUCthC/k/f0th0zvvUlauxJwMy9AayIXooE1LCdBvNPXh6P6wmCRygi40RD08Djwk"
    "rSXTKKQ/gwnzhQC6BJQpSHLiseN7mV5JDl1CnsbhcB6MpyQHDlYKq7VcG56iXi2L6qSPYCWGOSgTBAbh/o5p3uqf"
    "7dgdtuYM4TGTUsdNpgO8oYZl1OyhJb64rbm/bWBemQkkc0suNdw6nWnLJydaJt/+Vmvg5n7MFLPzMM2xe+O22u65"
    "W3xSJM28T58VauXTxO0k16DQUQXUWbwTa9meIUsWkkw2WUrKcrsc2GlT7+OJIT2FZHKybJ97Wztnatey6WU+2cAE"
    "s9MwXf2oQrTGp7lg/9SsfNdwduWeUtoKdw0g2U2DFpSO8N/oYMDu7vWJZqaSll/RAscKhLGaL0z/NCon0Xgczlnk"
    "S1LjJq1DxcaHxVdQa97lpCjMbLVWy0EaeOVuPo/afTx32M3ZlLu5u2E3dcbsWkiQOdrEblYv2lUVnF1bOXm3QDyw"
    "zW6UphzLQq5p2rK/D1pOg7b5MdNSp4172KrFNdeoSWtgluoOSPPNtDazW6RZ7BZrjUbKMmm6OeKoFdGkWazNlXQB"
    "E7YCqaa5JLC8xC3cQBjdVKq/Vi5dD1bRQueudvXKva54lVandoE321XYL/XmpXx/DnsImtDS6a670sEH1wha0Uby"
    "nZt6pZGoI9KyeQXgo12ZeSNyFBM/k6+Ztb3bqHWSZ9lavi2XX/LC0vi1syi7a3jVaLaugVlp1CA7F1fAOa+LNJYV"
    "KMF4EttjVT/ebYgp2zBvgk/i+JA7WPq4NqxFuaDG5suvqNNSgc5K8F4fM5NcNOHswfnj4dVG0gCFpVGjs7X9+bpe"
    "a/yKPgmfaufwmKgGecZlt15pAW0QP6i1vXPQK+icwa9q/0R6q5x7FxVogB1dVdpXqUe1pue2Ws2WlWdInvZvg0hV"
    "uDSLE1Iv2s2qSrsG1WTXKOVn5AKTRKDIAqQl6jvJ0s82kQyXn7hv/bqc+hOzkEV2vwVYOze5S8MBMc0xuxBHP1RW"
    "oFDeg2PTPWoaTBZjnMAkfTeuqgiOCLSH8TDSDBphdUSc/kSsdByCpDq520dDFbTtjVS5m8fbUJYaxJB0fB1GM1m9"
    "d2868icODRjfh9P9QRhPI5a71yiaJ71h0BJ1Je679umqcp9qXzqyPdsrKL3j9b3Dru+51SsW3gPyCkKrm8w8AHZ5"
    "Th/6nIT5fa3aMvkOOOF4vJgjAPgIRD5YitmBD2Y+u0KQow8BIThXVtL4owPbeowBCo68oEgaYcQVA4KigTA/A6pw"
    "nPWDgIVFo2+BjRfC23AXMF8wbtXf16j+Wl10pu7hNhvguaWL56SLx1/KYpoyhSIedSd706pdV1D66DRv6MqInfaM"
    "R8sVUWa0fRqXgEyhXMju4cCP4FycfQ/jwAn82QjOTzhZ+3M8AKDpHQVs3I2iHvy+Lb17d1susfOVHafksIQPODNP"
    "pAo8cj/QiIQGgzVvlfrX/WA6V8IqPdg34RCdVHRqkAnZBCXmkPd0FmIAuZfML41pw/ZPUtZoDbO7gcsh/K+HJCV/"
    "XgFludfjYDSk/Rmbn2Y/TcioyDBnCUDrQiMZqCxJVGAyA0m32djT4rEy8SgWPrRLUGK1LoG1wlmZ/Cks5peDeet5"
    "PawCZhM1qUrQF6mnfpAKP7IPofW75/vyea1x6zZQxWPBn7trfSqJ1f5jfL76kPSVoH/7cEmLjWaFKTvuY9VV7ra2"
    "+jrL3vITqqf4tEmXfoF8xcaTcoVExU+aFfjV689JXlJcAWh9TKETp4AjTgGn5wPJg6YrE7GJlrOZ/+CMgskdO4rk"
    "WkFb7UcU5kn/gUmAYjpYULUYOTtcHY7EFzmMFjNM1jp0xMmGaTV4elZVzWdgGM5RoiCFHDO/TvrhKBSCICdsEmd4"
    "/lfUW+fRHCNjYUI0n/dl1gAJmunB39mKYkf4vTv+3R3sTvgrJsCDfEjZbAleA2f+PeTSH193oi//o91sEPgBjcE0"
    "mKB3oBKqi531FpPBKMH4UrX0eXRSu6M2pbletprdGy7Otpq/YYQ7f1Y795qtc+YBkH+8PecyzGdzakFkq08tiMyi"
    "eMKwv5JlWZ0Lw/BHoEi1f4mzNQPWi9rvaBhd17KxVQWeWBWwMlIYTttHuWXb6CavHPerYfop8bummYFH1DzGxrCG"
    "5q7E8agIFFZfaekpREBCPtxiZXjD8Kmah3IbqVXzUg2MlfUMRJA+YZIcrZj9HQAQL0ZzL1CN17AtFmxfiOp5CC5/"
    "HHgIFfwC/tQM3rOAMsb6c2+irUdFZyrkKF3p9NEKuhl2q5kH8pG07lzWLYtqoib9VnDFo9rSV8YCcdauK1kyUldA"
    "XxbMSlRo1YmrCA+dqtdo65royoYIlQvYwNv22nyjyq1x664D202qybn8YZ2JraV0M9w9m8adORu0WUoK8TTK+StE"
    "jif3o9jzPnLRfexxX8RHcw2fDamo8LMgAu0UY4RFD/Jc5uVoRMd86JhWx26ZqcIN0QZfVyzqxZI2z9bkz6Nx2AcQ"
    "7dEm6gdJULi83h0AvPp8cAZLPtN0Qzaz2Bkv8Oph9MASW8Xht0BEqycf8VXgZqVYdFAywxkBg23jXeduhvDjceqS"
    "d9LQbC/RO9xme7DNHLbNaIkhCrJ3ygQZWv1BNKUu5CU80sgeiw3sa/fYFJhPKODzFDwfKErjvzJ3F7s1x2sYgNeQ"
    "34LnJMbail6vT/SyV64Urvq4gNdHColbOno6OrJX1JA+Bg8Tf4w4GkVvu5JBLxowLHtoGP0h6niwHHdUTFw8Z7k1"
    "8aV4wutOaF/Hc3ikPdOUnPRwqrxwtkTgOJXVYDOzU7sp2XSTXozaQfm9TQ/ZxWt9lG36yAJL6+NweR9vPbnws5Bf"
    "IaPP7GZg86XNOfk8ywJtEkZix7AKYKM+j/94qywrDUBxRqUeJ0cKvrgPRlMPJFQ48AbRYp56y0kD4DCL5564WlPf"
    "pD+jEkNe2WPypceQN4LhSSBNvZ1izhZW4AhexEn5IZZS1SZb6LLCSropyQQhKwfsHCDa2TsK4GzfgQEV9jM3Y8tq"
    "8CKEalrt3h41ta0sn0MKapfoDG5hEDDTzhod2VoWdJbxjEaF11Xt/S0VGwaUOXt7HLNMZ2ePcF/SLTtemf87mEV7"
    "k2D+PZr94SQYxj976IiPDJ3tKIe+A1QOyMWbF3MRxhOFsXM9O9kcS7G4weKiq1d5NUsj25PFfLIsFaBSXGJj0tMW"
    "IWaE2Ap8hq6euUxFt1X32t1PoENX3XZbicRzbw9Ka5amANxG34F+gsm3cBZNsKEnloQ80fQe+ou++ZSNzZ/dffOY"
    "k5T4hVnyRtyLXYCceZwTFJnMPWZWEl31Jx8hArDeSqkwyeFuwjyQ6shEAXOAr+iJkyP/tZgwQvJg3gsCkTeMZr0Q"
    "JPGJ+lpdOzLCGXBwtanuZ1wI0Px7GnLkYb5CLFZgJ79YUCFSkgP9yw4WCkeby+8YcYc/2vJXpV6Xfzea8s8L5QNR"
    "HfXHg7oF6ReyBPH3JJJ/DuUH9q6nKgklcy+fWej8Or2pC/+FNov7u/t3mNXe3iCMeaCaeqju7cXACojBwJ/30fc9"
    "Cpqgn2P/x948JK50WKInPCck/M0S9+7tsUgu+POXT83zz17Hvb7hwy3G0z2mceLbK7eCWQ6S94y88VW7A2/UV99n"
    "4TzAnuHX//sfwgBaFP+kl7CB8CP3d9z1sMC/rwBmdS9qUmq9SUwP4YUUUi6rPAYYi+VVb3pza2MoQdMUO2vVZcYu"
    "yLH7Hw3eH3YmwXdHSeS5RzEtAwetBQ4Sh4hwVGjiw47fi6MRVuwQ1tAQPvmNqhfFTvwA+37MxL3kaJT9KPD/IK6E"
    "ZtG/g4nDacSBdxnE506UEYo+VY0ucr9k8Fa+/LOgklaz0e4omT3QiZPdJWdZrh4xXbtxvesufPzJ9WA+nc+2l9Rp"
    "rq2isKCOsBAmoTckyH22WTlolYb6e+kKK7k5vNdE6EwDjwft7Hw4ULi9nEfyAZNHVJZPQcdrQNtSXTTIGmRKs1MZ"
    "6SRc65o8X9ks2SmbyWGrLe3cvW1063XL+SuHdJYS6UirNs9dFkhu1WPhQb+G0m8tGazc91vSj7OO4abiShtQSad+"
    "/w8Mw7MQgFks9GKCR7fDCozv5+4o9sEsSF1kc0GW+/4zeHGx/Oyjg6++lL/+TQoV/NEBPuLc5iPX6akbErUJPYJs"
    "uIKPdurhEFnMt4A1hUkCxuaLOTcckJfEEF8rFaX4sejQscju89nRgEEOFJfA7tGBeyFdssUBSe7hH2so+KUcBX+r"
    "OWxEcyiyB+QdAxuzCWxxuBEcWpgQMKmGF05AX0gHabzl6yPdJ4Etj4e4J6sUUpaMzFc8HTTVeY0QQTmgLihQ7eV6"
    "pd2uXQA+lPo/lMSp5bab9S49lRlrmBaEeePcFVSU7CKXeIUeHqyWjWk1l+G3foO9CXIq4qf5m3CzptZNrMOGpwRz"
    "//9n713Y00ayRdG/ouO7773de8C8X8l0n4/YJGEGgwdwejKz++gIELZOMLARJHHP5P72u9aqKqkklaQSxo7tsOfb"
    "HSOV6rFqvWvVWrBajIHCP4hDPXuWQhkXiFnDvxKQvFlzaHm/g8D2Hkeiobw33oWYechzp+pRiw/FDaqT0S24rpTQ"
    "6Z9EJYZ/u6vdZmqbM/HH5N/Bm6L/Zsrvv0UlE3FNyHuAOZj+PQeNz96sNw7JdQtgDfL358Lpn5Qx2SoIpk2YPCf/"
    "Rk3751f/tPJ/FPMt83d192znUyLZJVQXmKLuSObIfjxTrpQr5yq5aq72kuKBgivmxsettV6jQv+h+AsmLan9UvNz"
    "xbDR/ZRalN/LC8dm2wtTni4sTJgFq5G/iwvLPRDhBslTzpAvc/I41ndYRv7YzCgL0werj6IvJQjQ7jzCmZR3y70g"
    "bcka420BgQvSxPA8wy38OfQEdvPXgj9tt5C0JrGT4uJtdoGSdkYYnd2JWrbyzVa9Cu67znqUwUZpXWtJo9ipa2mc"
    "WeaumYkjAt4UobHeWAfLo5FGLk8locaT182fPhmliYokDLjXVYQ9yf07wPT+Ikas58WKmf3CKPbbSXVqhIBESErJ"
    "FW//wTY7S5M+OHlVSsvOhc4uTCQKxqcEdVOcKGa49MrdG0+W43u7fOT6ERsinDp4cmcEzQpV8uCwIgyTZvekcviv"
    "OKfGlzmcnLwCmjwhehD/vYMjPh/Pv4yHIR9q0jVDZ0nLcw1WqVSYuKdrawPYvM0ZYeM3+gatYPVTk90qJX6QI2hK"
    "xrLhGcve2dAKYzrp0qh0VqO4pnpySPEay0D2kIUB2kiShweeLHIYOezp+fquZMb9zNW9FEeqvGEHtbh9BYUF2VAc"
    "Rbs/Nt98HHdGjJ9ScWJMS769X95YzOjvlZ9on/3tqjvq0s3EmLKDwcrHbAL8bqiyKHJQmdWpmxzgDcFhvQK/PG+v"
    "+FA1SFxbP+lP8iz8BsHy0JEXlE04OIONvbCxePdqtwUcD5QUjYUfKgcrdMmz8gSscIdfGEQqegRaK+bU4ic67ztn"
    "f70cgKQ1231KZRZsO+iPu/0rZVtAre4HcS4kPiFOJM2KFx8hzPAqd7Y/9gbt8++IIqm798g4dFAUCSIFrzwSKffS"
    "wUw0gb3GshWdEQaCYDlwSpIhIw3HqHF7OI555xWsUH74HVCR1UPtddqw3vYbljy/PzAHV+PLq3EQ/R4T954TM4rB"
    "K07WHLjnCoQEuygCcXk//H2KYQP3mPGPsq332Bypkuo3qYDUm06bAp6fhiR/AJiqsOPpSfKnL8Xvk4Y/AsYA8rAy"
    "C0y9JRsynGsxUoWBK7Pr1fTG+8WsWf+oaEp7Ht1BSj8MvW1vNqvd9U20wVEipCK12MCti1lkQgUDlHDXSvuWRCBS"
    "TbUfUbPRqHqWipw6cRVa6KvfkQ6C37+3LBVjk6lfpyZpHF6GOGbuh0TUXFgV0XIXy9xEK7ekLAC0WMs+7EghV/SO"
    "btV8Vge3UjixDoYfgHYTBbLu6XVChUrVSYZeicqQUhtMDerjYNQQ0Sob+fjlKqz1ducJS6KCY6kKzfyWJBK8ioYs"
    "BaWyfqJokp/Y8PnyOlC4ECfEArpEMSvSh2AK1sJQDYGTWJASygkNywniycbatvBiidQ3+3y7cWC5YkYq5DQ4XhtS"
    "sUR0U4fnifBYYh1LNu7GnrvEojnex3Uj2osu2K6Ip4I9FSgKCgxDJmsCX0WHEIU7JjZAmLJ24HgsS6XD8hzfK1n/"
    "0WB44QZDYj6PGK6YfFoSWiU/PGFntNLYMPmbO5dOFmGwDbzIEwFzLJVqsrKgYXi+oRmH+pcCCiQohBqxWR8J4EgA"
    "EQIQAUWDi8teZ9yRLj0zI4EFFqGQ6PbPO5cd+A88HXUu2qCRn5ndc+lULw719j7jY1PAu8ftN91ed/wRTxaZMKeC"
    "SbSWAtMwHDxMNm4tkHNfsY5jmCS8ShswI5ImUgPvOPK1QbWI83h5zEtMvZFuxeLJKY+3nlB2m4O6o9bYarVz4/cz"
    "gNTPn5hSG1i77c1qw9U7cweYTBukKkwi2HVsg1Q6FD3wGBqTVe2GcRU1Wv2irxHIRV8qCdNvxIC7WX2RpwLfLRbx"
    "7+WsvhZeQtZrysuHUdO4Ci9eToekL+8eyEl9GA+eNtpoWZFHf+DL8QcmE5ZeD4l8Ri+/pyan0XMlarKCzJ2lM4uj"
    "q/O5ujqPnssH9lwmKnI6fTy0lzFJAdGbX6wOpLNRGlqS1iwe3Vkaa+tkcJlm0rB0wHCAI6kf3I8rHDVBd4znpGHG"
    "IJUvcnOG55zpnrMkPiHXDid/Qxid0o1dZz73nJ1GUZh0eYS+M8dqRJI167jM0NUyKniposWdFAztFfuR1R7hU1WU"
    "9c2iNx++Mm6oJOub9vjsvXnWa3cvfIcDlrxllgPz8L5SzJkg6urpak9lFWKmYu7fDu25PvoWjr6FH9y3kOTsT5bq"
    "h0tJcCTgIwEfCXhPAtYrSxbj9N//GCJgvqfcIfnOmx8XmK3vgUAIQrvOELSVv12hZyE2Tj6FIUlzidqHv568KlIw"
    "L97jkmenvB3xNKH6r5P/8UtG2PIFHy+uHS+uZbm4FsAZzoHMwVD4/JQ0oy3RvIayBhB+53HSINy99+vdZAGSgugH"
    "duA2skP68lO0JC0Er7CzSp2xRPg0NvF4v/B4v/B4v/B4v/B4v/BJ3S/kOqxZVFLFPVTY4vH64vH64j66XFiPi8OT"
    "H0Z/ewq62yOH8e0dOPs5yhFemNfve+gQaOpzz2Dwl992f4fhMyHPF+W3/EHDHo+BiseLyw99cflg8ZMh/hMMb+KI"
    "QgXrzMth52337ybg7LtuX8ax98PB1bv3JlOyPHe1zl4fNABTi5nv1VOmiKrHDARVZjQNXpgK9MB4JztKjRmbZTM9"
    "xqAeY1BT4kmjSrBWUOkxgPUFXL0/BtY+WmCtZBOpmL1ze8trznstI/xdla76m56BpYVj3ztTQiDG4LmH/2qamsdQ"
    "4tRQYi+8d3oDqzZol693GA9Mg9xNFzDCxkZb0QsQJk5hoHohMmgvnOUne2ZInNhATkx5HoTbhX1Fs/XgQaHGwARW"
    "C6opyqsJAbVhzgn6QHhODpO1AquWGjxVRbRnP+ExVri6XVN1VEXx2Ql8tYDlYqnl137O4/CXUnZuQnXDj8R7bUxW"
    "sI+IS7M8wdDYrnjyCyYJ9w6jprK0HkStzcKBJUtd+XHeyoBr3+Q3gPUZnPXxy8TYt3V9DQsDK0jsfeC+se9SKKhS"
    "a2AHkw0Md+MHkQOfBhjBDDgCKEK9s2vZ++r7oYBoFrOFEdAoWMfDdrdHle7fBkTHCUFS7tMLW9eXIIcP7s4gBkPL"
    "7l5cXI3bb3odHhF+3hmdDbuX48EwAofvEfx99EgfPdJHj/TRI60VLJ+mBSeHy7ODNl7gUNQOMlzr1s4v4T9etULG"
    "+V4bgTDvAh/bkGgCxN1sB+oWiHuBZL4opDa+QuGLWl7QQypZwMrRo5PjfXv03hx23naG6NY4D13f8UtYa2ffYTot"
    "Bhd7NTC8SigHL8b0h71ZYU2J1dLWLccEosMt/JkJkF8LNFMB8Lhp71lryZsHUcQtzM5ht91Mewak/xnwZLVxw7wk"
    "pp56qJk8b0Q6fBuo2qtgtDZIuzuYtrtbRKmCCsq4Jq7UxIUB7Xm6jmJ86GUNOwOWi23Bck37K7ViLDLrF2pIeDI+"
    "qg3wmrKmtbgGctne3PqD+iwloDIoC+i6CUVcCdOjqODVrYq6crU2mKmj7hY+LVWLlWlx2mzMKpXGfFKvT6pNu2lN"
    "q7N6sd5qtRpNq1JqNGqNWbPcbNVL9Xqt0sQHs+K8UZpOE/wPkjtYB52kSdl2vVaqNSZlqzaza0WrMmuVrKI9ac0m"
    "9rxSsVqTYnXamNfrs/pkYs1a83p5YtdKLdA1J6Co17QmpUTeoKsZPb7CsXw5HGClc+BSlz0AdsaC53vVgoynFc3P"
    "M5GTBH+rVqs156VmEcAPuzC3m7NybW5X4O9yuVWbTgFZpsVyuVqp281iqTopNVvleaU5gw2qtqoNLfhnJV5pfpNi"
    "qWiXmrZdmlm1ygTmNW0ULQv+rdmtsjWp1GqtyqRcayF2F4uTeqvUqBbLxanVKBWr9eJ955dCU8XidFK3WxO7XqnM"
    "p3YdaGhabJVmlcasWKlV5vNWdWbXAU+btfm8Pik3p41paVYtgkE0n1SaE73pPf5FfBJMvjzS97+lc0oZepOyXbSq"
    "pXLRKtvNSXPealbsJmyePS816uV5vVaswNvZpD4tFyuteRP+nNcrlt2wi41Ks6kFvR+nUJ1fAM67ce9sQdOdU1ec"
    "xXXOT2+tzSd7w+t8rdaeTeD54ChHm1dETmygW0hnM6S5GNaWO8cknxJPPkoJ3qh8HpaKw5JrOVXhOlxgnqVnRH1V"
    "EGieEag3pQIjTyypt3VAv0WYupFic2K7YLI7AlsAJYRj6BpNpCX64RgzNrwGTO1OxWzR0QGwOhs/FwMfgJfriG+v"
    "DuH9RXdGwSBGPoBQyMbyva29P7vX09vEgPfW2dRpeo+WwpOyFBJvzytE8cHuzB/x4EnhgUYJ6gBUmSBPv4H9OI4O"
    "vbrTqHHAK1I8prDeXwuXQzC1rvrmaDy4NH0thflAck9sYsxCfNsG+/CQU0xwEj0YWBLGZJbvo4+aDutkl9hJ2o7R"
    "xd6E9zB7nz/J4hitBFKY+YRBq2TEB//gWZr9FZRNAIEal6HbKMblPEzLxYzJLqy8FoWjOVsEa8Ve0IQo2i24UTCS"
    "onXaAN5MRLeR6fNO9accmese10A4e/MzokdLJ/scWMyM8XFv8IDECckxLGVAReIjJa6Cr7Tq1ahH0QnpkJcZ7x+0"
    "l7vbVyruz8GjiudKLDbPZpO11nwAtor+pMmGtkGrGEtkUgf3agSh92i1WGQMTQabjMmhWTzz2tlZKT5CoDHF2+P2"
    "9fFSSz02p9JXFO0Zh8gzLh8fVHr5QarntYqxM/z1M6jFQ9d/TgpMoloff8aTMEfVSQNsFgpZDO/2HmQ5b4g70tCW"
    "Hj6k4vo+uPyL89CGNiDpm+9YyStMUE+ljNdT8kBznZi0YdeP2AvivBF4wpFe8FCcyhcwmLf20lhYpFOzrSZFe2JL"
    "CriIpVyxSIzsTl21kHq6zCbVTRTGzoMJwKcLEz1JeG1v1hsH44psC8Qbeq0ewmkiMLJ0WM+EcgFoSJvr1cKZIjgV"
    "DfYMIknVdZTaDZ8IIBJwMse9saWHFN67i0voSF49PyQutgVFTsa+tb/aUzYELcRv4DEAwK3pJ4yA84ZSRPEBKwWd"
    "BaDoRTDJoFUk7pBMxvC3KaEeMdunmAIXByHETp6altzNABu9e0lRJPAPe5mdE9fJm8GgJ3URjzK6F6QSTV/VFSkt"
    "2zcR2bJEasQifKZOVDSh1YG+yqPgK0e950DW7pGTSpw03raPQcEk5eYI/ADwf09k9o+hBr0bfOgM+3gJ47J99tf2"
    "u4550e5337KL2h/KlYdSVvwQcRbQPV3t6LKSp/tieAypnW42KAdkf9LN/YQ+RWjnrQPqLn538qqUdsczd7JbOoAs"
    "5gQhLbokKH8LLjLlFnalTB8o4OCtwpcJetuXS2/n4SiGgXdGwa+ZfBpdXYxOt19xlxQqszmztpZrb3HPMQidWR3U"
    "jQDw6R/O+l4fn/p7nCzkzF53NH4ITUpTPscPexTSUeeERBxeCBMjXGNhL6/J8rQWGGzGRLnkPCDCwKuBWJg07Hjw"
    "JkGhdqwpK2HKpiW4w55awkOysBihm4JX95S8WRaULLk4B33Gnu0AA8fbaDxGhqG7DLVwcA3+cv5AObC13bArOmv+"
    "jlBvWgk8opNMTqFQ4gk0pAWnGGX/bOf/YeX/ALPMPC3kf/+T2ihbpTu+xaAM3ziQn+3ZWgCGBlMHXnusjN8JhE/h"
    "letcL+Hvq/HbfNMI4Vpk/8Tpve+33dhboBG8KU8qcCEcduuHj6l5mxq7UzE5M1diG3tYl+cBKVPDR3mz3bI47B0q"
    "jwDnqbNwLCn0zPxcLj9nRsdXQVYW+vfpQqRJy8azUFNguncxk8fgcZgsnCUTtWv21nHdnS1OUb2neLQa0swVH6Qw"
    "i4StCIwa4UTBaQR0NoqneT8eX2LmqfHVyOx86J5TWqeL7ugCL61nTG+igI7WsZm/DYH5/Ta4GpvlYtF832mfd4Zm"
    "tViFFdJT+FM8hQbiaRHa/tYdvzdHnR7gMCAznejwltDqQ7vXPTepbbfPfvCl97r9jminteh4dEmTHyA5fv9XReXM"
    "e+6+pUclpxh+nMqzTpFnHYwhP+qSD8Gy3QPx7FTnCklnkP0FmcMMO2eD/lm312XxjR9g2pgPA43d8kN5W/i6gyxY"
    "05ZNByeh031t2rJWrJZYiMqhoyeq8Tz7q/DqVAM+nmo2H4+P9y/fIy4h0L5Mxz0s18kyZQ2mEZfTZu8CapTGVVmA"
    "Ye5sQDP+ZANDEamgTO5ow8AK1RspjzxOj/sRi7xMkmIoP6X+wUbz6pcdNG+8lyEF02BgMhmCPHv62VPy2VOO85G3"
    "PkbmpAnn9ll61EwImxGRIwIv14uXGcVVPw2fLgSYsWrdWopjEmi0OtgrR+ijODJi9y8heNtbVtwOa327x8mtCg24"
    "lDKDjTWyRWpgj+Z5tExdAQkfW0I6F67LrCXZA4wifWsPHyUYtpyImb9KWCVrsM9aNRUnhUh5Kt7/J59OEnaeuvPS"
    "SsopDtHbBbBA/z8xLy8VIeP/PMuRdxrg1bOHd67hLOUb6EyESejrZ6J0t/z0gSbidSKEi8jYRMoZKV69t/n/syKv"
    "nKS95D3lzM/7SAkRJeFCfRSQO3KgXlobWPbWa+QBnieMhDVg6ii+epa8EW/pU1pE2hyK8eN5oHBvCvyWPyauxGtR"
    "mLsM/UY0FXuxWl67mErKP0Cx+cfYJf5iQ2GqJ0VeRSaDgimgvKxXbD9DYv6gIltHJCuEr0ZlXV1OfPiki8oEkoyx"
    "m5jTPJpAEXaF4yhqz9ONs0brBOdNex/YjqPCtqfClo4zsCLri2ltNtad6SVeY4YDZvhMH+XwmTB/7C1LCs6OE9Fk"
    "EIIcQ2tOGKEL+/mfaoYSnPKtPdRppb7Nkc0SeO7eFQ2oJyNpDCYe+ipB6iy1/CiBycJsQLG2uGH5HGL6RYII7w8z"
    "dkn7ZoPkNgl6wtFpBh1uV9PV4gFSfYBqSLm0r52tSFi7IhauwCk3+lhKCSJlAlm5DqXwfJqpPw6fIzJuuwJ2H3r4"
    "C6XTkp51d8wRqZ8jkuFwgpgQVxRCSK5xBkl+hWqR/AoeF+W9RkgmmllSRUMpl0vitYqoEyiNGHXzVwp61bu+eUxY"
    "+YITVmp7ruIk3jHf5HOIQwvyLtYtU5aqRWOx+mJvplhR4waewgjOLbq1bizcG0CMGO0ArA47MYZte+PPJplzGfPV"
    "YoG+OB+xGFS9hJanOorId8rE+AOmRtwnLecjJ6yM09LEEJ5+9sgJQ59GVsmjxfH0LY4MLoCQQD5c1skjnjx9PNFw"
    "wizt7ZfV5pMZPP3EqJzN7Am7Lz3xj3MM1GPluUiC1ri4m4n3xrg+xo7PhJYCL1Azo2O/LzcwR4PXkaEScw5oWDPH"
    "JaRBqQVaUr/zoTMUNWjD1WtgLZstenEo7ysf8NZZOre7W4M/xpM5f4Y4gdeGH7nvzGlKqKvBNAp0aJSDmTlTUv3m"
    "q83EAbguT3KRSB45dh9nHtpadkdW8YLteaSwFTYU4JNgoN0u4qCPb+rubm+taOKsWMgGRFho6d6O80I33oDsWCL8"
    "NnBpl/pWNFoC3XoOwOUOUHvjrYdNjBU+Ci0VNOVbQgTlW+ANzmwnVZaSV49Xp7r97rgLtJsNsfESXLVVN3iDPNVG"
    "FPdLAPW8BXvn2rfWV8RPr0seogGdxEP5pSNY7gXhkSiqPbrsnHXfds+yckpkzDhSnqYoEIsl6gf+LYxaYNpsZScB"
    "jr24M4XVbPoO06SFvfKwju4xgWndGQ6vLvGegriwwDkmvhbVwAf93kfzqj/sjAa9D8CZv8Uidunls84nhLzJ6BnP"
    "YZK4/7dvex6nSNsZfHTLrhIkKLdqUol9IVVxFO83mVTkJN6kqT/by9l65fDruWsAkOtl8/Kv44n9tRQYGlKohT4e"
    "ehxVz/F2hp85TE2GuRNgLCYW/pAKCMaQ2bOjPw3UvwffT004opev5BDkr8Vonmba/5gcXkp7jEUDRrY5aq1hzZul"
    "jdFVUzLGTK/isLYtJxpJjk8Eu7tVUajGmaRHQimHXdg+PZJWwTZTrmQqGW1sv4c8QY1h2Wll/NT8PO4ELpn9a52/"
    "SRIisNp3V6DcfBg87+PieDmmk3HgSZ42e3I1sFuItu6rQmG6WE1OgbHcUS7P7SlsTAFYC0w/f+O45HvS2tCgyNZK"
    "46sj1fWS+qoEv7xa+vD39JSAyarCwx+/y5qIFghjbIZ/adw7VOkzMswQxTVAFqMA6RQj0FSR9LtKU6Lu11PSbZXM"
    "nakUsSw9Jqhq+t0olDn9j2OsYY3vD5nbcu+0lBpqpQ7H11I8kzti2dGSVNOUshX2f2vnEz0GwRyrtqYgSrqdkSWt"
    "nNIUOWReOuXBUIagngQTSC/u+wlGBWWwyfS24gWHGXlKqDf7YOBRWLPBobxOaGw2AEaNpPrtotoNducBwL9PF/gs"
    "760zzZuVPS6Kn9rkDPlwMkeACzviDcmHafhAMm5Wi9kPU7TWDxEK2Cw5fkRsCH6XMyar7Y1XPJhVC2ZwHRGgjHMp"
    "VszHZLzkSTdCAVv/sJdYj+0YoPXcA7R+Z9bWao4MJXROmlOGBcQfgyWHQz2jE4MXfChwGI/30Q/9eH7opEi1eA3z"
    "UFFqfghUH1iAn9i613nXPvtojq4uLwfDMV6Pxkx+4+74o9m+Gr8fDOEv0s92GIpk41iUxokcw0kRUya/EZra5tA3"
    "3HjYVFC/Mbrn+1V0DfRSYNOG12FmGGrI1/dQickUrNgjnjSePLmLNKLKRzidSG2+KEe8Z+L/OEYfSfof0zBSkzu2"
    "BkPwbSiM0t5aAGOkZO8qIzy4tZX9ZCpWkNA4xB8SWM49S4Vryr1HYOnaoppmbIO271feEgJAbgbDLV0Ml1S/1shh"
    "GIq1eO6Hg2EChs4xNR9PAJ9Uf0F5KDi5u8d5mwbJZjv8S+YRWn091TPA7AWZn+Yt0wyMVGu/9jjiu5cL8SGLjmWe"
    "zKHLbmRkhxLy1GuTFhjSLbtZm9WaLbs+LdbnZUCjYqvWqJTm5Xmt0rCKjdm0WG7Umna1Wa00atNGq1yrzielkqbD"
    "++mc0RwPLY6HFgcpq5tk7hzmHnAcPJ/BZeAUBU5aTaNZr1ZbxabVrJXnE6s4m1nlYr05aUzgWas8rU7glVVr1OaT"
    "cgkEcKM+b82qjea0Ni/NylNLazVaSqdM8aVqc1q2ppWSXSlNW83SZGrNJ5NWyW5US/ViCSfUaNXtul0tzRt2rVye"
    "wf+qrUnNgrm1dCb1nOoPyaLa+NUIW44M572xFnfcImcXod/tQDB9XrE7bTwRX/dcuDW9oclsj5yPeK99b4jhLGnu"
    "rpHZxEzsloPEjRy8EMC0rNT0Rrgn69V6t6BLVnTryZpvwz4MMSjfe3GdxRUpD1md6n3rMh19CkefwtGncAifQkyq"
    "91TN4J51yF4atR4J8UiI9yFEPHsgfciktL5i6GC+3ftVKzjrddp9E6sheWqixV9JV+3V7ABLs/gX8kX+TFUtAkBy"
    "iuOkL6jCS/iSGLvl6+4WWxO0S3sh1yKgmOuN+clZzsjEGFyy2kbdf+CVQLoMKe4+ZlsAQVVvBeG5RSavXKJ6BWy6"
    "4TVc9c1e50OnpywdoaiN/Ps+9RiUNZY9titPM6dYUS4IhpwSwvLTCG/1XwUrTQafO3ZyzYTU1nrx8Mq5aFZajFlh"
    "xoFjUtinoGguhQi17PMASsqDR7AzFyY5rf4VmJYcoLveWOkujChOKjqVjiJk3FVE+0rInNxPCO+V8aCP7KVJFQzH"
    "mgOaNQeUjMD4BasA/ORTlnfk/rOKXxmBsgAikm46tddbytvPm/sGupciXO4t2MvOFcUM/J5YypX8aoJ6ddS/4VUr"
    "YOTtFxjIYa3ktYWQ7Z7nBChcBkZZXfY8KPta4c9ZxCQGuOgR3OPVuXrOgNYowYDcvsg6dUGdXi3IHpKB+XyTsWMz"
    "WJy9cK4dZKyh9Ovh174Dt9KqtyrxHBnTarzrDJ+VExYZ9WKF9hpMa42sNLDnpxFwUJKS1W5rzBeI+hToSqWRl9Yt"
    "RqjH5WJXAD2J3hOQ79D51xUz00j2FaV/DBAERH+IkLQHSrou5lyIW8yDxZ/xcTh/BEsPc5HaXxXeI5XtFQi7kbsK"
    "qGu9Ae3c1bAHnK1joonXHo+xap/m9e/sMRb+QnTv4car2skKfLRLLQ1eU72NxYcnotQ+JQ4a1N8cVHX/Mhr0DSyN"
    "fo1s1dps7ugyhkjce2YsrSVIO6QpmDDQPbzOGfzuSw4468ra5mAWa5B5S/jrDbJAa8muZlCaJswKzBPaKWmErS5+"
    "FdQTOsFu1zv8SU1QFjCFd+58RrUeaEw6ytr7YOi+xB7jP0pE0vvIhxSec8glZ5M1pD/aoOAtVmv7QQTNH/ZmhdQg"
    "YqCp/vNhC31Aj/DKU4V/LShX91CSJ1ltB1XzmsL5JUWd/oZNc8nz7T8Cqr2+ZvdJQliMQDQ9v/z1ztoAItr2jLm8"
    "WQk404MlWguO6+KhgFd2G+Et00Nw48PnCgF5qBpBVbbZQ46QIXGSrRqz1w2hyH5SM2b5qVdbzV53NH5AYakHfb0o"
    "Mc9DxU0J/CQe0v2rXm8PcR2koMeS1YJsUuKS/UkyGotOQ+1VjPaU6FaMkKtOZ0HyVvcp6H2fCOlYjuAjBHN6Jmcy"
    "efH1zl8od05RYKJke8+T/OcExt/DjNaXRw+s4DyqXuN7sh9TsZG3OFOggrxxPpQjLsZETST0XcrRHssw8310lkPH"
    "zccDSK+g45Ow/fc92jyANnF/PeDHlJTfgdx1RFv4/Pzwsu0hFi4E0+eGeWtvrZm1tb6/Xzd4t5iFORVCs/ye9TFD"
    "SoJmrFlypB4P5sJr8pOF497Ysx8gfYHsMsqSzuBYgPMHvk1578uIClLbI93m8V7e8V7e80omeLhzuwOnJtRR1mXR"
    "fywU+hyODL9PZjgDJA0sPXgn7Ji47VhZ83lkNXw5JT2PRtIzN5ISA9cUEvlpVQo9ot8zRz+9iBEKN+cx0ixg/V53"
    "1aIOI96pX+CIP9isFjYvt0VXJqV4Zi95sMkuEzAPfDB+QdlEK811dEStz0Lr0DqnkJca0M0v28Nxl7KkXrY/9gZt"
    "vMDzvjsaD4YfzYt2v/u2MxorHpmj7nnnrD2UXnX7552/w+/Lqzc92GXq86I9/GtnqHwo9XB2NRx2+mPzXaffGYo2"
    "3tAJb5P7EBNSdsDnFftO6ppnjBRNpanFvIn/VkzpzeCqfy4gbmIcdn8c81jqjL0e9duXo/eDMVBRu3thjjow7Lh7"
    "lvZe6udtp3/WMa/63cBiFE8j33Q+sIlKv6Q2PH/mPxgcr0Ydczj4zXzTHp+9T34r72P7cnw1DH4ZeSa17w+GF8BR"
    "6LoZQAxnBMgY+yLuSw8hFE+9bzQM1ed+uYnfFBJ1itf42dSBUUTlWOyieHp6kS95xWPlqcxXiwXWUWZZaqm8slgT"
    "ZvAA9pMXiYXZB9cbC4u2xKivh2TZKUpQVPwcVhU65FI078MEF+VOtYIwk65/+yyCFXAF0w9VMCyew1CdYn2d+dwA"
    "/YxW56JOBFrHL8XXxgrwcPPFcUXQLqutPcfXeXHkpcbjE8UNajHC3Lp1Fnfy9end0vHD65mUYxNvn/3tqjukO6pR"
    "ZsSY2dng4qI7ZmW9RbbwYWfUGX4A+MovBU8StWdV78ad4QXxEeWHHpsOvIR59npsVmfvO2d/vRyAGDDbwNeR+wXa"
    "yinOQ23bgAUf+BvpEwaGYafXaY/wZu43RBOZ43GARO7Gh7fz5FXxW/qeUCoNHjsj4QrPCe6fySo2TjkrnK0HNkmj"
    "OBwyrndgDbCU53k2TQ2E9K/9a+Gkegnf9rmf72n3fve56CZENk9rXzwGRdzDDf9OvHGv0b1OTavgBFQBNvFmQ1qE"
    "zbeU9WSMkn2se9wqnv6YoS5B3ArMcmqtt7sNpd4B2XHnOmiaSza+/AKvkEy3wUkHkcCfc4T16KRcCMgAf45K0ssd"
    "xYNSPKhFw4+jBDPG4OnCmHZOxL+ABrywl3kKg/FFBqWeontUS1H4PnTOQl0aRLXIvq0vRoAJGXRBipRt6xpQFvQh"
    "7+I/LdBxATpbVtRmZmy/OMTNZf3Oz68HQsT5bM9y9AUwkAVej9mt1wuH3db3NVnirWncEIOX7rzfJ3ZlUpxWq+VW"
    "cz4tTUvVljWfzKvTZqtVn09a5Wq5YdnVkl2tV1uTVqU6taqtWqtVmjSatfKkWcMTg0zcnKu8vbfmXwCNucILOD/C"
    "Cg7jYbvbowsWbwn79glQe1qyNIOx4suAx0sm8IjA2j8dgAATTHtGbtgDeBWpmAj3BwD69TrB/Eu+KhiddVRbZuzH"
    "XM3NkHEoKY4hxx3QsskDmeI9cvs629Ja6fnFIg6r/fxZyf4qtWdKzxeV5G1K9SwlO5B8VxHp85fDzmUbNApzNLga"
    "wiQvBueEMCiwhGCMoGnhzx5R/Uqh++w1PcQgSoYRbuHPQaQxS8XZr6cgHU985AnLJt8gbo8HFwDjN7ABPZhX5+IN"
    "eb9GwEThtyiEA8D70IEFAprnTs47wy6qOR+6nd9MUGvedcZ8mcMOwrd7cXE1br+Bz9lqiefg4SaFjv7zZLbboNJg"
    "8jMEEtq//GLEOjniFxE3INmHGrSZSHgRMo1ScgxtHunyedDlQU6GIliZUyF4rBOPa8iYa8kUMTfBs7fI8WIi1n7P"
    "8yjVurU+3KN4RRBmWqbgHiXGjydsxxO24wnb0zxhyym1Gp/c9tBsYtSJGJVHy9EWy6vTy9a/rCNEV/aZ4KmhlNDf"
    "WRrL3a29cabeWaJ0WOguAAB5F9VfqhLQf3uGlXvzG3sBa/ts08TZmhe2RbWi6ZOcMUPHR86YWNNP/Ak5L+DFakv/"
    "ydMf/ateznDvbhfO8hOlBFuttobtTi1yzvh1o2U4sWuZlFMMZo86uS/4DSYA0feygQnRI+f2drelvzb29W6BO8Cl"
    "vdgR3CAfSJjHBMbNi7cwiGvd2jQS2yRrQwkkw5vnpXKU61qjMDJure3G+So+Fpe5PFeTiLIVhkaehmIm+eFOZZ+Y"
    "uqTlXgn5Db77cfATg+G+XhgKnruXD2Z0NrjseGJ3RGYe45Oe5VzgvieDOaMKwgVVkPxOjCSYR1bEv/OK44IcgXam"
    "N4bKOemdpnP6Ojn4+Z3kNdvnXDXoFg6FVEYcxv5DL1RSDkQIvlJ2Fg2xhH1eYr5M5q+IPkk8QoybvF4RxOj6snyn"
    "Wuc+36fn63aX1tq9WQGFSrStTBMrJ/kmMiKUSWt6yLTP6n3WLXJ4iPPgMEYlnggHG+ueCaeg6FM/FQ4w2eO58PFc"
    "+HgufEDLRjq9ZWo22TJCdZg51xj972ep5Ee+IrkQ5s3cTYEUMN86ZpPekBlAvVF5F/ZeHBUjBWPduNlmtV5T0mKs"
    "khY5bfbaYqrO7Q6WKUlapRHmHVzjAF61N89+QP3QLdAJswvGUtC0IZPLywdviFaBZPGgEs92U3tT4Bc0Cjcrd1uY"
    "Arv6ZHiJKaLnz+mc9zFPoJXSQ/8MWui9vPgParwhZYL3xaQGUttlrzPumL42jTlZzTcfx53RiaxG82MgyvwN9AAm"
    "JT9DMo0/GYvVF3szteh+yNefkqbw88Ock/+IOms2W9ITzErbiGB6L9vostfumyCBgDGPP0qWkbVYMCeCIEEDmfMs"
    "Tyd0xnbFOWeQCqI2272snAgSp5DJy8QxH7eOdtDRDto/LjbF/lFFvWgHxe5n+KTJPN0egmIuOY8cCD6tHBff2yDD"
    "BR0NsqNBdjTIDmiQhdmFiHllVpG42OExJWFTMd/3xgaxuKTpeGchqCXNwdSRbTUqjsANNmbx8WpYvgSntRpcuiAI"
    "yFoqiFV7VbaE9QMENr2bgqDD62/rm1chL7Rr5H9lc8V/hW3FO6VReFEEeA2223TjrGFr5ES2hl9j3D+BYiUUtkBh"
    "aCrebFa76xsDuN8t9eglPYyNDf7eNplaoj1eYPBRfdVVX7OZRJ5olBUAhQH+XTMBKA7fjskBjqFLx9ClY+jSSwpd"
    "evbBR+qoo1CWgmAUD4qaIIc3yLVOWiGogxtDiqN50JCY++UuCIrMpxiucs+EBnRKMgUblXfquBSfwQsvPucan8BC"
    "uiPkfL3Bb8BTwHoEUjcvuqMLzuU6ve677psuOnXlx2+7Q2DEoOWedxQfAWMDcxC0YTATUXb5bxhvGb3vXspPhaH8"
    "G0gi4KaBN6NBD9lJdJDR1RuQJaOR/Gw8+GtHGi+gEqUsVWaIRS1XhxI02btJAmX23uJAn70n1VZl7yVua/fpKQYV"
    "sncVRZ3sfYRQLWsHz73uwotnHEmSL1keHFYAvnhAayTpY2lmAUBfMQzy2QvdfvsC1zd+D/s5s5cr9IMxP9rgAzwC"
    "LTzy4urSBLj3Q09Bl8TKPrwes+lNwpVSRm5WX1w/geIk2Mh76pdI3a4+2Uv2VUB8xk1aZnyloh7vjFmm3FWrqdWT"
    "Ci5yNzW9CcUDMnAEUtWbVAD0cgfVVl3vEEWxWXI/FU04R7Y3AJqyVh8SPshf14s/gpR7RpSaLK8i/POwQuoZwUlf"
    "3Gxsd7fYPmdBYy0WMKZtutbcxsKDs5CrPSlLMjur9QMkQk56PLfdOJhv2N1hHsW7SGZl/yg3oQtFa9ZdYuPJxlr6"
    "5vfDp3SeOS6dStBNsYAWglwEmM9mt8ZuXXvBjlFERbDVxLU3nzl4SyXvuQC0yIT82VkteHAIbyGQHYZer1yH014w"
    "JfMTzPpMJGOCTLAX4STQj5L0GSucYeBAKvaJZrsZRvFgQQMsgAb0t7XDb2ELrOuNTXTm7U+gBWcYyq/V+MybYFYV"
    "G7ZtR1iJabK5RPRRCLATcA9wc3sD0L1ZIfcJlp9KJHKt6JcHqWCVxED0grmiPCa+ziGd2Cq5Eu83xOazcSv9+eox"
    "tD36C/I8HUDEsks9iByLjh246JgkRQJ01RuQGnI17JmjNoZjg1V+2Wt/NPsYhlQyOx+653iypUd3YSM5CU1UdnU8"
    "eiRIupTT3hKPHlQJQ61P0+Slv5XFLAZanHA91k071k2TNZmU8rohrechw0AfuWpawBL6kWumaeqVerBPUD1TCzkn"
    "aa3RfUhRY7V4b7ymm2WyIRU5eap7q0y6arXewhWaN16gsr6aFCt48qqSO7l1ltKvJGEb7Y7OETYzOae3aGSTW4X7"
    "SAJuFIwG8b0tSI8JBdxFd8+q6J+IoEA42YYHLYNBy80Z3D1ieKsT7Nrgm77C/CWfV5/wIiJeXsS8eRRiK0XXrjc2"
    "QR3Ev83z39JUsVm1VTck3cAVde7WGLOKYa6eBWfIVGUQchm/GkWW/T0O/39BtD8bm+2r8y5GX50N+me9q1H3QyfR"
    "nyAqtunbjlJfhoh6NIgTO5MdLjug8RsXnfboati5YDFh/qwILt4+FHwry9hBhxsM7N3evTYcgMbKZomCnS3MfY4x"
    "LFM7HhCwS3iQtti5zmf7xyywmGw0Moxit2INwjMRX/Q8ajMqVX7RfxD5xIrVn/Ac1MySzUtO0HRnmhjuD3uzIn/K"
    "rZFgHp+eFUtejPpZuWL8gtxA67uq/12xDt8legaRzcjkKRoYwqyQ6DSeML1g+hvb2Rjc5ZIXlxFgSoWzYq2A0wkC"
    "G53hBFPOidDS7Hxo967aeBWlDwPwe8Hn3hAyPzyW0nzUUppHL/7Ri3/04r9EL77Goa1kex+uOuqRoxw5ypGjvESO"
    "ohXeEEWh5x9U52msZrvf7n38BxY/6PRgzfyus3h71RfvKQxy3BkOry7Hwdb9Drpb+M1sDGTkd7QH/d5H6ECEPAbP"
    "YZMmoOVvUs5R60vlMrS+DK5U65M4YGh8/NzDwb4TjiVrCXHEfFiV4TstfU92JsUL3JOfSe/Qr81dk5TGjG7Uer24"
    "BflqFBZvB9QrgIBzC39m8u7XghA+hYQ5n6LY3i/UC636oNpoyh5LZMWkum1Xa0+MMFwxJ3fyXOQb4QpfYoI+46sp"
    "NAtv+Oz6S6BFXMl70Dzs6Y6aECQU9edTr9n7PmEGGUH30SibRPgmsL83g0GPJfCJbIAWx1XvUerZfqyUjz/iD+36"
    "PrHLB4sS2H8KMcinNfwhQwOSUDhTPzFY/kSTwiYxt0dMRBRH1qmE+oyOypScAV3p3Gmdfpik7OE0RnCrCUt0laAi"
    "GH8yYrqM8kTRXUBLgA5itAR4E6N9pLFsOqRTL+kX7vOPwSH6MjrzX4t7ncrEe32PAv3QAj2rKi3zrYO6345be+it"
    "zWAqUMYklkP4+5sIa9hmhAAK49s11lcMPSHTQZ56QbGOPc2G9CRUfChAfGeOf8RuL00m+S15Ve1tFtTgDRhKBjTy"
    "4Kv99MQDqFcp8MnUiQqE2TsIQfmw8YBRxHssle4ZqWUB1BQ6AFMpEnaKZzVn+ZGNnwJYifwlJ751ZjniMux7llbb"
    "sDFawHZZQSvKjWNEekiluAxT0Bzx9z1z3z0xtiMlQ9OhhyRV4dmtPhLrbs0sUC023qHLszo2oJFNPyEQyU1YAK2M"
    "s5Wzy7vtDRpS29nCmVBu8tPFypphbfu5hYGGXsbMHMawAWdA3X5huds8ntrY+S/OEhrv1pSIyDY+2Xcs3saaTm2K"
    "9+lb/UJ3OXeWGI5Dc0LmgZmrNq5tzC1nAeqfcWutwa4qqc7cBPM8OWMpkPKd5XRF07BAwVtuC5Qhs4BBf1sHw/NE"
    "uzHQNm9DiaiM9uis20V+dzV+m2/m3wwujMlqdpfDR9Z6LXIpFRAMhT/hf9l30xuc61aMt9vO8038b5MUNQuRn13k"
    "dbhqJPDF57g5Y+1QvQhQd7bOLVa3QNzJsdynWEfPXs4AxMjacQ8Zw2ZrgqabHOPNQEloUl0jMiAnYoeQBg8Kvd25"
    "W15Qiytnrw2g3g0CQEA1jyuG3eUgdHdTPPdFgYDRjLApW5Qx2xt4gCkyaVfpEI7azXeL4EErHgrDgin4FAzVq96Y"
    "z8lloAs1hpE6f2+fUaZgaGtSbgwDCA7koeMGmsM+lqqFs1IN/r8OeE/xnKjQs9KEckClsdptQSraDPOWCCUD4L90"
    "iaRmYMMCsKBLl4KGOanhmTRDME4L0AnKQUONfwJDq6KaXwCO2DHgg+hqucqzjw3EsZ0LMyOkybvO9Wtjtb2xN18c"
    "V8SLsnevw7RQY35KYiicbI7UfKTmIzU/X2oO2aQ+7cbSiRIlUzYwHizyugImpsRF/OtKT5GdpBtfcQxHWtdT5Dwa"
    "VqWCN/mLenlMSgMiiWzMh83z4Wfpa47leNJy78f6NObgM0d/1ANxyXsn0H3ysTXfm+trnAzEmL+nn0vNwx0OfG84"
    "6LvREyJMH8OrLsZyCzw54YiVroMf3Q/tHuUCxxInQ8a6PpSa+4bWhN0dOW9sdmzhiXITRLk5sW+szw5ls2KSxuSS"
    "JrCh1mZpu67qzIOxYsk7I43L2XQoNEXhjtGIDIlz5iTlB/FXHfAQexsAEuJy0B91ojsB4NfzEscAM5gxoz0am3hd"
    "qYMJKUeaKdCDm5EJSJGNjANRZIMzDaNAj7iBsjnsE0iVuJcWAOMRM9Mik/A7brUC74PXr8vFwP3rcjGXYRoyLFj3"
    "J4lXqfm0AfWfV4AIn4vnIjECee4Pd1VOnAJwRbh77qfCZ6UeY/f9lH9qeiCmdQQVcFgcGFY72Gp+yICK42JhlIue"
    "7iqGW+EtZ9DoFsw3TL0T5G6tO9Kt3d0EYL7Fm5XO1jVWX5awZ5v1zo0LxXiSAkBfYYkl+8NFNDxJCN1LleE84Rnf"
    "iEALxpxYrl2vAlzol3/hCbbiekW3syLWnhxRIjaWG2vyKw90/jumVrr+DjmhKFp5SklxeO1Rh1Xpk2etlzRNLCw1"
    "Zw+ffXTPTQk4ESEYhVbKQCrwRnuNg3cmyZqwa6kBv5Hd3G9kBVLEDS2QZR/lwUe0ZI1BI/J1+BeMe/39X+Vv5j/b"
    "+X/A3+bvf1KEvz4joS8RjRDw0kzJp4HH9RItquXek2Eg+4k61sVhBd2TAUl22ZbAYp6rhHNcd4cqzcz275j6dSnD"
    "x4LMbRJy8UtdpDDy4GXiwNAqb3vyXBKqLQc826mzCu1mXIKtZ8S9uEeabz56w5cIAOFa92HKk8LAPhhABJg7SXY+"
    "8+8N+jb0EXnm0elOX8dwv8AOe5iTgRXFENxhGdLeJLA/A1GpCs+VgwCk7bWoyi5lEsvKRsL96ND34zGJ8I79cFyC"
    "Xnl7hEVz/n7WucT6blIP8Z/P4dWdgZoUHgHOvMG8Hg226zHBjvfgHeGdOyzzuB/2Z+YgUQ/ss48a5GfXALAt9xd4"
    "jwQ5UHKQcDsJCSqn1VN0oBGI+Pkzpm6k8AIBdHoJAGc0yR+uKRDBDHrK/AgFv4U8WKlyWpOzhPjvyqeV8qleeNXL"
    "XHZINkQWmbCe0DqCM4+bcmSiivkFqzpHwC5FOqjgr5GmP3aH/K7FVqX3FtxMv4fgrmr2I/bd70b7+xgUiQTxZOlM"
    "CRiOVjrxN2HE87vhGPjyz/ifCkXpC+KgyDqs9H0q0Mgsx1WHnM9fkvNKwqAHOddL/ACmIVZ6avLXxi+8jLQU+kWR"
    "QoIKmHcN+l8s5O9xlJ9+ZuFVsIhPX6zNNTmFeLBdzLDiNQwrtuB0t3UW7ikWMfY+RoIUPtGfvI/5g5/JwSQUPRHH"
    "B6OEtdqwNit8T7R22CqUih4mnIqrmLZ7ema5dhdGXOIN0M/2uTPdygc53CLyP0WEgyUMeQNf7ZQm559XsrtIEcWc"
    "a6I7lztvysWiluZy3OYXsM1hTS26qcEtUu+AEmAKcEQWGV1JcJZBpU2Bcb7sz456GiE0MnIqhorD0vSelXisGOFQ"
    "CK0xIwXK+xNKx/30EaLUIS9Yl0wyRGh7HqTIKFGK0uo2SHOSyaBBfHoB2B55ep0DncZ/3O2PX4Ay+/SYjr5eG1bh"
    "DqzZPj3QZFZyE6Pdnr22qwi5QqfqX4olkxUGZ3Ax+wPzfad93hmOsNT3X4rl4GsK82QN2PuKeTV+2zSvAMaD8070"
    "fdU8v7rswQaMO+ZfOx9HJoVyUhAnva+Zb7v9LrzsX110ht0z/rhujgeXZq/zodMzOeeh5w023JvBhT9T9qbpv4lM"
    "omWK8uesTXvYoRelYvBFty8PVip5b6nH8fCqj+s4Z2/L4bftbg8+Nc8GFxdt1qSCmfXF+tp99rAqPeyyPz6yNzUA"
    "4+jq8nJAaY/Gnb+Pzcteu8u/qwfe9trjbr/E3jQCbzAEGusGdPqwI95ammbn4nL8EeBzzkdr+QCj8McQQMtFGPyK"
    "hVgjPa0x9Szn2oCKGOA3FJULuK86Z/AX/ABMeo4M2D8iZ8KYhwlub+zovRo8qsAb6RQAKIblcYCxd3GS4gEZcYk4"
    "QKCenLG6dVyX/hLUnTNud8yUpjtMQes671Vs4LGD3gE9T0hS1rJHjoR4JMQjIT48IYYsRmXIsQ/K6CpDnQYsPBUN"
    "e4rwkZiPxKxNzHEGEwwHG+orr9T+W4D4pfKij8EF0u3CCJ+Qyu0+NYahffklXG62/NKt3AMwSn2rNP6KyEHN0wOs"
    "aV9zUgp6fq4hU8K4FxY8v+uBjwjxlc5Pr7FOTFOgu/QPnjmJ7UMhHI0exmuTsLFaaB+uDcNDmV5AtKCI5Ly1t/Dn"
    "1pIvYHsxdWEwmqspS/1At69EJlcfrqnvAaKrBeOHYgwPqIB02HIWCRiXa/KIr5YrM9Axha+za6NSGx4+MjP5YXTo"
    "YRRJpLe39syxGLZ4NwIFIviRqozdQt8zcwKY/im2/JGY1Mb6IuexjcxA+Z7Pwns+R3TiA/r5EL3X4UJXwRexpzsa"
    "KKEZwZ2IVLE8Mh7LNEsLJCFi9i4iuJoaVJ+M6PE3pSKYH7gCfVaqUjx4jf5bp/82zMEQVXrSvUdo+rwfjy/Ny+Fg"
    "PDgb9MzLAZhQH80P3QHq/ckKeeR4KEJuKQuPp9LICOlkmzKWDt0rRo0wAh3ZncQqMn4vMROdLxPYDd7zwDviZuIG"
    "BELpkzfe7HVHY2aARdhY/Fx9mlEzujSUkTlUmEVGz/0SeaZWfHosV9UKTE/iuzowiuHMik9jYSRSnZ8kzS/C39Mn"
    "94zi5Ak/5ILJBlsbqwPs36Ah6sETe2b2e4k8mLPC7Pyd8qgAVwzkVCmXWE6V5HvzL1hdStZxlLSaqu8n68+nn8ul"
    "w1/cP2q0P7hGu5dlF6kT+th5nzIxqewJFAiyDGwsfDZ4B9RD1fXGntozxHcVtYSSYnjIGpssg01Deu0s17ut/CAB"
    "7xFNeWY9Gf+kjzWqbBBqLJxlYJLbYNLwaM6NUHEQ8XRtTT9hEVV8u7RubekVj6s2aWuDmSJCsJcPVFgaTMz+4kla"
    "au6irxjFoJTzhYWXGH/Ym1Ue723PWFPDpxfOLbkzmq3dKBWLp6elVgu+h07nyA+4+KTaKpRQTXxoGWhHFEqnJaNc"
    "LPL+v9ysXPScW5jmcn2zgaFZgsz8FP7MO36AmEiQg7WYlku2XD+7Irq9MU/jlxt7CSMtLPTcsyHsr45L1dwYlMhV"
    "j1lGYVREBBTm1BARaI6KB/uMvXVz8Md2t1kanHj6AzwkAsL3qOpNb3D213QjyNOF04lD3sSzYun09KxU8ZM+FhCM"
    "ht8ctKGNu/X4v+HF2Bmo4iycmZH/lTI2hvkAzOvqbHw17IjDIwoQmq6ul8jSDc/9L4iDkgJ5ewidahiH7Frhyggs"
    "2tisvhDR2ZQVVQhVQ0q9F5nzRWfcPm+P2/LxEpqriiyrOCRLS8lSViq75ZnY5NxrV31YxocOHnGJKRXkfpjMRx11"
    "tzVYakH/9EicFu2WAK7PgISaI3mdEhXyTlgXfi5UyhTLM1JQ0kuXdV8Ld8AaUoZDe+bSRClfq58Rl39ZD39JzbwP"
    "qU0DSOoLiJlMuB3H1H2c/tdJMEE20a2vShgiOA11e2/jXnO+Q5lA8WIppds1GH5vV58A4C5uBZ2Euex5Hpaflzdf"
    "7CpusLVAbkV3VtjhPPXHesKjsKXc9fXGwvpW2HMC7QQMFjxgZOjoLc2F3gwp9A6VF8p0jBG4SMOGrxAa1hwRYXQJ"
    "1N5+A8Tv3N4CPF+z67eMy1H3rDAVK8suxAJIKoAt0tytlXdt2Hx8zdZCzF8ah0RAjiclXqy+2BtkvDka0Rj8NspB"
    "N7D1a0AfLzkVZdpFkxF5Z2TmTC/4lv2UVi31ZcRhSxZugBO+F+KQefzxsmO234zwbzxaNs87l53+Ofz0rwyRYrQg"
    "OcAQarf8792KDjl5emWC0uswQF5jytkmCFPHctlG8hS0bD8xOJi20vXA9Zon50UY8VeY6FfM+X17OOqMce5vgWOO"
    "ief4fhym0LG5FAI4mIvOLJw0mrES6eF/sizSOLxHDEwTBzVjS+dsJwzfkE/ghFFG0nzyOB8grWtU/3KGO7WW/Kxb"
    "yE7AYsPrSZjvIEit5Z1x/rerwbhj/FT8Wi7/jGSFF7PcBRru8Kw2/ZnhDQhZLFMmdSPmgSsJyl/q8dy8bA/bIBLg"
    "gSQPTo2BnyiYSABVBKav2LcO7MwKcX9rbzl+E+vhNJbjg7F0GOwrj8/4M+OgQAzgkbbSMbwtVBRSpujiAG1eXjAQ"
    "1OtonOBjwo9Tow190XB8kAI2L9BLPKlfbB3Q4uQhXDq2h1nmGY6QUpfApE6Ncy+dOn4lcN5fHo7osrzcNxamovbQ"
    "20O4vLcICUlZynboCLgBzklFmgLXT33ZH6qVQChnMJTzuDaOFMx9jgNw8mPwgt9MMFAHBdE6ThDA+IzoTW/hQgxw"
    "xPUBwtbFt9oVGC2jcs5XYGIlD6GCBgaT44vNLY+proEEMM4DyG5tMyG+8fXZ/eWHryrDcAEVikQIp0rgLAIhharG"
    "XnPVWCArzVMph5jawSW3N7fXZJNIEt/f9pwEeUJ4F2lVxgAWwc5RdGL7ATlbOU14EvrtK5qUKX3ProY98/zq4lIo"
    "1agOl0pmu3/OZdDgot3tmx/KRb1zkpBRK0s/X2ehRkgvGNADOMI5m6+2sH0iQk3RWaCJScr5xqFQ2xMmXsLWl2jK"
    "ORZmhPvn//i//uP//n/+3//80+n/Mv/3v/+/Yr7Vzv/Dyv+RZ3nhVhMwdFc0TaQotJJhv66dJUmN0SVxCcRNf4KD"
    "NyPz7aB3DrbVX0ThW66+UO4EhuRssUKtcX2eymgBrGb81xQoTxeDbleYSR+xfgFGkpAs6E9Z8Nngb5zOPtgR8jsE"
    "NBZeq4J5CcDOg+HIo3g27L2FucJ/AC2Qb/u1bbhtjTMSJt0dsJ+vCCnandd8fyW1AoQkXvpAQ57JYPpc5LDrjgb5"
    "ZrPWypdQSIGwyKOsInjMsRoDinB+7k+8Az5laOBxNi6QfS8j5hdmrvRXpWK5iteYpCUKdoqqgud84IshIQVMw7Zu"
    "GRXvXJtkp1fXYwZS4dZBHoBwpFlRaYgJrvRsiJhz63yFhgjEQu9tCo6vyIXzhxeHS4wPOCrZyMC0gEW7fHKmaPsL"
    "HWgYYH0bVIaE0OXG48FofANVYD4dwKLdcmoxQ9meO18RaVe7zdRX49iGfNlg2VgU0mjXLYx8fra7XYuyB7gPCAQp"
    "6I6BDbaU1Tc11gvACpwE65WvIHDtcQ/kTfKRBTDZnTqOyW8ncUhyi1ReJeAfGaGv5Uod1zugVRiDVT/EJRASsFFe"
    "S7an6xZETQc82UEEJ8gyfw5ugqD7xR0lFrwNzYiTuqySCYrvvDXevDHevJUoQ1JlyRHmivoSfAl7T0yY1sxUIYLv"
    "D4LiiKQDURm0V770QmIZIgOf4ON6tQgps9mcIQCMhHgsVpljmghqehYlbPJ8XWKbgktlcgPWpjGVnCdnUtv7VGgD"
    "MqJdwLQBD2exC3QiNt7KVYCYZsHK4hAIY0cSEKTuk5sC5lNr9OHB3BCgcrEHjkG31jpQjWWBXgFy5aASt9pthVeG"
    "Fabx3Cu88pPUYcreK2CkN+09iNxzdcsUrW8+v/IORXz/H/OSOq7hF5tecIdMLqhTQhumt/MQal/lx1dAic5MuG85"
    "dwjd6c5L3AKgxOfteQQ7ve677pteJ/s0hVobmK6szXubyaYeqf0ETSSHTnhisqsy49zIdRdxkGKeNYKkkBqye9Kh"
    "EHaq3eMbHkIpoYpD/hTjg3mkebLp3QCrsAzJL4yGo7cE4Rt+La3BdxiTVc8LBQU9wDRxa2kt7kC++/OKim+8fs3l"
    "XNS/DWaA0IkJNrcT53q32oHlwsNB8wtgNwui3t1ygdKIyU+CyYpi+0F1KwhlYOIsxbay0588Z3T7CNbomVJAnPK1"
    "m9fMl6U+jmQKEos18NEmFaCyKaQTwZU7sXbA2zZ0lOuHkJyIIdnRGwIadTv53IurPMGmrJQuP5Iyrc31jmfyyOdx"
    "dawVP+n97KwWXKKJALV0JJXPKcxIR2xOjPPyaRURxfDPsvijshcf1S4nknoETPEJ960HXtKq3648p5RxkR0iCke4"
    "Nb3xHV+MB5DdJqqeSaqVfFrEjBYc5DW5UJhDhplsZPzJSnp7fDUye92+rKYT4pe+yiYm273/+q/TfxZLv6OV9hNL"
    "Ql759vNP//MVe/Bf//W1XMzDfxv27//588//8z9EV2WzEunrp/K/Kz9n6IiDDpTXa4QNHXfWWq192EHcsbC8ETG3"
    "XN8XS8KvgBYPu+OF6gNejnpfLIuX8Mq/JkWvKnirazC8ILKByYzfd/rs/JK9r6L07+NluvCbmtlpD3sfzfeARqPI"
    "2zobsqgiTXjdoNflmLdNeluJedtCPQcmxHQe/1IbvYUR5bfypTf2vsTfBxVWqUGZN5Dv2rE3Ff4mrG/Ryyp/Kelr"
    "0qc14FUdUpyUPdfNIahSeFvPPwXEpuxtw/NM0Y09/rQp3VUUhwX+x6xNS9FGOlAYvi8X+U078buU6H1kbcqBG3wX"
    "nfNum72oBK/2sQHZq2rqrb/35ZrSvwMv6oBZHXj6W3f8fnCFS+jx3So36H4kYD372TQvun/HC4fIOUA3hb5H7E3L"
    "P5hvv8Vllf7+dwq3C129DacM4jqFd2TMrCNxoc6Pj2AuMuHLFFFYzA8TvGpnx96vbe3BNVQhI9INwWJxOqnbrYld"
    "r1TmU7veaFrTYqs0qzRmxUqtMp+3qjO7PrNrzdp8Xp+Um9PGtDSrFqvlxnxSaU6SIni9WiGxASqh4maxUUYfYLMH"
    "w1EoElL3MmEo/CUwqB/klCByeTfaAz/HulWqalWTYqlol5q2XZpZtcqk0phMG0XLgn9rdqtsTSq1WqsyKddapWqx"
    "UixO6q1So1osF6dWo1Ss1ovqiCXR+wFQLxphsp+6G47NElO8Rm8eO6S01wsLr9DyBkz3UtXyOMayPXIsW7YgX7Ue"
    "fbi6Jcftf+Ttv19ArVTw8EnE0yok3R61FgS8+aVq5T3s1C0NKB8xJVFDQ8WmHtDKN8Bd6nyTSF7xEkCeehV8Kvyp"
    "gALOnMeqvE7UtPwq4QGNa0a5DbbMTYc3XjFok0PtUIkN0pKXHG20o412tNH2stFY8i9enfZISkdSOpLSXqSEbyp+"
    "FinJy8pe+Smk2AT6AJIMsd33930LQ/zxXN8x6YgqJf2Pw9W08Vupmrayq0BdziA4Xm4NbVFfmjnNuAmu1F0TvRaH"
    "8CscyBnw4Jr4nravTEcHLHL1wIvdw9J7KcWlJatHlENlzzzLWdg5foBd6KPAU++z5Wprp5WRlvuBh+ySnl89WocP"
    "R2esVWTaW1Rq7eKUXEhp1ZEPskgVhLWWSZuQ1DKcHU+j2vL7l1ZtOal08qOSRxaeK0ojH9TF+PhL1uO8mBje3eFx"
    "+Z35uVw5uE8N7xYbLMrV96qJftyCtA3AeE3Es8Jmt3QLf4b/wkJ+LfBQ3UJwrnt62VIFGRsV/vAUB8+tCXjgzCn3"
    "oUAJD/xzaGdv1htnqXrLo5LMmQN45josRwMHedCTGnQ7q9uwAM6kDiimP6bB9gbgeLMCmKjfW4sFSEt4YM1tjN+d"
    "hd7zXQAWZi/kiphTAqCUaCGEWmGoBNOEJQ6qxY1TFq7fRyL0tbpJQgatDjKgnlZ/uvin2Zl6x5m55Nzubk9elcpk"
    "LLEftWSjqyl1yrAqtVxvAAPjSrrEIZ7eIhkXSBHX2AoFtpWf//6vevXbfygzKWnbzzJ3Q058X1u5ohkmFstOtECV"
    "zFA0unjuysxRpDwdkcL3Akk3hbiSFLvjnj7Wnv7OeS3wVGt6g2qbD76HUEYVB7xZVFF/mm5hvcHbR8qpP7huKo2N"
    "8brs4czGiQBrkmbEbqSxU3d1i+C2eS0Uq4sibCbcj9vmRMUwbcZaEioNMFo2fBbIfBclT4ETKerLemOlqy+62/ZU"
    "1aoYCn0s/erHUW5eOE+K0ywS8OtQKsbzg+zvHq2zS3J+g9UEQfCsCzxsWLYLa2suXW2dzj9moY6iDTxYLlbXVAIt"
    "gKRLjL0yb+yvETwJ1pMIzC0pP/n4zOyPDuKsSFlhpj7igKAtXHw4pciYdPnygvm+R8ne7INHuox0A8OKHmOOTJ8e"
    "UST6+yXWlMqps3j5fad7f9A33w0+dIZ9iqXovGuffTR57AgGcXTxgnV3/NFsX43fD4ZYfwuRboccysaxKCKAHZMp"
    "GSlOO5bLHsZ0+m4sNlU0CnklY4B4FkbFZOl5eJ1CD/UTMJu3WC+sZfzbWNJxlgBm+KLaqoviODCNbbJ1dSib5sl5"
    "vlOg8T0NKzW+asnsKPrfV9o9HSGegP1aHWSwCyN882gVHsoqPDLoezDoBFNTjbL3NDSPm7X3ZoU1sCfosxZzKwS0"
    "3of2UCuRNe65Ujk5oK9QPZm06LRYzTo+LC1xdQ8lvo5SKxqUzC1YdzefO19FKHAa7t3L/bkvwmsw+3ubqNpUd/8F"
    "a4adwbc8f4/E4J8a52QzLKgnuycHRSIBMxmkGe6ine4r4SNLFS/kTUjZrlCx2dDQGgwwum5TsYI4dnhvc1CxeJlr"
    "YbLOBL71ZjDofb9TJwXKHBl1hFEnoAiOwVDhp6kFuimlI6fAhakob+HxQFyWoPbgHuWMADBzRhSnckYYp18bLsuj"
    "98m+gx88VyYlfeWpg3tvf04mXZZWnokhvNccBCPSZAhQEkMXKIsQwKntyJ1Gmb2lEX3Q0o7IoOcRHvKSqC9y4L0y"
    "RP5outsNS/LXT5kNee67aB+nwWrLXg7uqZ89QJUyxKrVas15qVmszezGpDy3m7NybW5X4O9yuVWbTmeVyrRYLlcr"
    "dbtZLFUnpWarPK80Z63ZpNqqNtQzSU0RoZrKAXKjZJnKw+ZRCVyjiqKKj0Pr1XqHGWtne1ySqsR5/B9bkKU59GP4"
    "7b30phTrk00+m/6kBEMEmPdRo0yVoH+2p62BSDd7dm2b6hwkTJGjAkoWMqTgW9/ngPvhpZ0ItQrmi4jvjcOc1U+l"
    "tm7Ut8AbScUcFe4HgMUUlmbFvc96ThYOwsvkHlF/nOg50ZQEJ1rlEfW/UKOAl2Mmbt84cbI8cNGASRY9MTEnhP8M"
    "R+Pa2MvZekVs4cZa27GtBHuJeR9QtaJA5u1mprW4Xm2c7c2tD6toI2nZqNW6WxWKu7sJtMPE5nFgp7oucRgVehmZ"
    "MXu/XMF3q91yFgdqr6idz77k10TKqheZXIcsHS2omh6AlX3K5T5DBKlCs4hJpcGdpAQ7qFdMi9NmA3QeEOT1+qTa"
    "tEH0V2f1Yr3VaoEaUCk1GrXGrFlutuqler1WaeKDWXHeKE2nWpn7knjhdzmG02G/Wh1l3CwJ8PXapAW6Vctu1ma1"
    "ZsuuT4v1edmuFYutWqNSmpfntUrDKjZmoIk2ak272qxWGrVpo1WuVeeTUkkL8HoCJIvpmyRjsvQTL4Y0j+WSJNX3"
    "ixPa4/bSoQ8p957C3kecGWWvRAQHsMS0LohlkvTS/A5gnt1rfk8h7WqKFpPlFEEpffU6SNWFsnWToC5l7EilUWXr"
    "IlHpytJVkl4mY82kbBetaqlctMp2c9Kct5oVuwlIa89LjXp5Xq8VK/B2NqlPy8VKa96EP+f1imU37GKj0mxqYU0W"
    "LVBvjSmKopw00K7XSjXgIRawlVrRqsxaJatoT4Bp2PNKxWpNitVpY16vz+qTiTVrzevliV0rtapV+Be+0Fpgglqq"
    "d00xUXPN0EWKcqvXU5L+K0G20axXq61i02rWyvOJVZzNrHKx3pw0JvCsVZ5WJ/DKqjVq80m5BIpioz5vzaqN5rQ2"
    "L83KU0sLsjHattZCtHRsWQCVqs1p2ZpWSnalNG01S5OpNZ9MWiW7US3ViyVcTKNVt+t2tTRv2LVyeQb/q7YmNQvW"
    "1dJZ0HNK48y8KCwm/hUOH++Z1TIHfzkAr8mmXfxyCOcuYVEyv/nlAEwmo2LyywG0kWy6xi8HUDD0TNJf7m2HxnuF"
    "j+66o7vu6K47uuueirsu6eBIeWziHvROyJEnHnnikSceeeKT4ol6h8u8YgObJvCUzd1zPkqe4TY6E8aF/MR5ok7F"
    "Jhoxp/oiYBZTtWhFZkheJUknM6QXSPZyyhOpTYMooFMiOqLYd1i5rIsPWWjF41/fP5Y1dFPDLfw5enfj14Jgvd4f"
    "ZnQt+4a6iqA907UAN4nl+fBhkJ6JDXYjD0zAKeh7hYmePIVkYW0xxyvwzOmNwxJKikcbe2FbbuCRewcs4xaf3G1v"
    "UMaTEoJEJnIkRF/4Y7FXQYXKf+5H+IAgmK1gSqsZEGVYngfe8UEFhBULTA0fwg//wMRLTBCEjqMTIZ4S7qv4eL5b"
    "TkNqZEK0b2g/06OLFeIllB/9WzpS6B2ChvFGizlHUCvbVxz79D5SI+ie32YCjRLNswycQYYlEYve0WeUnvSGjSO5"
    "A1/KCXPOx0vjGGYMgUni1eHO37GIRndsDoZmv9390DHbIxNevLDSiCn8QoRlK7HBmK8Wi9UXQzJDaMVeDTBKtGxM"
    "F5ZzG1j3YFQ47/WMDVh5GCI+xdQaBwy1PQrSRxGkWvpokLYP5yQ67vGj7LGGMs/6NzkHegxF3k8Uc9k++2v7Xce8"
    "aPe7bzujMVUUrJzyJWdWwbfW5treClDyX7HRjIr3eqfZ0igvypDlKzNwZfAh2Isu9UFjcH4eni7rSM3IdbYj5j5o"
    "ECkPy3t0pqVDN0tr7d6sgBZQPkJ3QBs0Kqn26VfjEzD7hOp70a1wAVXEMnZFY+NuzU82kJ3HQslezZ0sLPUbWM6X"
    "G5ugtFl9EVWiirgGWJ1iqNXy4KP96+RXGvJblGh9wPmZj/1nLCOg91OwZu9B1M3tDZrbc/o+h4j9PsEr5qm4cSPo"
    "fBtYf1r2HWirkX4nDmJ6VlNkj5IS94CSXikHP8tgushIkzREvZrKW0n2qFmWirmuLcR/j31OnCXdWsQ+ZM6ILFH0"
    "mQ9cSgPE39jG9sb23LbIOw1LdBlhuB6ADA5XPhwbAnjd9W61wyuKBhaLXcKLzca645LUoIOqz7ZrbFeGc3vLlBRj"
    "bt06IG+9rkmJX6IH7M4ghMZbnsaffzEQQenv3RJLmTHHP9bCMhDKM8NPmh3D358c5SZptMns+rAS5skBJiLOxh8v"
    "sV7kcIDiDKt0BiXaboPYZn52bBz59tbZ3k+enbUvx1fDjjnuXiCZ+9LGFRqiIQbPT2xAOrAX19bdYgUGJtICM1Tx"
    "6dtO/6wDamKv0wZ5/NPZ4OKiOx53zn82ZrsN4f/EBv3eNq7tpb1hitJ6N1nw4+MTXzpZO5iuyagFz2Ws9Xa3sU9U"
    "Iko/S0SgUwmiLh6+MtPmxnFJr5dmJWAcOvgLYqziiimY1NaGH5RFj4PZa0DY3dLhmYvExnpncBz5Is9ZT84ftik0"
    "xZgm0mE+vQaeaX8Nd8sexvcpv5dS9rNi114uJhVWJpfZCeyw7CASmw0bBuh65zquGQhbkF+wwgJ6bq3wpLXS28VD"
    "Qa+KTyKQNYSocvO0ZHUiTmSafCziZZp/EK0zLSEJqfSuaumRtW4KxnjCztCDRPupKRzttW5iqcfMLJIkkjJ4m5M5"
    "qZ5TPMLKtVDzYVObPHkFV5LC09WGxQfNSGFllYANj2MaGDOEXJ6xZll+Y+QET/LAJitUg/Vi50o9+F6+hX1tTe+M"
    "W2ezwVq9IMadzxh5jh2RI4RSfkhjUCiZ0KCloWcAMIwoubt3wqyjZvDdNQM98yCG0dwrsUZG1eWIV08Br7LbTSGj"
    "8jlHjwVBs4fVCW8i8bVxJrDKShbnIZLtK+1kyE2XuWLld/Lr3c/3dnhfoKY3j6kyD+7NC+zw/b1/Tz5EMEhjD0wu"
    "WsLvQb1iT5+lZDn1CQjToLg8iKvszeCqf94e0tEMnb3BB7YrOS9gDbCZGEsGeq8qHN345ReD+Lk9i2sS0Gqlcx/q"
    "Gh5tbzar3fWNOad7ApJKoTsH+TgoxuGm6Axju9lGcLfh++Hg6t17kzn/Rp2/XeEftB+iCR1jmYNh9123/7Agw5D5"
    "LW6cQCP8qBgLyQyAihz2pWzDQWDLAHc57Lzt/l3ADwHLng87vTbpOYc/iwxBMXQiGTPyoY4mI4N7B5Q0BZNDx7vL"
    "bXHqjAVnfzD2PvqWfSsPQVH/OmHuE32XJi3Xp5nIpNdocKx2ri8gIvo+e59iWUhTVrhRaN9HV2dnndFoMIzb78eZ"
    "S8I59UFNskOtJsKMsDzBbk2f2IwG9j84kmUn6gMOKTaRZ77gi3DKdF4aQ1C5wxLMdz0T0J2nzlWbOP4jL0RmRblE"
    "Pp9Lk7Cahx6JOxW/LF/vV6GsvKZiiquU9fLdzLo0NM9o5wlaQ46+tW/xkpt3j0Aj6igeVN4tA30a1j1t0OJWOhie"
    "zBl1eviOpxTxRsEehxWPetCQU6lEP074jeSDYzY/C1pd2MufIrTyM03ef8yMABIxsngUIT1+b8XTU+gwX6ISQtMV"
    "+g6kGayWyAC5BwK2wWD98rhLLTHvjfSHvVl5jl9KJA9kBWParrvahKDH86VjULQcczS9my6gxca2jekNIpJ/NCOE"
    "j0GXb0EW7qYYKbrb3uCVZ1jAZ/lch3+Vn1jb6Q3OY+58RUrw/QjE6TR4KPc1YMzI+gbkMK3L2gCVbBlW5Zjn5tbe"
    "WjNra+UIYeCp7Nvx0ndzY3/YedcdjTtDNPOH5/SvZ3pk5ZQUZOX9PrErk+K0Wi23mvNpaVqqtqz5ZF6dNlut+nzS"
    "KlfLDcuuluxqvdqatCrVqVVt1Vqt0qTRrJUnzRrm8NmP//Ol9d6afxl0+9xpPRz8NsJSnONhu9ujKp1v2WXOBz7V"
    "Oqq6j6rq6vn5kuXUwVx+R0R6HkiT9ZwrCuB7+Tzb/Xbv46g7inW3sMWhRoA3hQTH4n1/O7BDJM33EzcZVEe/acQX"
    "6rlcHtOl8rxcJqnkvccpNeOB09U6y2l4+Ew74Sw75gxbnMwHzrCDD6N9qd5Hz0MOyXxiMF4ViqHYnKcWo5lCxv9K"
    "LbClwBa9YMd9okPjdztTWOI9okMVSKp19rt/VOj9okH3iAJ9GAfOvZ0qTzII9KDOnnRuoZcn4Ym4fI5xqc/E88M6"
    "nzuf7fwtxlhtDM7ljMluOYOere3qFkl2cQeTzVPugqmNmRJuV6ywmOAyBWKLhueQEM4HY2ODfFjSpCnalKvt3Ici"
    "hnNcvMblzIA8YKAtRcHmDLwE7t0Fm4Jkcomx5CeYos0Lf2Xo5gZiV1mYLHvzGDGrR63s5Whl2V0HBwqPzaY0HjH4"
    "h8NgfReFOk+nXyLw2Qfm+kvhqfv8B37MW8IV0pgaybE5HJnv2V7ubl+lAfdEfSMuNLvAuW6ulKJsNPcNmw0cZHkD"
    "1sq5SrH4omoKp9Ur3RtNEsVBCiocPqX0PRejE9qpXpO7u721DsIzHjPD5aSQvJw9k1wGEi0LN7m3k+LBrW25u430"
    "AF3QC2vth91GBLiYrN97cNox6ZjjmsclZpYSPGv1H9M6vvu0dvH16hWglTmXHtuKbEaQ+Wn1ENq9gG1YbWp1Edzv"
    "Peaga4Un47i+IZ4F/bKV39LE0D3Lgh1qlnp4/uiFxx7USfGkSiOhQAMj3zY4nFj3LO+FawTkqO2e7sVu7pGS8cj2"
    "D8z299CtZKZ2MM3quLEH3tgseqaUdzX1+PwpK5j3Tp2e6s8JoCkfl3s1Ekp/eJsd/CKmxEeoPkjom6TiIWtnuYTu"
    "QrVorp2tcCOt2OU0ZbMYREXfseTA89LV8x6F7Iq0CGBV4snr/Uqdxu6I1nnbfeujJuyV3vh7l1VV4pRe+vDU7dc7"
    "1NNBtpSDMO8QrFq83yGYggNk17kDqK51Jq6D69kq28aQld5sfhgtVbllBgu+8FK0pMF0z0Opowg4lAiIS7kbQ8xJ"
    "uuZx3+6/b7/LDC1UzuqZ+R6Ds/cVRL/YjnJ5e2qNt457i3cKfDMl8MBlVeFmtlS2TzJhQlMJF7JLK/MXrDqG5/vh"
    "zAKxJpFuCTlWmS2LCzEEkSw36LjrLwaCacVtguAI9ZJQQyeyL/KU65oez4Sd1DspStzsfbpg+CCvBeOfEhYjIgvV"
    "h1a6gMiqtcVQY3YN7mBOwxikPzoLg2rYgbx6RwaawRmXQCwH88YdNySrE01VaPUxtCWvRFJhNLgannXMc7PdezcY"
    "dsfvL8yzQX88bJ9RNZNS497lBIGe8WhgRfXiFIVzxMVLeu1dWAkwDZh3UUbLpM2EZjfORKSOD6vz7tZeu3Fl+KSZ"
    "issz+Aeq05PFasJcEyfzyWzSsmbTcm02K08nlfmkOanVa41psT4ttypVeFqsTOtVrB4bcmuc1BvWHFqU7Gq1VqxO"
    "mtOZ3aw2J41SqdSYzJpN+Flu2OWWv1PudOOgwroGI9UzDdySdy3qdH1H6O/P/GTjXK8Wu+tVYY2Vg1zb2kxvWCwL"
    "LEiRH+ClrC9ORAI+jzClhKDGv4zY3dhEXJQRwJpZa5B7OBj5CtidX1RKLB4VbIAsBAYKSIUPKJKXRb/6E88ZQWix"
    "3wLuORKj3OSDlTtz1gsDiBGIFkZet0Fh6+DFb80ykBgLbFBppslu+slmNRomO2eBValcADh9b/OMsRRtOFtRSO/G"
    "9uxGFPvAZGyY0hpeUAGo0yH9kwOpb6MisLaWSGvw+2Y3ny/snMEHJNaQM2Yb64uxWK3WOextTlUj3NVmKw9ITWn9"
    "fmQwrxYxy3tsyBBRkCJnPn7gAcTAFZPNjfWv4OUXQDADvmJbhS2c5XrHAMHZGQO5dQv/sRcABqoiwUfLd88NOXVV"
    "4G7deedt+6o3Ni/bo1HJHLUvLnsdc9T9R+fkVaVYzHnvR53O+cmrcrFcL9bLTbpJ1+mPQTSMrt6c9eDjzogKAF6a"
    "54PfMMEJlpoyr/rnnSH86LcvUIqM38MvNLvFTjOmz0LgTqQ9pgRx1yCy8R5S4M1PAppg/75CD9jPRv5X/Bfowusp"
    "ih2hDqMN/H49uLmvjBEH2z/PxMMhofDvOYN9RoGcrxC1jF+MWFgyFAs3Q5DS7HuOu42MQILr+zA4rgWcd4cg9M3L"
    "br8Pm+dzobdXfYr7hEe9nhaLk9uYGdhnAus/crYjZztytiNne76cLbPSF7gSLzQ8IG4iCpOo1gRrw1441w71W2nV"
    "W5Wc3wTtErAuJTw4eVUrSw3ga3c3mS4Ae4QLEYaQUfxVqV5vNAM08KpULMIogj5elcvFUvmb1CsSMt6UAJMW+qu2"
    "6tI7ZpiyN3WkyuXEMyclv8BykhdP80ip+WI9X26elujSgwO8Aw8sxMw9S06HZIF6OLrbeAfZZwMSFXCGweaKAfm8"
    "SIG5W24A2lShdI5zw2fAyVa36G1YwRxqul/x1/hNKXfyxdrc7tYwJdwpgEwFQJMgC4848OPgQFauITsw/8UcKuhj"
    "2tkIHE8y4D1QnsnqTwbOLfr8F4NQCWA3YvrPubgGaUxW2xtjtduC5GZ1S2f21preYJYtT90R+gD/+A2riJfHIztW"
    "7Np7QbNDPYS5bpfzBQkq1/DGZUN5PtpwkimWEQxmsrFD7l1QJZyNsfqyNOQcWKkud7PXHdGpSdCXEzS0PQcTtFjb"
    "G5YAmfcm3/shd+J6tVqwlAe6HypIW45Rx63RSNWYgED+2ZCC/AIuPv9sI5YktU4xVOMIpvDQ4xCG76Sj8UMOiCw0"
    "mh30smie9TrtoU4f3xItnyOqHVHtoKiWVahkO+9UHRWcfi41Mp51yu7xYNpdX3gU2oUzkZGQReznMKMj/Ffc18UH"
    "TBcx8CYx/aRTOy6/WCZDVqMeusCUBPDMXn52Nqsl2dveQ1A2YE6Y2tF/BmJraW+/rDafxDMDNRNmOK8x/8DGlqpc"
    "CWvxVBMWsSetpYbeQTUdIviCC0xUb2+YQuDb3DyVBLteu7Tp9mz4MEO0FwiX47kzmdZJugD5OG4omyXfe4PjjUsd"
    "YGfGfIHRLEu8nwtakYuQvHVcFw9VGV/Cju3NlJwYM3tu7Ra4VewAFzplQpyZyCLnA3AwdieaXX4toRWtXKwfCoU+"
    "HyBhwffoh1Ap6UdELSWSF+0Na4pOGFSIVnTQzDNpwBSN8WZnF97itlAxNH/pXgI8fx5G95zBZguba3i9Cy3XEFOy"
    "mbZ1a60Da8Aib6KJCi7wDb9q7rFaCU5lBZxoHsPOaND7gH4RwEYw/39D63lI5IVeL0QZb4beVsPcVEtlXUJDWGlO"
    "4IMhDl2JjMQKvKfkMNts7gzJT0KwfG14TiprZnzBiLEN9yht7yQkpeSDDDU55lD5WzEON3ZiAPZ/Vo7MymWIVSIQ"
    "W6N/YPPZ9pOTEJTInehrxCJNLcUxgI7KocN6F+hPpkMBmBMo2zYGMlApvf5qCdg5X6wABH2rDwwKE6AWvtw4wPrW"
    "1tQmEE6BkvLO0rWXmMUEpgPjFrAkNfoz+eIMG6CPqVaWgRFprmJUnulQcmw6dC6NXW/QiQgISi7D7cZZYwFr1gX+"
    "XF4jcgBCgrqRF/259pbp7VgckBsCgC4zm5yhIM9u14aFG790bne3kvtwbW1c2wQCQ08Knzkm7OXo5xFBDp6g3k9B"
    "GXSN6xObGJggIYjeWgtMwCvAbi3vDJoKYReNZ8wtZ4Gc292u1jJ+MBqi1i7hCOzqzWrjyrhRjeU6YgKf7DspUTHB"
    "vSQhrXiDWQySAY0gFr3ym9poAXleU7EdZGbyDDtSgUc5EbO7A0Zmz1zKaE6tDV7WhfLm+Abia9EbANxrYZNRGJgs"
    "jguiDkTiNaWZEKvbzwDFjWBTx+yI6ub/WTN+5R/4OyYscJv7HLB5YLtqke0iHz2LQg246hGTOALywSmZEkchmUUF"
    "kQgYIlXhvOr/tT/4rc/M5RVwcmRgtDBxaCCIlBnELrF5/HB8ZnyE//vbf0sL87JBm9IcAyurJ64s4dABGCpY91Gf"
    "v+d4zxnoGTGE10TaXXguqo0Cn2eoDY8QTz35BEoKakZsGkIdQhPdRc1hxfhh+LwCicG9wZQvxuWw/04619hgnqb8"
    "ZjUBlrBerfOYLZaTAPVDNc398w0VBD23uge7RgR2POCe71ROYlHw+dw24/d/YiN9up5644GTMQ8ePQLbngdp5mIN"
    "ddgGe0ZHKo4raUXANBmnykX6woRWS/JKI3+d2VMWjgaScbb6ArIClRBKRZrzJRVPeYVZe1BMrLjfyUAmt7aXKE0F"
    "vYlSsLCsjcwqhF5NubKY+wUk1GrzE8vmS5P9E7qxfmYJxWxn4Z1N/MxLxCJVCX2HPILSDiG+OPM7UyzIZAsKoHkz"
    "slXIjTxmW0Q5sTRKbCBreiMpXc6SY4a/mcyLmGN9CE4MC+B8d8MGB4MBsQEWv7nLB2ZPtANji+MzJl69nqqtumeM"
    "8L7CbL9WNjg++DMVlFRFpiuGC8wIeT+er6FsxLby1Wbblbk+tuD8hfaLoCgxTDplYZaRDObWt9/jHBRHk+JoUhxN"
    "iqNJcTQpjibF0aQ4mhRHk+JoUhxNiqNJoWVSZDuIekY3x0CB+oSFu/QurbD4R8xFfevbOG4h6TyNfbZhC8x78ZSR"
    "VFSwIOSOnrZMoaO4Oimqgyva3jelBk3IYRIFP4+988YxhcAeCJDll+WKk7JdtKqlctEq281Jc95qVuxmuTi156VG"
    "vTyv14oVeDub1KflYqU1b8Kf83rFsht2sVFpNmMu1D31OzsaF91iT0kPl8zziQMpy+UzTPRuUqwwRrQBsq+eXaLQ"
    "WSFxNXveXvNrqIl80dFbf8mZIwJXzKSKqEn30FUL4BmfozVQYyamd9c4Y+SBErL696x/mJvNfE8MnkIcL0xsVuQg"
    "wqj/S1DGKRS++xYIk0VIc6mVY06cK3rIpFvO6A0oT/iwfd4x33Z7ndektYA2FH6B4+yWGL8OY16N3+abrOCENEmO"
    "TFxPwAVfWwA218Wqnv18CZUsDkChW10WCzGzLUQma6ymgDGSTTy1X0enSY1cbjEbt3SxAf0KlP0Y1SDma+BoR5vu"
    "kMCk5yYYoK7zNT8DxWpLJULza2vGbouE1/cnA1uHEpwc6Nr5QXiDliiLJbuDCbODrCWTxOExrc87eaAsdKILeqgs"
    "ggkqTui2vFKQBJuEcgFJ2xG6eM/05/gGDtiJrA8ElLtV3973o7VE6oFITUsRvh7/QnHr34+HjwwpvYq/0q/Cx8S0"
    "g6mg1RLAetDX6yoV/popYFK2SLOXmA3J/vVeeWySkfVhdCMFA8iagiaVpP1Yw5N72365LPlsdOjjMdLbxDIIrcHj"
    "eYjG58+9lMZRrjxduZKcyzCeudwzqeFxxw+047/LvFI5/+er2SqXs2/dFcu1F87S5i5r7yJjZB/CDWNSLvlz29ju"
    "brGlGnFYkUtkCKCjDsQNkQkq3q9mTVysxINLTJ1e0kdx2aHEJ7CFU7zmgKcCJlVI5Bew5UZ4mEe3OTPNRvVV9vSL"
    "mpukl19bZx8z6rd8qwMaWXc06HHnhO5VnRRU2SPtYVaVUU1Z2fMW6mNutsonusidrdd4/N8H5HsQTLbpatPUMbvj"
    "g2R3PIqMJysytJyX8UzucNVfjijyVFEki09YMghehOKsXs+emvMBDTAd+0pFAvIJtaLcb6pdF0ckSvMzakoLRFWm"
    "q5+l4rHIjBLzeXY1+aV6gB9C0U5EnSfr0o0h4IN4db+3Q1dFTdlSnB9Au1bR5DHP+sGj5ZKoD0fh0Yh+Wh8eQSru"
    "FHkf09xDV4FwahvrSx7nnafARXc3geVsoUctHn+wYLbDHe0fhe3TELZaBkYClz6YhXFEiKeBEFnMCdURwfM1JlSr"
    "2Tclf/SOZCSPoV+6gV2/QvOPgq/kSgpeosDd0sG+7LQ3VPlBulmShtRePib/9EV9JpN0jiMVlohcQjrxshLSz9D0"
    "5DyGwfSFe5NT6ABORRQxtOCdWnkzV16rCtU0iCR+PFyyrDic2adUeyySJVUu5KnR4vFwn0RrmribEsHrIUOoj4Qa"
    "Ugewke6fvkxNZ5mCdvarOxWmVnkF1VZds4BWlBq08CeWBejustxB0h4HEqPKFge/mpeyzEpZ7oTSqMoY/iDltWIk"
    "z7O2gQ8TgrRn9NE+9BHm/ftUVVNLCw36eEaWrpz4loSgn/jWNegm5TJVl85kEKu1ioQb0jHCRb47fSAb9qjlvXAt"
    "T8s4jmXeh7sHd8Szl41nWWzuoCJ0f2Pbvp3YeLXHpJQ8eMWckh25u/V6tdkaDGwkZ/BW5cxa4J2iNUKRGLUYI7uN"
    "LGe0DyW7FznwA4ZWIKO/nElWUzrL2f/3+NwrFZD52+ce1ay3UVq8MoC8h2WSerPMRGlemW6et+BlnJknLmtPf5fX"
    "VXq0RkIpd69NTPF27z1LpoGlGEwQUcHa6UKQ8Io7se8T3aRxHys9rPHn1yGwPEK8Y/LmZo97jN2tbBF+yg3N1kVk"
    "z5PsqvGZ2R8pj1IDO7tfF/c9Sr3HFPY9y/1hDmKpskuo3gslwfeyqrkGq78HrJanFYop8XIoK/HIG7MeN6YzsYNp"
    "DcfN2fPoL+x1f9mGCFpzW5YVKtYg4Q5WXmssjqcCS+28gw8iBon4nOqSaXwt2SP8U6phpvUtW4z/Ja+5lvrlD2DJ"
    "SDutxatCdPDoNo00Xx3y3a7WpkeND5eICFOG4PaxPKta5gwYLmDCoPmCZgslYeOoUoiZ9Z62ijcNkSB060wcWpM9"
    "u7Zhu6fQefhmItt0r35O3B1Oedq47fg2kBVGEVXC2LpL2ahNnDyIIkx1GDfGxnbXAHygQtuCJZmU/Hm6lStR6X+h"
    "Xi3bhYM5zWj/yC8YGCfATP1dSTkRjOJBbN4mzd3F0ReL1RcgyeVqiWOLgoMnpWqxMi1Om41ZpdKYT+r1SbVpN61p"
    "dVYv1lutVqNpVUqNRq0xa5abrTrw/lqliQ9mxXmjNJ0GDsvQ5FMo51qolTBH267XSrXGpGzVZnataFVmrZJVtCet"
    "2cSeVypWa1KsThvzen1Wn0ysWWteL0/sWqlVrcK/8IXOHJV4HTBG33b77V73Hyxu+XI4wCxE5mg8uNSOdIihkCyn"
    "27pElABNq1arNeelZhGACTCd281ZuTa3K/B3udyqTaeACdNiuVyt1O1msVSdlJqt8rzSnAG4q61qQweaWSk4YbqT"
    "Yqlol5q2XZpZtcoEpjltFC0L/q3ZrbI1qdRqrcqkXGshJheLk3qr1KgWy8Wp1SgVq/XiPaebkZyKxemkbrcmdr1S"
    "mU9tUJSsabFVmlUas2KlVpnPW9WZXQecbNbm8/qk3Jw2pqVZtVgtA/FVmhOt2TLepUKbNZoRG5Tk/wtb/bOYb1n5"
    "+e//qle//ceJygui6XxB9rZPsjatc/tYWB7yHD8Glvc+xo/h/C8qFYjPu8RnruFsXXsxp644Y+ycn95am0/25jVP"
    "PTvd7ij9OLPYZAuGRpj7aU2/WK7UipelRcjmeIJqfhBPlSZ4HwbJROa1wAp+aCMhnHDhMIPtjb354rh2sAOeD5kS"
    "HMOmXWPWVcqJkfPzvvGs8rDGYN5WQ3CJPOMS3vQLjEd42WGpWiFLqC3NS2wty8O7l/eFgKYRC09ZYYmWDMxofJjI"
    "eAI+RjF4G7CApREQgGBcnpp/w4BEOfnD4GPgKYi8u97uC+UGFpdNyqkXel/59igL1VGJ1Mu7rzL0SPuYSf6rV3pf"
    "yf+9V6pQHWJI855Kw+NgrJapoV7gfY2Mh16g2pciS6t9zN54E1Pbekx00ESVsoO5ZY4ehKfjQdB1enlR20/Lz4Vz"
    "K/gT3PfmOmjCWN/GtLbM7w+Qo3IZJqt2ID/BSSbQLKu4AcuesV+oZvErUqbNVNCM1AscRewg73W7ca6vKfExws/0"
    "8Pd6Z20AtzF6K3gNPLg8rSPTMASSTA6yyMxedzQOfMkgpf/hgztJ5L2J95JhgZ9XBO7gXiq6U22uPGHqVyNK4TvZ"
    "3IxkHis5usBlHcgLrI/OwSMDnW7idk4QUCpuYuNYGkv4mm3sc0qFRGhjWOv1whHVXbgdu1obMmV61Xpk6zxKkTgz"
    "sH0d+zMxPGu7unWmWNkL2Dc7kbRnBVHQiIrardxtPjDQF5BuaEJzJYOKnYC1jVx7xmaIlQ291a95DDH8zUoQYa9L"
    "rK9lTBeWc2tYbDHMjVCQWTa3hZGOad4THoW/VwiDKH4B/NZDQoIxgsUMAKw9Hlx0z7rjj+ZVf3R1eTkYjjvnMG5S"
    "y7dtAPF53K3wlyjIUtVUn48d7jb1SwSklq6HsT0mEZBpXW9s0ppeQJAC8vOzsXk2uLgEinrT7SEtnXdH7XfDTuei"
    "0x8T2fE2/RGoJIFn5932u/5gNO6emeedD10iSv9tfzA2Ox/avas20C/86uMwvc6Y0amviKVPIuWyE5Oj0Xlm+Uy5"
    "lCwdJKxWo5tnJBSxuOEczC1e1hWw9Pb/Z+9dl9vWkUbRV2H57B8zdexY90uy1qpSbDnRN4rkLcmZlZnKYVEkZXOW"
    "LGlEKYlnaj3Pfo/9ZKe7cSFAghQlS3acqOYSiwSBRqPR6G70BeutpfDeZ6SwbA6ZsaP3yzSfEQPbsrbvJtlCXJ1F"
    "GM9NoO6cSUG1rzjwzQPwUjucOYvwbh63U4jd50myER+IGJworCmiJRGyRKXllusFfc9LxirBSMI9j//e4sDTQUmB"
    "XUOai0IanJMSNu2tFzi3M5A3geI9GMfRAsBiLcPYnom34Ad6bJwZgOfjZQylJZzNZxFmjTkQ8i9Srvv8TeuYi92n"
    "L/WmoPNMISI99jyDfnIBrJNY5J4HPDtXcP4zaOGGff6U+niOjZXPQT5j721U1LO2rcEAkG8f5yKYTVt9+040brDN"
    "zGNsJG3eG/nKjyWBpbIgKYtt5HVYii0f7qxfeY9523ODQCqQrzaKLqzMataxqVKlpQ27Udqyoj7ENrHkNjH2ZZLA"
    "ZC+8TevmsjOyOzCH3kX3Ztj52LaCSUQ1Hse2ZQD8N6ugSoAf24PWu7Z93RqMOiCxoZf0YHBzjWjBHtPRgh29sVZ3"
    "QGXwX2V2k6Vzj4YZrSD60meGJO2QtYT2juQ5mWP4SuapvreMB0dp7DuVxnLrUAdKUXAkjO+UMPKoljyFgr26W/ow"
    "5ylGG6Gh+iVbzKDxJKBEGBgUyApD8weINv4QmOj8Hml7vqTaqF9BsTU9A4EH7fP0RMk4ESFM/yh6rn4YPRXrGKWE"
    "wB+LRWJ09izqJJ57Tp1iTq0ogYVc36lg5fogicstPosmnE+G3ZxOjImsysolLtWMS7lduoeG3pE2C9lNs7pdL7mE"
    "8SRpJSao0FoupCbJcYvPtlrAFyfRk/i+mlsKct5Y8vqODsNlEAInPGXpnOcOCJS+KyMtzcmkfkx2lSmYJA6evWdO"
    "+jGRutOhHtrOcukczmhc5tfb4W7G42jbnBtg39F+LCDSzk3xcJMdMFUsiseavSAGJhYL5yT8EYBNcanLknRt5lIK"
    "Orfb15z29ru9FWhybAgWA4/7foLFhXjY4AuWcMdz7yFSTO5WK+ZKsA5l9jHSfGCFAvjSi/wsg5iDndpRLnupOlYu"
    "oUCCk8tlyQhxji9fenz6Ixc0a0caiX/PNcIeB/0OO5gFEL3sTYwLEbCQp2wLhbZjxVfw573zzQ5W/j38KJxmnmdm"
    "BpiMm855+5O2Gk92A/SSTl22XjzJLWZne7CYMLY/4+w2lLQNq9DWdW/cYhto87CGpTMLcavai/k0cJ/EM4JGgjmc"
    "jwat3hC9H+3rfrdz8cketD+WSrsWcEY2iptaUBLSMUhRwI7se+Yu587nfwS+/IWLhh9QdZLQx9HouzUQ/j0P2SCP"
    "v9mXYDmfkZFR4Iaef/Pd9Qp3mugSHVvF3zzkQ4WIeDus/GruzqfcBsuWbuG4mE0pAgIkemc69adBeH9CvqXfMF9D"
    "BAcfhL2gHQNghICl+zlTiIDGKUZVtFz6QIqRjTRBO3c+BbEmrbswCX0W8Gi+Xsl5ICOchjY7nlyHT2g9mxKHN0zX"
    "ni8Ig7BNluMADg9qHwKunFtlal+XDulvuDo4nsBNUgKLgNMz1zfrxY1VHlia/TipaKwb79bect/bzbxZpbHHdGMk"
    "Tj2pfq6c/DFqjrwj/rkRjii0w7gBNmiBxKzt+RjZXIbzR3wTaTj7e6d32f/70B5+Go7aH+yLm0HXbv/ezofCaDM+"
    "Yh0Su1g3bJYqG22bjMLStr4G2vvR6Nouwn/av7cAO/kKGOqcQ+0vl9VVZTTa3HJ9bOZL2qQQ1Gu71e1inMDvn+yP"
    "rUEHF2CYc34pHE4hZIY36h0IDX8M5S85Lvzd68s/r5QPxNJ8e+A/QvkLMCP/ns3lnxP5Qf49pPNjnSL75Cpw1e92"
    "+3/PG9IUcfOtlzyvnBoTDUCOyVl/hx0mu0REZUi2xZy+TbHzSt+vlUa1Xsu1YeOnnIYlYkR/H3RGbbt/M7KJ/i76"
    "l/Cr1/2UD0eJM3OHLLfbHbK7DBA7lZNIuGxftW66OXlV2pGuHWvVHMfaC9JgUhg/9q+ze9b1ZILvv2BQ+u2XKBZd"
    "SNGoPZ+dYZ/FV0XLWQFoJGtbpYTgyrQlISOy2HbqJk2i1ZQseW5vq2UVTzJsNEfx/GcQzzOVZNOhsl9T2pHIfgYi"
    "y2HboBsVAEmJznt6GwceksM2iLxRuOwebB3Oyr0TFVq89WKKSPftf699WN8//Acdr/4MC6csnXs4Epf2DP6lqEXP"
    "p6lFbwQBJ9/Ev2HJ1ODB0rklUlSHu5uHK+5udgvfYlUdRzxYwpfJfuUb0S/F6q6SDeHH3dwTWIZ//KWLw/szd44Z"
    "WvAR8Bb4h6Ei6oChLvJz+xrMvPlXJjuYtgI+8M1RmEsDYDxPNJuqbqGIlmpr9WrDyu4g0BlIQZPp4P0ozKlepxCQ"
    "1l//Q2fEYps76DZ8mVftTqNBzeagZ99LfstT/qV+ImV9AxnvgFuie2327nQ+fgWc4IHR8ys4jfKm9dT2jtZpa3jR"
    "6djDzrsecLu3rWG7WAD10e62W5eob153b4b5BzHtR2000WjLLiXqo57g+MjXiXnzx/rCJjm7YzxD+/5dO7d1hfn5"
    "RZ+eL5aB64dnd0FIKaDzdRPnU1qXg6uLcrNRs2+ur9uDC1hR+337d3t43bpo2/ik3RuVCjkHQu6XTvG9my6Rqpk7"
    "5k/ZYuKi2pRIo7FbvYv3/cHQ5onQ7XbvY7vbv85pv8tppiDPmG0NFIy9a12S5efR9295rRSGU0SDhlrkZcXa6WNg"
    "Fje9R7OLF6RxC/5v4XF0jqg9J3ZEPRHlW0TvlFhEEbsoqeiMLqZne9V8DyqsfX8S2DOLXlnaZ4xX7E/vPMrj37c8"
    "vlFbJA96VolSZXGuM5vPKNkj8kPPWs6/hlZIWYyA+6iZeGGVT63ulfWveTDDzL/A9VBhnCKr6F7pPA96OSOWx/IH"
    "C0JjNgBMJannEyQ9AtXFsj3sta6H7/sjFj1H6iTM6aLd7fJ8QR/avUsMAnx174kIc+TLemjvyYTy1xaaftmpOvVx"
    "Y1zwJsVmszap1Yv1kldvFP2C5xVr8Nor1AvVQnFSLFbqvu9Vm5WiVzyJGJ2QMJZzQthVp4fnSsVuX10BZjsf2xFM"
    "/OLCQQTx+xuaZHiurIsW1ti+fNe2P0I/KEUgBopMYd5LhQFleFLSb95eD/oX7eEQs1SMBijA4JAFMeQeCgZEQw7a"
    "//umPRwN7f8ZwrLBj87HVrcNK6kNXmyIwfeQX18dfHjd75Gc2bpEuex3GpGoSZ26xPYe0uXnGt241HvIfh8NPuzf"
    "gEBtX9qt7rv+oDN6/0FHeF2O+tg88UTsjE+VSrawByHdS9sQXQAMR63RDU4ZI2uB7FsJTJQETLXquAmzbvqNqldt"
    "NP2aW6hNSkCLhWa1Xi5OSpNque4U6h5QQr3a8CuNSrledevNUrUyGRfJPJXH9+b1Sb1Rq1SahYbTqJYmYweYgVMq"
    "1Brj+hieNUtuZQyvnGq9OhmXirCz6rVJ06vUG251UvRKrqOOlMcCBgRerDTckuOWi3656DYbxbHrTMbjZtGvV4q1"
    "QhFHqzdrfs2vFCd1v1oqefCfSnNcdWDgpqPhu2xLOc2GAz6Y+Kian7zD2OMeib2ti79hEPKHVq9zBfuQYClzaxyH"
    "/cHG2mnjaRDeoTwHZ8l66uAh0r/pjf7Cm1AIwhq5+l9/LZesVu/SYu8vQVXq9C5GFm9IrF62iQq3syMg9GVMNr5S"
    "zpVy6Sxqgp9ianlRQt4FqQaz9rk+e/UFhVs4XawILBYu8Stsun73Y/uS2lHRNgyJ4PnIfgXe02GvlA/HTogiuRGq"
    "Acf0WalssXbsYy78yhxpPGtt4KV1RHIA/EvXU5jdfr5eWVKCCs8pYy7rfT4OQSqB3rE2NEvHhoqDdjdGASeuE/oW"
    "c7om33wBFs9yj+kDoyTOTBWQiKVjmceVhBiqhPCuZwFIKdY1IBGOMZthi4EjD3SMJofGDl9RXjeWOgZRgDEgLyDh"
    "8tSa3wdhSH9hEIvjoeYlQ9OpagCukPLE8yc+qCZffPzLgSU7RRWJkEOD+98Af6FKBDw0xookGKYEKcsAytR//Bkn"
    "UH7j9+pEUr/qc+gtQKxZ2VIMk0+4cCl/c3Ev+s0EQ7r1kNJi+h1ImqCZIuYZJekt5Nq9CN1poi0P2YkLxJquYBZ/"
    "026l0q5D4jc7sYuj+L1S8p4lcd2l35LF75FSr6IMl0CJKznDnVjigumzJELJUpTtZrCry2Zs2xHVti4u2phVwh4W"
    "bZBAr/sd2LvAFq7bMOR1p9djrzqYkwPFU5F4jL8atK+7rU/x16Ti82L03MhZhHk7y1sfT5i0K6f/51xbdsmA4RNm"
    "KlOqDCZ9Gk2zIxHJjk5xIcXsMAHuKalMI35LC+DHlzFzCjEnyAPDH7n0ZU5Bp+kk/O3ezYdM18sDT6NcyAY/hSlk"
    "L0TC+/PAk0C7SOYkYozGsAwfrkHzk0EV5hur/e13Ez2xW7Bc29p4AiUnFdlq9ZMzZSp75E7GS6hcU+NHe67JiHuS"
    "w65L/O4l1zS4BJJvGvz65MBrgsb2fLAzaSoJu7jIiUtmT0BP7J4kF/hSXMxCfsY98mGpqf8WtFJQiZDdXZItrdXN"
    "N690sVGdqLH/7LvtFzRhA6tTurWxBK/5Mv67n6OQ69OmphyvpuiAAx+wLOYg85A1SNiZQoKqnD0BA8HL91wrIvXF"
    "dFktI6xin+twypydrwf9j+0e2tuNE4uFb2SvUaoKnD7ZDIeNw24q6QSSa9nS9e+sYyDpOnLYOaE7ynbTMfEFfYFS"
    "PVcOPRXyhsm3p1IMLFlLkwwxOjCPy2ZvCXtGJnOLxTcdmjtvgFy1y2SDnRpZdWhlOj1eK3tuaTYh83axW71L6U6U"
    "6o70nGYdvq1OuSfOKSmFp4IbnP5TyAuf8228NCuhJjEO8D7s7SdbSjFXncs23oQaI8gOblbR4tIyVz9uIUznkSmu"
    "Y6a58Lu6tza/LLW7eB882PMyb3BVy7W4ZjNuEgksntUe3HTbhii+Z+WqugU5kzelea8d9pQTHnH5NE/zfUHWKWeK"
    "HDy4LE/xiJnrYgi+yFwcU1zhgafBXUzT52C4FkjOAd2o263eyZ8pNydPoJnkc8TNZ7lJXvyk80RDmOWhebsWvJm5"
    "eMnbovSJZAR4Htp4Xs2cRPrNWcZm+lO5hdJvxTHBMl2Pxm+iUsmRHG2ZX4uYlDLb+JUPYqYzhM+g9VXnd+gQdcti"
    "Cq6025YtPzXfdWzbiX7JsN3XJgN/dGzoZwbDIsdxYr/HTOs7rkXMpv1IUJhF+bGgCOvujv2kmlh3m1yqAfOR3Qne"
    "tFMvSVPcdmSoGcF2xHOqNWo7UFLtPLthJm5Z2a2XFNvGbp3FLQrb4UdT6bf8NEWt3q6XFH11R6qJ6XXbgWJUp3YG"
    "RFFHtgPDrBLsRhxJQXw7WJIS8Hbfm6XPHXGaEO22gyVVoNqmG2ZO+uLPHFHIVPqXs4RQwkXMDp37BXqs20r7KL+p"
    "GgchfdZf5/scDzOJysgnjXIXuysLvaCtm9HVWeNET1S7mIcBv+u9pcIR9/fwz5wyYuKD8XQ+5j+jxsLrjHsf6oUo"
    "HM9ZIInSN5P1zBWh/AS9L1x0xC+f/PLnywCWEKVXnqGXOSkxnzmM8JA84AYmBgtt0f/R6U11WlkkgD2d8AArnnQs"
    "qv3he7c+kK0L8NOi6A77e3B3F6EFXKzZ1uUeS4KwkAgR6hWtIi2cEvOVjH7gg2PmaiRlasadMFcP0kGT1R0hUZRD"
    "GTluR1SWjjfpvyuSKQMdgqoR6uEUWRTNQ4bIOxKnIxOwzOZaBEcUvaFTtiBhShHKxDbHjDON8glrGEeXJxIBk04s"
    "WPUWSR97iE2AtfKB3+FEkL8AnP4bHUoVGfBPcDsjHjtbWV/vApgAtPRpr8BOYOjAOkxUW9xFD9c3VgiPpwy1FHyF"
    "BwZTvXA4daPM/K8IULRbAsQgnthstYIZMBja6xv506YvU1gTBfycoXOtsLuwRY24k+AywDCkbUYlsM/iE+xKVkrt"
    "vYNmGAqKNbFYZujPGtKwWyyXDvj1Pb63pKekgjKOzO5VGoPBQxh1K9p64TYo2/TlzigTdjgZ2OVhitRgzF3VN+It"
    "+oMwZ/cHzBXmc4zsWLgpoI/PwcKBjUhFT+gZ98VX4s22wbMsu43b00ZeBpI2ub+n8R1negsnyuruXo2ixYr1DI4U"
    "LpHOYKkYg2klmWkuyS/2EE6Uyqk3o0PyadHHFqSZ+slWNBkQVUcJVa4/jd5jHNbv7YubEd52QTsQpC77H+wP/csb"
    "+g2i3eiqP/iAmQRbH0Di4kEkeDEWnabDFkiHSKOfk9SPqwl8DmRBnraLZyhiz/jeiB5ERx5hcr4k2Y1iXLchTy4F"
    "ebakuoguN6GbeaqpiN1wkkU0KsU5SX1C/3x0aFV+wUsiivB/Cv95jfgz4In2MUvYbItJzlB20IPL2xRdoeQIWjnT"
    "+a1FPDsIeaTIKcWlUKbz5dxbuz6LYndW1tR3whW9wVBzrExySq/icSzjgA5iCmF/bfmwaNAHvpgE33zv/H49XQVn"
    "TLzgOdbtpT+xwoeZeweaLbE+jKaJIOWteMchho9gf7Ds7jJYAIbORE04y3sAUgxcS/9ki87fUHgJwh5SkP39erWm"
    "+HouY33xMcyEoZJyZ/GhMLgFDn34KJ6d6VeWlUCNmQImSDG3SiqmU0scAqcUFUNSWhTUzVDNw3x5pA/ItBEsRMG7"
    "gSJjjMQDJbGApeZzOpXpC86j1AcIBgwVKsJSBBUHCNdXBCa94VE+hLxz5A6iFRKSRmdijXDBYT6wvoJuQDXFQXpz"
    "Hk0Gv4EsFnAaslKriynIc1iDBE7FNxZLEMGKaAKhO9bb+RxGmfGPAcugp2J29hmVAl27qzWig/Z8iH1bojSAnI6/"
    "xFMhjGYqtIMIwNDSAr5/LZXfWCKE2BK1Byx59gBF+AskvgCoexncUmpEsn+xZWC9hAQkMSkcm0L/rBasjkdFSwtl"
    "fmi4/nSqkA+jZT4LjPZaIG6ZTOmdWizkXEQbMopAy0zyCSCW06JS7IFK5MxcQDBPkoEuzii5ICwa4a6cW4KE8zaf"
    "dcUIQqTxoD8YAkk+Ms4yznTQgmDpYIil4JKR5bjLeRgyujvlS8+yjZxGUe3qjsPlk5YYBikulc9JyQwYAULVW88w"
    "HHDp8MObLYA4eADqt07o1ypnSj0J6P/ed+8c0cJDc9Q9kAtttFPYGN9gH54yEj+VdXhvfSoHy7FI2mmIqzUjjcYA"
    "omCWZ8zuzLeM2h0xPh2UZfBF5DBhYZCckGFbw5Ef+qIziutzebleRtqqeKiET4oIQTOQsqrlmesscD9aUyBF98EF"
    "AglYDOBqDgeYJZvSkDATFBQA39/gjQA7Wg9ZQ5cmDbwBpmc1YTsEy1DwOiMxgS46h1d422WJeqEcZyzg0Zl+dR5C"
    "UR+Ey+awEcjhnE3wip9GFRHNCUC4f7DkMYgc7I4Hlb4RTYgq74PwHm/qGPe6g1ODesZk0LJLJlZYmMsgxsLxgA8x"
    "XDNYWX9AexTBI46onkIBfkpQfJ35cKqucBPfA2OnYzdiISdKqsFImCWREfB2r6V9DYNv/GChnlVFnEYBQls5Hsgi"
    "TP0GQPDcEGlyHI9lWxRrE1oT5A7u1AnuYYMD42ZRoTARWEsX2oQBaw8blU56D7agw/mJYDvsLX1O2bEtXc9m8amY"
    "HJP4xnp1ByT1H57zZz6dYiIN2gkR9mF51Lt0bWUmRHA+oolQwH4L3mphRTq5L+DXGk8hXoj2jE1UbIYzOnbpmBII"
    "4qgNxGFG9HP6mLNdPTY416ONpgiT6uwY6fKiOVKuEzHhAT9WWRHsYkP7dLHE9cBI6oh2OUvmH5QL2gfY4AxQvQSa"
    "AgHqTAk9p2+xLGaCyr4GUw9JXB8ahd7bpYN1kSXyQ85DJVxCGIDZ3+OJvVSOqyjd8f/9P6w/bQCGiDMpKuDRgScR"
    "k96s//jLuRVVAbRQDjpnIhFNAr7T0fx//0+pZonawxbHgXoKFkvWdWs4ZGleEEyYOqwkcGYsbwQonga3SdrMmGos"
    "rp9nWA5u7zQurnxHfEbNeRXyhQ3Pf+FKD9cd7WLB++0ViNybYDlT0B6jFvFKXUnGo7wg/BfXodJpbeE8TOeOZyEU"
    "hEcs2okKCi3Fa9E8SgfAZ/ClVCbqws3MdYZc4/CNEYTy+LVoXeSJyp054Pn1oH3dGoCSftPrjMjeoKg6YnChtwRc"
    "cFiHKyFiIzOgSvOyVlYWgErXfIq0lRiT4ZAmx6TxxlGF+iljtkrKAZgbnVkkI0hyUYwb5PEi9yApmULe58gS+P2s"
    "6LeZJQiFNqkVLxKiK5AFXbKwitxMNCGD1mqFecNtvgDU6z/FUzgpkcpCmYwBOTZPvrYKbtfzdWgVX70ivwnMwSA+"
    "i8unw1FrMGpf8lNAZD4vmD4j1sBVXCYAQkv9O8yGIl/BQqPbz2Bwg9eV+CXeinTbLHepduPAmAMlXFBERrnMsksO"
    "DgryWHNc/YwRrTpI4jOuo7BjTbK/O98wEE2LzE2IK8yOEZ68rjRresV3fnvD5Cxlrvaw3W1fIAgBpYwPlkRZCluN"
    "slAIsQT2Bop8bKsv5ov11FlJvUqpwQpH3wKhxNlE+fIw44hM9cHJ4UzoCbzZqTyByDgMXBAtvxj42B/Z7Y+t7k0L"
    "Ye/1exKFb2CrTDFLi89kcJo4Ze4T4iryDckVyaWBhDJK6ExuXZghs2+3RiOMQab0Zk64Zmc7vPrQbg1vBnTxa3d6"
    "mK2nezPsfGzT9nBYFhv4/KJ1PYJmSje8Bj2buc0wskLrGk+1yAtVn/TaH9sDm1N5vJB9VOeeN2emuWhCNkqzdjwt"
    "19c7n+D6tXDy52k0TT4I1auw33fevUf36sdMvH/d7gnQd5i6Bs9NT2Sr2S8SBIPoEYsQ3IQf82I7aWhS90kMS/bf"
    "O6P3sbvTAbnJb488Sihjq4PBXx86LHQxFYVsbgKDpi29EX0nG3fVSRZ2+SIa0asybsZ0NPZ9amggOZrKinlrJhFF"
    "X9CxiIcx12zPhJqa4NXWRaFyflGowv9q2uLKOQLBtQDXn/6RXOWdljPq+ENnOMR0U9T9sDPcYkeYoDvUdpCIj86j"
    "Mer5zOwsNXVEJiUumt2ec409BaG50Qna40NsydQGiT0SG2IDSvUdYgAv/0YhQOXZy4/0yIYh2luiOPn2m8awCFIE"
    "UJcgtDjmmRc0ThkNCoAy7A6OZTj6WTshX/J1zJg/CjwmBvIGRn6wtHPp1Erh1aea1KRQLU9Ixk0Pw1H/Wgb0XPev"
    "b3jmyo7kOYIjawLDSXyyQqAxznjnqZrgz56xhhyaKtDG7S2Kuzmn6pOAZJiwIDdbSNd8ysHEgvOcU6MVSSxvrDku"
    "9NcgFGKiFZEXypxvrBlKq9YEkTZGs9lqDiBYZOMXbaO9EK5Rq3iwY44/ik4jhdVIUkvsDVyYN5YiimZ/vvFEwgrs"
    "8/XtnaXoIvzGafV1romjwvyIZk4kEuHub6uCscSyCEXT/YvEPFCuxutnvo/fyNMIjpdT+L8qo/9CLTqaNCmUW1Uf"
    "3rCV5gZfNIXyeH28TgiZJqxDoDBEWzAJyZcyziNppbLRMmszWwsGrUSiPebYjuTj9QzBYFK9IsWrHFbaujgqDKI7"
    "itnM3ojaDGnAzGAIuBJmQJYgd0VaAakDC1oqBu5mjm7SRnPKQfpqLpbzO0DziqyxhxeV2CUzW/oIFE2PHod0889t"
    "BXj3Y1NwiEjp/l+e0p0Kzb0+8afBbUCuVZ5PF9/Ms4Xs5hfFGpFksQ6b/ysz3gG87HvgGm/7H/BULFbQH2l01cAH"
    "QEN00CZfiMfRiIivBQlj8P5U7HsGAIPmNB0QVh1UmycPqDnBgk14lK5n3CDqe9K+DTutyCq2St+IGd6iB66GRtUp"
    "0N67J+UkmAHJ2Hf+N8Ea+YWFdf0A9D2zJtO5s3oF7yNN/6rT64za7BqVHsDxcn7dx4DTq/Ne+x3+i8Z7YM/wtXTk"
    "7vPf7eUSviE7F3X+l9VfEaXs78VfOUsNrYtSEQ6EHsuhddXtt0Y25jyFv/4OPDgM18LrcoLXO3jZCuR9v8C+KLfS"
    "GyWTv09XQJpVIJghQ2VX+NI+ihYneMeW3GOuF/IOB40sYhSbwLXJf9aOahQw1JBXDUXtMaTgb44WEHRi0cL8EzRc"
    "fQWW9cuv1sr6xVqjq7S1RiYqVmJMVyFnNDCTM5dByNx9cbTXJ7QvlbH4E1oits4spyi7U1DAMzRk47OGfyYcfBPe"
    "UNwRmVWjkj7J6NnNU0PLRMmJHNEf6RLA7F22z1TR9qOdvGCnq+/wJgb6oW0Rrl10zp2spxYLvIP53nRH9ofW6OK9"
    "xXcvv6VSOnmDLOD8oggKHfAVbkbkuSHJbhsnURJ54OEkINuQDA4EAWIifBCE2yqIAWP/zvkSzMktjDE7ppesZ8yr"
    "3Tr7zWK8UbBCLqd7DyrzQyLEUnAha1+Nt2dNCQe+F5K+Re4nXApQv63Fv2V+KuJTaiNZ62fliBFc01bmobtHihaR"
    "CT24v2f17PLcSr9RrxnEJS5sCBPrth7YLRvgTrsIFthiUSRYi0GB1l5gdIxLJ/A/Twac6M4UcohuyOmWV9xkRdZy"
    "kbYlzyU7IpcRnsUTDFN/ie7CyB4h2rvz5WINbI/FBkjXRs6IzgXo58zfG2Rvf+adu3ew2v6KvBSoFzbcIpjN5FB4"
    "TyzFJpGzN3bXKq/qFEA5T2F+JjTlMz5lGEf/nmqo6D2uEFh+gevLnMJK/mc2HaV3gYjISsMvj/GQCNfjcBWs1ly+"
    "c9fLJR7xmhwc3z2S0sWW4AyD9rx0UfysSV2RYyNe7aPQFqlgWbn2udiDtMs/2ZwhX3zDiflj3UKdHmTaeLCDAOpU"
    "pxXhQsYcUzTvqFPpCgXYmKL0TN4zsTXiVzun7PT2zwAC4auHNgkSJfFdZKuJHUmS5QFLhHFZaUNxFuk8QxN7lSga"
    "6Xjw+qR12QKpe2B/aI/gz1HLjn/DJISloTdGQZhCi6E78X61WogEW/F3dGZeFPA6hwQc5qb5sXNJK4zSz7DzD0rY"
    "NQUyntqOYfzcNj4kRd/QARN60LeVggwlzzpJXtfA0sQtPCDfz+ky7j++1R/w/aQ94jFx4hGLZOSFqU+uB/1R/6Lf"
    "1VHzRiZMjxRu8RGJoWS7e6GrXdJWm6Jm2r93RnapYY86H9r9m5G+4Fh/oD20QTPsD1iIXKfdGx105ek2NXKrsoUB"
    "4Nc4oD/7WpZT1rI/ek8d9v7RHvS/8+XUYX0BK6oaQmx0aKOgCf0qRbXZJa5VNDuWpdqxRNeHpptKkm7+Pmhh6pbv"
    "nwfEAT1SzFNQTDVJMYObXo/kOwxUpwpaVyNhz/9+yScT6iMtPQUt1ZK01G3d9C7eK6tC62G3PrztvLvpszqb3yc9"
    "bYT8p5FReDWu1tshWwy+2nVttQ0tn0m9IOGjQGoEOdyzWBKu+/10qyYuL+SyNVKXTTT9vtZt6n9DO/s56OO3vtTb"
    "f5pl7PQwvrbF86zf9Nq/X4v7O76gzeSCpn70TEtL61ksFF69KjabP9EWvLmgjBU3veHNNeafwftX2mty9YoFw3ZM"
    "/+w5169UKL56VfqZ1m/QvuwM2uwWhkyf0bIVk8uWbP2cq1XG3Vb+mVZL5tMi8TFaqlJyqWJN02VQGO+qf9N7gvWq"
    "4HpVmk204vuLlVUpNbHoIVr00Xh968/wRh+aVY4rWn7Eij6NVsGWtNREOzX9XcXlrR5+O4qVaXc774QL9k2PFenA"
    "S6ZihdJ1OSG/2YjQGL/eGY4GNxfkta/IheiT5LPoWszrr06ZW+ijK0ReZTW1O5yEYXhJU8rxFx+6tNXQxh7jo6dd"
    "h0nkxUAobwUCXpAhXY0+Xbe5emS/7V9+si/b10C68JO7jqS6ObH+MMzkvxhQofZHHcW9lU6NrWK+Tn8+Gg0VHQ2C"
    "R5yza2wWcqnd07P7bHkTa/ImIDfeiINIoIzw6Byj/ze7VChEnELaQ7XMo6rTvCi2yxyBqOQu3furO8WaBMtwdcZC"
    "pZXZq0wmls1RcKyDy2SFUwOTwHfnxVdFFiNA0EcumOhswGf2yrrgt86a2wHex6Eroo+37RQ6ONEdGM74ygoEvdLZ"
    "Grs7PVNCgl8T3zo38zvqXXhKCK0vwFRrYh7kqjLHy8JbasybRq7n8pvcrJHSF0VEFu2hSGHOIizdbMq/oQ70s2df"
    "ZGGC75GkkblXT80bdcrzQwhnBfFUEkTC4VH67egkIk84ucTYraQPnrgTUIGKLKtGsNO6EiPLt6Q145JiB4dZ0hho"
    "z7SasaUSHlSnSVeTZ1xF4xHADgC2KWiVspdXN1caF/Egy4yuM932xzYyvZ7df/s/bZZ1OW25hc8orSNnxBiPQDHU"
    "Lxf9jWdCPxf+edRZLrcU7uXLasPDCvD4LsoWhdL3i12D5vOuAdI/q2G89SpQjDjzCI22hLNcOg8vdjVKuuUPPdTN"
    "aiv6rWdiXa0OHSE99jQvvin7kEWhCC8dwbqNjlHyVavTRSX0on/Z/ssffzVi/EOri9BvZ6WTUQop6jUbHn0bhqPW"
    "h+tYIALCsYOqYAxqiC2wjI1YOgHqMlr4REz/Y0BeDzqA7CcGcJEG4GdDf3KFbIKYYg7Tx5Kk/4YpDuhAPQm+/frH"
    "G6Ya2Vz3+PWPOGSkONH3ZzxtthCEMHGYEyXO+OO1JXNMRSkX6EuM6prxaAiKJzllaaAwqWGwYuEq+pyFWvVyd14p"
    "H2u7HrSHmyxxUZsEFVA9Rlz/oZ0Qoh1+TkeLifGdPA6HJ1abxZ0oyC5wxuJqeKKo36zCy12G8v6WodeHTS5q9RHS"
    "n2tFfn38inyOO32zikJ8X9sU6hGxb7TTEl9Eo0Ukv6dbQqm3pOguWa3sUKRCGGHO7uuTTBsn63TquH+EFnmwLwwd"
    "jvp/A/JoX7zv28MLNPJF1WXSTZdRwjFK12n57t2cJQREbR7TSbBICvzTP2fx2WJysIIekDQssAEYedZd9NuDC3Sh"
    "wdOXWbXSTYg80INoy16Fysn1EUVBxiHhv6OHhR87w+TQ7ATLHraafQptOxjsARm0pw5Ti7kbzWfA6pkOH7D8Oz2n"
    "xyIS6JB4SCXP6ASKcnSLzJKMOnjmLVygP/wHoJNTTOUYrS+t7K+s8atbH6QCys+KmVp57Jrv2fTsr5g5CIsb0UpT"
    "tJjDKAMvhBaL6YMIyAndgMVOumdAETxBKqOb2zUmlFzNLR0CwTgslvHIii04C7VDJFkL1kCNIKWgJZplHG0Elz/j"
    "p+4bC7+g81sc10t/tV7OlOP56x2m/eNyr5KDiWXKYmVVKPezFsWJLFQvanVLS/tfJSSJM2RkRgSwO7+lFNH2l2DO"
    "A/HFzRW0QX5Gf5bEH2UWssarA7JgmliND7oakI59PAhcdq/F+tDZIPnhdb/bufhkf+z0WeqFEzUAO3GNwYL/jTGV"
    "40Kx4Bcbvl/0nGp5XK6P3XrBceDfqt8sOeNytdosj0vVJoYXFwrjWrNYrxRKBdepFwuVWkGNqRSFWKgKxuuTPKFG"
    "Wh2WPMGZaVNMRGeKECB1G/8Tw2ksGX7C45uIZjEZwEWhdHZRLEeBlOdktePN8O8zOJmjuD9uWWeRX2k3ZDyq0tp8"
    "Myf7SF1l7CsHMZAPacKzNOrfdJWWANN43ya7yHEVRptQjZdUbZpytI1XVUqEqIiflwswXyrXUuQZKGIg1bEW03Uo"
    "TKdReF/MhsqDWZVgUwwUVHOxlJpaqsL5/ZhSHLMBmcFWhPZqkYIAwZTlcCaSfKNFDfo8ZI5Kh5ii+gsFd1zzm2O/"
    "Vi5PXL9WbzhuoVn0ynWvUK6WJ5NmxfNrnl9tVCeT2rjUcOtu0asUKqX6ZFxujJWO829PY5Uk0c0umzNexigrT2N6"
    "HgmeslFNZ0EcW2a00Pc6z2uhZzK77Axb7wZtkodZWKOMX2NJn3nwNNIWvwcR1ZzO2YHH9Uxq6+jb7EyJ0JbJbjgY"
    "l53Wu15/OOpcwB752GH72QgAzYesZAwAlqLVC5zb2RyoxuXJFqOuYTMOO0Pcj1GeHKRgpRjLP0/ENSDL3KAk7xS5"
    "b7ibeshquym5yUFu9/FMBixMH6Kj21tTRn/oEcUUJjCRDM9TkYdyqdj1BAUIn8OJdka6yzk7ss/g43Mm+CgpNnnK"
    "R+vSd4N7jBtmYtbM+mfhtPg56liIPgxFYqFYohk49+WhTzmUqA2LZI3pLHj0Y5pJkGuk/sAunO+dBZIYCeNRBhFF"
    "Qo+YN/0EZYCi/PVG8qlshXXtONukN6jRxD4xNRHf33RHnetuG6l51OmBKqN/m3j9J689Z3v+xAGypEJscn+JRDAy"
    "pZSSpI9jkEuvvIRigeNKJnXRnmLlo2AGOzQKx2fyKIpLn+ONgM5sHg8eveV7LN4zPwDUx5QZlCfRiMOo2YX4W1Gf"
    "hmeUw9G1z3iiOaJNrMLCniD+lnMqm+jFKCMRj/va8Oz0JB4b+doc28kb6lF3r1NjB0+NflNpjlfZXsWbXZVTHCQz"
    "/CwN8QQp4QgmF/Y0H/hN/rV5HHc3Boa8zhn6cnqSGbP0Okc01ulJPGrutTnq708lmYca2U4K2WvGG4xRPUMWRS74"
    "o0jVF5mV+ElyNegjvfQu7c5weNP+Cz8TzlFVYscTGdv/xTIXktD2OI9YyXuuW4Nh2071m+H2qMR7RSkXYj2Zapny"
    "B+LEKRcMRV7Hc3hJUjySyInY6ZEZ7W/tT4lRmBamXgHr79erSYOVSGzE3qGdIcfilLIXJ+6YcjD0awNth33Fv0H1"
    "HokiPfaNaNUBMQeKy/lQLBxFVBRHjGcvyOUm322Qy1HKsuM8zFbON0vJSRMJYtx0hMfW/hG+Fbor+dAtR47jfC8Y"
    "j+ZlcNDJgXYpqzLMc3Op9OHYDcGK98jO2K3mw24E10HQq0x7N/zOeP7WuwBLQj0AdnmyNq7hhAYkRy4gcdQ+Hq21"
    "HwOtlFhX4JTVxohwakDpW5Apleuj/eO1/mPgNcTKF6n+RXSTwl0t4hjGDtua58wjkKy7hHAUNzQUMzty8tJwO5wa"
    "PFJ0lF7aKe4pHJmxt9n+KrqzShyD70GT7Q8+sUTFeM+G1zVDlix0V2xeQtcf2yjz8iSglPgUNsJV53f77Q0QFdox"
    "0Wh01epGYWNDFqu5UZZOdVXZO2WzkdKJWnmT8IvgJiYhTjBLjOoT8aSLcSnxhYpahHIWYJmOctoYGqrJXmDWWPaB"
    "c0qQK5y64vjGC3QTxhWzU5TZbfrA783R4DdhdU8k7LgxhOJCpVEXU/9c1HuDP7753hOtD2EYJyZsUdgx/tYTCgyL"
    "xQNwopj7yH6XgrB7Ko2HFqZ0HU+D8A5zOac6k3xXOC9twLnN0pBqjh9bL0K688jzrsevB16Pz3wWGZ4lQoJhjDi/"
    "d4miTqgeCcKjJOaBke1ashIezlpXOmSRMwfe22U7lHB1k4q0ztcrSqiuV3ZDlZQnO84zZLf9OxBSttvIit8dnDOx"
    "ynVmiKJ7ZyGv1FZz62Z0Yc3CDIzRWmc7iixyYIu5hBgwVYv3lcQUKwx2zn0o8iKLjWhEVD0+Js+ogZFU96xIKCuu"
    "fhr5RpCPIoWA0WWKxy5TtnZ+acSHJmmXe0Om9tYHAap/ZQ9avXfxDpvxDgXW2O2O2qPxpkXbV4VYZ/yOWNwMRTlC"
    "P/Mk9Zh4f+qM0Xsuuh/77wkr5W2LQt4sRe98PhGSEg8cFHW438iStawSOrnMUI1qFyO/8brbn86/nq3uYEisNW1R"
    "OncqHsZc5Bhth84qCCcPljv1naUlrLpvYr+tcDENVtb4wZrOw5DdVfxaoOLF69D6rSD8HYArFU9Lp+XTymn1tHZa"
    "P22cNk8BRcXiabGE3ihYjhvPBBI0KO8u5lddrlkxWrwEpwrR7BdemCFPnEWtYTKBt6bb8hukFlgRvDDqX7cH4soA"
    "zurO5U2bZQpWK0Cmj4CprXly9qjKhXR2yCw0gh5D0+kZlcMjxzcqXx3IpL3QSbd/AWAxM3z7utv6FJfv+PbUPSa8"
    "IIyK3+TpBausRKutZes2fj56D5h63+9exjtihFWqNM6w6ApFFAvS0cmt2DyvFk6rxfNm47RWPS8WCuaR4J9B//IG"
    "z79h0e613wESeSENjvUoibiSOpxVXZw9kCczpraPUncnx7jsXF21B0OmTcEob9tdEBPkHNkyyZ78kBM4L5s949VO"
    "KAPyLSV8ptta41DDFi49iPkfgejewR/ddmuQNYBWNj6aKm4l8wh610pBtEEHZSU2V7zhw+ufqDTNZipBtxIsl8tc"
    "h6MvcV+y+q2iyqxBQWB7T/gJMI8vVmdbekiEyTIvasUIfLv3ohGiCr2sZQ+iCUo73Nsk4SZy0YKDpkNo0jwz2peA"
    "cIPnyZ+nLL0bLC13ntQqYujz8f1atVitj0tO1fOrBafsNYtOwR83vbE/KZed5rhQceuTWs2rjceO15zUSmO/WmxW"
    "KvAvfJEyn0LWfHCxhzdvYY/RdaPm21aQc5B1BUwlBWwgUxsr1np4114qpC/YHmogGCZYbGRMMEeWcZhqsaFMVXcE"
    "Sl+uPXgfbkt+W3olGqaTujZ78NXa42zMW4kVjre9SPjJWJ7CuOQXnEqxVHBKfmPcmDQbZb8B6PcnxXqtNKlVC2V4"
    "641rbqlQbk4a8OekVnb8ul+olxuNFGKrZ0xo2L8ZAGVdgqb4rj8AxvtBp7I6nwmty5dS2XbggPbI+6tQJq8W+ZvX"
    "HPkIjVqgwV6SFksXgWMn9DHPgM3chKBZqVQrNKou8AenPoEZOw3ghbVCoVppNhululebOLVx060qhyZwXXY7bk+D"
    "ie8+wHkTq1dXtqKUlKJMFlo7v1nsrazsyPqxvsJ6+Gfz9Up6gi15BcnpA538JNo6VKMIe2iSpBOKEnQsR40oDRaQ"
    "EMWyL5BJTDqk8gI2IathhHJYiE6Js8gISL1SDePZmjuMsRJarNQ3ue7cWsXSmetPsVYz6sPobvMNq46tcF2lb/vH"
    "oi2WFJp8LMMi4nkILF8ENXys8oiHD61e5woYDXsmpD7zUzhae3ard2m/bw3f0zH8sdqyL9uj1sV7VqcV/vjAjCQf"
    "a+h+YbPcN+T0LevjstPYKn+rMJRb/A3zGaWaFefrGatdQbg541kqMPZsRrLhGyv0fYYDXmI6fEWDsJa2vh6vlHQa"
    "atWxkAcBxZpnFrTOGIU5SkZFwJj/Fcx7BqQarsS2EyW1w3OlWyAPG7UxrPIQnv8C/w876TdRF0f2ca53+WrhLKHB"
    "SimpLUdzHWZMJqmH6jeLJoupMzO9pjGZ/Qe1sH+xpC/2GpQhTCAZVcAUJe44axY1wXl2GEsISNzHO6qHMnzfOgMe"
    "Z+3hABJV4tiCkUbDoYshXZsn8JZEg1yrsqAKkTNROhFWKPZky9UibczGjawdBMAP0PENQxCWuKFXc3s6v6W6ZLDB"
    "scXbfr9LOU366CcIin+twqrUoWPq+xY7QfgfzFWVfBz5H+KJ3e0MR/Ix+3V6cgPdFPH7G9Yf/lMu6b9pOOV3Q/k5"
    "urB7Q7Lj0R9wWNBkaJZEGTRFaPALuUX+hnjAELibLs7li3T6+xp4qztbrLCKgdCezJfjAOS1GVtubI382wb+bYvK"
    "g3bEtXnWoqjE/eDqwqrUKg3rLZxGtQo53IYrD9k/87slHsQJ9ZSSFlD1IkbZlACKW8tO5UlCTOyUVyuPsk3f+ssT"
    "eWBO2B6pqMEujHapwJezfCAlAohOXrR4868zUEh8595e3LGwaP5GVlCzv86Xf8jHGExjs70atb0NVjahKHqk132R"
    "j2dwiHs2K3GG+3/s22PYC39EG3/mr7QBOZOw0VnVZsV91A5Z2UXlZwi6oXtnUw0pmJcXgcQFpPABeM0Sluo/OmgU"
    "FcDRhoxGfRwf989I0iBkc8uQJrJEKoCURSaOVymClFisVusl1ykXxpVKpTAu1ApOremB4jJxq3W/hOKi7FL2IkUb"
    "lOSYd2BMQ6pUS9BdqeSWCy6Io4Vqc1ytjP265zhNt9Twq5N6uerXSuVi2alMag0PVAxQmYoNEGqb1RId9Nhh8B9Y"
    "lQdazVKjXENzNONfrcGoc4XyGrc6ULTI8OYDRp60YJv/TiJp+dU9K7Ksgzepg+BVbU4qhSLsjWp1UgOoiuNSzRnX"
    "6x6A02xWJoVmuVACvuwXqsW64/igv4FG57ug6hjBK1abzSR4g/Y74DaDT1nglOtwMLie64AuCSpUowFjul6l0fDx"
    "RIAxx7VitVgCCio1akXQMWs1WLh63Xd8kCQbNRM41WK5IqG5eI8GUruL2u+AICkhr80ACXBRqlcrxWId5NWy64Li"
    "B1Jq0S06tUbFL3h1t1Dwfa9UAM3CxzWuVT0HV7NWLTWciWMCqdKo1CVI79D60SNzeuvib2gGETIYB4vrEnHAqkW/"
    "CXJy2SmWav7YB93UA5WhArRcqTpu0S/Wy3CqjhuuC1p40Sk364DVcbPgNZulcWNcNgFWrJTzw8UhMaCs5hSrXoOU"
    "lYZXmBR9dwznfb3ig1Y2bgC4vl/y67DQAFmpMnFLoLC5DVBn4KtawTdBBotQlKDBIl72r65svJbr9NpdWzm5M5ay"
    "UWhWx+NmqVyvgH41AaqBc79WdHD3l7zmZAIAVsv1ScMplMfjasmZ1Er+uA5qfnNSmNQnJrjqtWoEV0Jcbt2M3oNa"
    "9Y9WUuFNgbE6Bi3QaU5KbtOrNxpNb1wFoD3HL1VgQV0gsSYofohYpwCYdGF1C7Vmo14CepyUfeOqoqVCgZGKI3Zb"
    "bwFvl+2LzhBBG7XedttZcPnNarOA6Kq4AErVG/tjrz4p+IWx68B2dScN2Chlv1kAVlkAvRS2Y705gS3aLFaBmzWN"
    "a1ouFWsR9oagS3xoxflECvV7oMUXJ+XxZFwCeq645Wa57hSqwLHLro8qvz+B3qFtoVJvVMdOBaivAU2Aw9cqpbER"
    "nnqjUClE4Fy3L2yDSGiTfxedZaG/Ql0hEkczEFiHXVmHfV8oNmu1MvCOulNuFHzQfL2GX3Rd4L5Fr1wbNzwP1P5K"
    "GXdNqQnsBFhzudAwbopSvVCvRQCj9Z4cOTYvZ3NScxuVkgs8HPZhqQxytgca+aQO/wcHQbNecQpj32uUik0QxKtA"
    "Xch2vQnI6tWxWzZytVpd4R5I6O0WtzVuPoc84O0OdDBxK1W/4EyAvioNd1IFImp4Ew8oq+KMnUYdjs+mV3QnTadZ"
    "dysFOCmLsI+brpHLViPcRMXWbdqiQPPDLHj2Ut03Bk+5Xoq4/mMMtAewwiZPgnKlZAI2l/X1AFbUJIA12EMGCLc1"
    "nx7ARpqAFdhzyQjqlrbRA1hAk1TarDVr2wGbi0j3YNw0HCBFEwnkNWomYKxVx3CMeE2/UfWqjaZfcwu1SQm2FAgO"
    "9XJxUppU8ZSpe0Cs9WoDWFSlDGJhvQki4WRMvlhJOi0pwvBijgmM/PBcjbTSTXQaNktpkIKsW6k0Cw2nUS1Nxk7B"
    "A5mzUGuM62N41iy5lTG8ApGrCudjEVhTvTZpenASutVJ0YMz0EilhWoSUEr9jdFcIuw9EyynCFy75Ljlol8uus1G"
    "EaSDCYhcRb9eKdYKRQSp3qz5Nb+CfLtaKnnwnwqoRKCE1ZtGsIqA+yRcxIfagw7eiDO8GeDD+EZuPrWDgq2r33jV"
    "P19GeqBXh7V1mn6x5I4nTrVRGcMaw6+G26iVQNIvOpM6kCku8j3o28sA7+gdngxB6JI12JAF0JuAiMdj14OTw6s3"
    "68ViEzQEmGO96RdAOC6SiYTCNTFeElTT+fJBsweJS0XEBeivVNsKGgDAK27tpnrWYWRyc9AnhRn/LW4Xt4RdhKqx"
    "389nFmLxnBk5z5fzqX8ewl+zVeCeS0PJObe6nJNl+Q1d4obBtzOy3PDEBgAwwEtPyL1BmNBs7FOuISOK0xNhxpEP"
    "aC3JiOCtXZSqcCQ07UWrDisHA1NZL5S71rPg32tfjXBl9MCsE/OvM2hDvsyRYYE9JLzFclL0e1ddir5j/hSMeqQX"
    "WQ/DMbspL694soSO4namy/g3Q5S7umIrD4bM6n7RuqbkE4ZXw17revi+P8Jr7AHemXzstP8edS9fSxc78Uaa36+x"
    "45ueYoa34X8D9LxLKnHiDZe2pXp+0Rq1uv138j10et0aYO+ozMhBUZBC+byNry5vBiRo8refmV8gXyG2AFEBBGHw"
    "mTmL8G7OEwrYE+c+mD6gDh4jBzViWrtiB/r/2Ih5j4hOLeE6s1SLwzGHE/Yddz4xfsAvhrBhXd4SGVr+iQYolkSA"
    "z5K7MaEp6p/ZFLSB+jagF/bBitG0EWFJUmx/RGoAwfJDZ8SijmFqGh88w+wDU3RboJwsLSDwLqdRoJCLvzEnM1Rm"
    "B/2/b9UTo/iIvPVPM/CrfIwBu4CJlG+X69lMay8i6Td/0EfLwY1xnijVfBQae97pMs7QugB5c2Bsfi5gmPBq88zl"
    "Hzi//BqYQ7s13P5rA8FhF8WCxRimhlpho0Af78HHJG4z5iiX8vrmLdAwDfT6kZs0u8+8O9fYS+7trMR5L32eCwqL"
    "qeOdw/166tBNvfiT37H8pXt19q95MPuL56N8wbAlislb0bUD3feQZ5nI7qGltZHtoAXm5mAOj3/FoGp01ALEzW6t"
    "7tVf8bi8A5S4kc8kz4d1za6WWPd4HQgd3S7n64XM28Mv0ZeYB42SfXgB3e9h3k12cSyPZDy4LV4YXJkYQkfl5ZEH"
    "Yaw3Hszo/e2XxwUX1MhmY+IW3WKlCdLepOI2ms3aZNwsgZ7hgKTnV2og4jXLFdepNEGBL47rILaOG9UqslIAbOEs"
    "FaM6M97/ex0wLzUbnuFd73yB9zvoIIrC3euUFuwqFmB3l8ECtoct7yxFkRB+xyvvLjHTpLwjFjINP6x4I/t+7vkU"
    "NTO8GHSu4RgG2bNLeRpY9g+bnab6yFIq2uH6VyJFiHDnv0je/xvdQbLX9BA/kMc1Cicih5ACDM9HiKOx+SuoTAzG"
    "uk2gMlj597k+Z072aWsBPAuRjuIawzflo8QvQvJg8fxvNgt04OmgpDO6P+MXcdy3mudRZNfNJAKzm0tKhkWOHcHt"
    "jHllM8FRpLthg7C7Jzm6SFZiFwseScrWFwekGeZtIUuhCKDYAyuJdx5iEP5T7/Wz5UwwAxbzQsBtTRiQkV+hv5Je"
    "94VXrz6csZScvDP0G6GKKzPmnRq48kO2hf9Uct8pGNcdFZBfyFhAHTzmfSFRmcTISXT9b3nrJXPAYJd3hCv+/eqO"
    "3NWFnM47OrtHb7slwyoWI2mN+h86F/bbm95lF5OffXjbHpxaGFQAP7kYMyK/WTjWum1yrRcxayQfg2Dwrj3KCVSU"
    "fknwW3vlLG99tjUJoEEbxaXOhw83zHbKbAhq/+Zv9dniijFdhVyIJJ/HEdCZJ458ri/JxzHlV8DP7qAXzsN07njE"
    "6eFQnt0Sy459SzqW+E64Xcwnhi5C9WMFHpzSAsVbyuM4fiDAJ8v5f2D3lQtn1AQU4GXwjaZl2ACSU6kjLNbjqTCT"
    "IzvdchgjpBzdycF0lZNf5vPsuIJO5WjY1Rkfija30hGyZtdZ2vOJHdsvFOnt4H6jDmRkgdIx/9gSQkV4FyyYkmQ8"
    "kkjvjxOZ7l3MeQ+LjdhAmZhDVKnZpFAjPT73Hmage7mqrEJfW7dL5/7eWb6Rjm5m3N/PgYet7hz5gfqaebMrac+0"
    "sxfTFkef82Hlcakf0OEbSi16aomATOIFwkuMMMFd96LkJ+JUSQwr3eb4RhBvFOeSXGcayFLz6Vo9DpirHu6xjEnf"
    "r0N0koJvKXEwpYcV7n00LE6NfNteC6wAwyeWKuNc2DouH5jYyoBi3NUW4qeNxbjsyKUdzt2VtJVoXzyFZMJPsPNf"
    "kmfKb69gkU8kUEQ4JNOiVYIZ9Vqfuv0WZaHi5g/FQTH+yB52LtsXFJwgXnV6l+3f0ZoR6QXQfPC39sD4UOlBWGPe"
    "tXs82EYdOuNtdh8CIGMHHK7Ud0rX3fa71sUnaTNSQEt5k/6tAOktFu0UGIenI+bPaXqsdMZeR1p+t9X5ANIxDDvq"
    "XGx6r/SjmNaUyRieJr4hG4f+S2ljMM/1/26/5fkBM96q6yisd8qXiWdKe1UhRz9ggKhPRjXzi7QvJUEYnspvPpPy"
    "yny3hDXXdrz5gnGnyOcVzdNrYTjm2pIqLuDhSD5wxN6/3oG0P2UZTJBL2JzJ25L/oK8TZrWGowPFLskEWFIGg0Ke"
    "tJKc5rBYZVossixFmVahTPvUNmawHUxJCXOP2YKDGc1VF1apBhVRblJSbQuWS6IQy+ss9VkW0SjyLMKbELWHkKVB"
    "pwioB5GTk0xJwjxyTnamc24kYUYAYW9Eews6C8/8KQJJcieZS/hRKKROdhzKoDchc0r3fTqgxSQofTEAgRKJmNAZ"
    "Tgh0vCUpjQ9vosuO1d1yvr6FDyT9RWld5YWKcvWggpekf7zRWa8cabkK7uknSYK65ghq3xS6OgsRQCryyPKu9a4u"
    "uJT3xSclh9IOT32H1YfDb04tDz1ET60xliNgTygJy7kH6Ib/neG/vZsuYYzHFocP99Ng9of6CKMS5xhkHLrOwk8e"
    "np/5fqVwDCmcc7Z70b9u29w4QK0W6MW8nB1aBlCGf6UOjzNBn6SbHmyrPg/iZ98q4gsTVoQEI8nwtWwsL7pUGo0r"
    "HOiLyLROljgTGe/1oP+hz3lTZNig7aGLgSrRoAiIUjxXDVAJeEr8KW53R/Z7ZL8vjP0yTPxM7Fa79n4OhqsD8L2z"
    "XAatzbnrczJa6eNyZLNHNvvSpFwyaopIKqHzCfXwZxN7hbXh+SRfDsGLEn6lp47aWYySmDmUmk+im8P0RtzpTd1x"
    "ptbPw/XFIh0l7CPrP0rYL4qzP6eQHWMbRzl7x2PxyG+P/PZFGpQ5QGfkPSeARfeGGNlDT4v16icQu9kfPCwD3cef"
    "QfCOw/Ay7c7S/YBStzyDaJxA41E4PjLro3D8wvjvs4jHaazjKCDvfHwdue6R675EEZn7ANqJUNCfgxNz7+jnE4Nj"
    "cSEvVAaWUSnPwosFDo8C8JEVHwXgl8R2n1H6jTGNo+i725F1ZLbPxGw/WIwKQ8aheOxGyCMU31gffp36s79oa/iK"
    "C3t/zc+LEyFIQM/38xXRs5FPG7jdI1mxZILRecICCQ1sdzcnjDdWFJdpClCT0VoU7sb2W/hDiMg82IgqhchceRiW"
    "r1aBZFuepbrgAaHHyKBjZNAxMugxkUEG0YjvsLed3hMLRDniAHcQjqKE1LtKR4M+RqCzDJWUJq7f7dJBeUwUcUwU"
    "cUwUcUwUcUwUcUwUcUwUcUwU8ZITRej2G1ZuJd2kkjAHIGJxyHs4W3gBSazTKWyTAfGInMo+5jOVIhkrSfpI3Z1q"
    "7spUp/dwVo59LCiKcyC7MJBZyK2rVOCRmxc8RG3cfJzPZipx8IPYTDFDKKX67YjC7zsrBq8YRmFWKH7yFJXAOVz/"
    "t/N9yfjAijw0Bm2S7bE0etLGOV84cPC+lmtICTRRxP+87UYx2x4T24ddWYRYJAqT0ObfKiJZoWr7AtwvAeizL4H/"
    "FcvUIaCnlO1RNUft64qC30lE5jHgMTiENV7PPDoCjYav6AxhZx4P7rCi6mI/1OVv0gal7TFJJa2by87ITqT0lQ+G"
    "aH5GW0WpcBlvLK0cmNj+cVv0F551F+f02zlLxCujffgCn/8inwjCBai8RHNZ42z3u+Xk/s5M2Imr8bFhsTmY84Gm"
    "X4JoikTK9UfKDB95D3IQpO98GX3kUT89jzIbCvfLq2RBwu+NWz3mQvZ741d7va493NlwZFJHJpWbSbGrpz1wpoiw"
    "xNXhEP+EFqNnZEtRbDUOSTYfpUjsy+ZJzC6RnOFRvTpyhR25guGSfg+sQe1Vusw8t3plBOoHUq7MWSXIEXIPvr0H"
    "QP1RxTryqd351D6VLDO/enYVK3PbHBWspzod9sKgJnRlhvfS1h3sIOvWn/lL4QzxgtkVH16fz5FlYTm8DG9GM8/S"
    "6tRFnw2f2YzNl9hGCrOjdQ6PhuyDGrL3hvZ9yllHNnZkY3nt3HtiZ/sXw/a9s46i2FMeIEc+duRj++FjWabwLZnX"
    "ExnDt95JR3P4Xs3hR7ZxZBvZdvIt+YbW/HCm8q35hhmuH9FarqHmQObyfaH/qMkdWdkBWNl+9bgUlvYdqHHZu+qo"
    "xT3hGbIXFia2+n2wXDLW82LYFgwwdVyfONZsPjtz1qu7+TJYMUbBJsTDFQnIIztLsLO0cPxc94FP5fP9UmzfKZGd"
    "34cP90Es2UfmcWQe6Rk7tmMiB/cUeDkW5/yM5Onu/g9gPz5yjyP3iGXzMbOMJzIMv0w7by5m8eRmXjUm+w3aSOYz"
    "oLwJ0DeoNpQowZlOpbdh+KI2f2QnCWHbTH1997NCGxGGj9s9JTeaea/rW5x/0rk8xH6Ptvn5L/JvbPcCdn1qjpm0"
    "vc8BsH3cD0jR4rFIuqGn6HBg9IcwiBrCRANYTyYVyLfbs49j4ktT4ssN+YQp4W9WCuET5KZRK85PI67JXolslfiW"
    "0+PUWUMH1i1wDXoKzaYszcs5Jv4IZmuWX1jltofiqzy70nxCmV4SRmmaw5lw7ZaZh3OVGOV5g35Q3mrKQahxV9ZA"
    "afZ4iw0noHN+28Pqa0oHYfZTN2VGw+/bkMPP3/9wuuWkzWjenbNUR5jXFP47nq8p4xFLIJUrM3Eek7FSXlQoSnu4"
    "AHsUjvPYeY7M+MiMj8z44MzYbBFLMOV9WMD2wTJ+JMa8VwPZ48+8Izc+cuMjN35ybsxSbadyX7arnkMmZs9IJ/9R"
    "hWKa3LMIwypyj9Lwkf8e+e+z8t/NUjBv9ixisIFZHOXgw51z2zBiw9Xx1zt/ZunNKFnvG2u+uvOXX4PQtwppDMnw"
    "3ZEp/UxMyVgxxsCVjCVknkNMJKYgs30HlJD7x5MXxRWVPs9nER2NCN9BhjyyriPrOjjryhKszO2fRcLK2lNHUesJ"
    "zop9MC7hn3A29imL/s6cLE9HR9b287G2tIp8qbwtrUTf88lpUVjk1AnubeHa9eMJbOZsidqkn1F6S1uGPYpxR254"
    "5IbPwQ03S3ypHz6j6LdhQx5lwKc8hzLZ3x4uPg54RZHGjbVlh+31VaxrmJ8Rb+jjyIN/Jh6cVYPZwHnh5dBO2Tp7"
    "CljZnhUACYfnGlXb61C4gR/A0f1ZeS9zVU+b7ZOz4Wzc55FDj4z4yIiPjDhXufutGfLziMK5eMJRFH7i8y+TCe/o"
    "xZPGHcUi8O7OV1g+Gmsxb88k83V15JU/E68UFLlZVBUtvwMBVY9O/DHF0lgE5rMwwhie84igR+535H4vmPttlA9j"
    "XPAZpULz5jzKgk9y1GTxwAQvKyCOogQ2zu3t0hd8I18aiyXsDviTM7sZALO02ETEMsFAj2QiMADsOQ+autN1CH9O"
    "H6zJcn7PB8INzJkhaNdjZwULFqamq0Doic7gq+h7tu2BKfKPLPwozlGUZDkvkadojEPXJlvv3g3a71qj9uP4hb4x"
    "n8pYJ8hDUi9LnzJeB1NvD8lm8lvhNuWMOG6/4/bj208c1nvaePIIOaj6ceCNtkmv2Hp7RQE+AZd2Yb1mE/h4ZUkZ"
    "W5ZWzLnjpGR8CgSJj4WgLXuM5OpHbrzJfL084xJ0MrV1YiZSfH5jQaO1M4Wpyz1rfQ1WdxbbNPKTlF167yz/8Jfn"
    "Uh+wlCRPkbyNBI/4oeThQhL6kWRwfcP2e1fdzgXeWPA/hqP+ta26Qu22dfX+rlD77PwDlEDt+X5drkDXk9Szv2zT"
    "oksAYr6wGQ3twWsqH35yGACO7OHIHp6aPeiq7yEZxJ6V7MOwiL2qzVswziNbOLKF74QtdHponsPq008gOsjBXp78"
    "IMnoKUSICE9HOeLIML5XhvEkwkRiKxwlilR+mnnd2OsPPrS6opeU7NIR60DqJgPXg3LZl7wqTDQxcoz984hok+oZ"
    "4ilH9CRYhqs3VoQKi21tU1vYRyvLmXlWOKeU8xqj4BbBN2KfhxYQmOX57D3wBmBNZISiDkML1xi29Gpure78YMkn"
    "snKWt2T0MjEdx3X9BfIBPjQnRWZ9/FEvE1VajIhYv0nU2mDC6quWxn0eH4amopr9sMXn0XG/d0lFX+c9pKFmKaFS"
    "wH8kB8qHojzeDkf28z2yHybo/fCcxeyrsInD7MNjYasN9N1zmb1KN1uw331zFtjEzsxCvS6TuxibHTnMUcDZp4BD"
    "sv3h5RsyYrxY8SYF+n1yoDQEHUi4ObKgo5DzhEJOGpfZu4yzYRv9xCJOJgc+6k5Hyebl8R5Wod3IcAbt627rU2S0"
    "3Lc8E+//JdlphO/m3nxSsjFzNM8cJZfvl3tkii0JLrJ3eSVtt/zEgoqZtR4VoKOk8kNKKvrl6r7lFL33o5SSgpej"
    "leUoq7xwWSXGR/YuqZh3zE8sp5hY65/QP64gcK3VMvh28vq/mcnG4LWRIQgugkHiyEem6AfmxfIviWj4NxYryi4C"
    "6wER9L2tcaZitGs4SnDHRJulB8AB1XYR67gpMQ7tpSWtipMLg9rkPaWQgYi1C++CBeCBcR4b/fZe50lP9OdprixG"
    "aSsN2yTEWMdgMoktL0UOWvz9jmt6XE/5eD7JWk5cRmP1kLR1a3X/3vo0PNhWS+Yp3jdtZxYcSMHGRmp+FFaeAyMK"
    "dRiXXyIiLX15GiYSiZ8d99/rIAyYCy9FJ3vBrQ8ik//vNRyHPDMDS+sv809blOHVEhlezYg9KRL30OsDsOp8iD30"
    "woZzCyWYSpQ6loNlau9PeXKWXERs//19u2dfI3/ojb4Dit6UWXnTim6k8Y0rm7lKmWMLbp93Cb6LHZO2M/48NaSs"
    "yivw8NQ/KCXHs/88mbize4KkfVN2evIbE5K3kjlEtpjDSxvPi06FbJNUiVi8GQzwhHvX7rUHTEDo9C7bvz+XACB3"
    "1fXN227nQlob9oALljfANGNR1/wHnLS+n9Knru2sHM2eQRI6JJbUbZJBH2nIISPnz0g8mnUmCzs/K+EQZfx5qtXt"
    "/j50q2M5aFEOet87xVQjWCeB70ihPJLBPslAYQfqjperf9PrjJ5d3DhSwJMyAm3NkwzB/PrIGH5wxqBzAqCG950h"
    "uQb/4OqXmObPonPF56sygNR3P66QnFh+QEO3/a518ckW8vPL2QCmpIab6D822Re1Dbaar7YLUmatboZNTb73PbEd"
    "cpQtkUYRgJOUeLZnopUURyAjNtLdFfIRzIZYm1TcPCe5HBo/Cs2kEEYcLc9rmXo2eknapbJe/0SUEtmjrjEojWRf"
    "fvObiob5zD9bzc/whmr8YC3QbYgAZPn1pym3flN/9he9Xuer6FN/tloGfvjXkyc+v7J8qAZtVHA6Hz7cjFpvodGw"
    "fzO4aG88zpVhfxI7cHLG6kbLePvjCrUGIvgTcJHwALTd+Xq2OnndML1Df0KCYxvHPOlt6H+BlzPXP/9FYuC381/k"
    "a3pIua3YZfVF/7otnKKfbDzpOvkUI/Lr+KecpBjyaeZ5PWgDE2dEd91t9Z5kpolBn3KuIFyj1eQJJypG5LP8rO1b"
    "7rh8u3Tu74EPeEH4r3mA2xua+KcnzGnbxqyN0xVVQP80ggPmso00Amfx5c01MQ04am4uLtpD5ICChFrd7ie7/b9v"
    "Oh9bXbK4teAAoK/+3un1gKe2LvvX0sJFSelOPiPHma+XWCVm5bh/wJD/ZR7yHPrXJ+Xx2PGdcq3iNh235jjjZr1e"
    "rtT9iluqV8te1a3WXd93qrUKNHKa5eakMRlXytWSO6lVq7XyCXe5D4P/+DZzqn9dbFQa9erpiRAHXheYazR6Rbc/"
    "lsqRDS8SOTQLXutDu3f5AWd5OWhdjV7dexSOoEM+rjZKpWatVBk7VW9SHrvNUq1WrzQK1aZXr9Yn42LJqfmNerkw"
    "KYzdUqMxHtfrfr3ulCvjBkzFBHmtXGuogBdjgIPIdAkCQ4VVoCfzJWhoF1xouvhbOwVWwIjnVOv1pjNxy4ViqVp1"
    "vVq1XPIr1Vq9VC83CpNixa9MCpNyaex4AHJpXBl7hWIBgK65JROslWKz1FBgLW2C9bLdHbU4mHahZIa0Mh5XxyUA"
    "q+i5JYS23vC8cs0tOLXmeOIV641xsVFqAIHUG4DzcRHA9IuNeqXgF8uNkmuCtFyt1WoKpOXtIC2nrH+zUhrX6pNa"
    "o+H7lXGh5lXqTd9vOBOnUi82AaclD+ijOSkWa07drYyLvud6pUrdA2xXymbKha+KCqSV7SCtmCGtjifVeqMxAXJt"
    "lGp1t9EojouA3YJXK5ZqRdhgBQC54BXgr0mtVC4W6tWS53uVslevTJyiEVL4tKJAWt0O0qoZ0rpX9MvNGuzsSrU6"
    "rhSLk5pT8gtj35vUC77jF4AoyvCu4buVSq1ZqNR8z2+WJtVyo+g2K1UjpJVGqaxAWtsO0loKpE6tOGnUm/Vmo9ho"
    "Niuw793muFRwS1UPAKuV60CfTWBlbh1Wu464rpWrzqRYqEwqXq1igrRUrDZVSOvbQVpP2VFNb1J0q6VC0atUvHpx"
    "7DZKsNcdALlSbdZLwHorjWqxCc2diu83Cw6QiQt7xhv7tWLVN68+TE+BtLEdpA2ClI4uZ7WG/k7gbIMj4937kX3V"
    "B/EcD6ReG4N+yXTVA1bdggOJny/herGYL1c2jzGZOfdMWk6cqOI8xIA1JQyGdD/4er7w+SupFqpSOG/GHX55S1EJ"
    "RjjrMi9h/pIVRKMD2/gxC6uxtZg6Y8PkTBZTZ5b6kkbMmgkr3xZrwWs72VgpR2+izAPACiZ+qL9hHsrsiYzsspfz"
    "rzb5LsZQxb5R6zuStv0gmonk2lFebePr2+V8vYg/NCTkjr9Vgxb/xJTV8JeNiAPN/4HAWqLEhrqgXk8LI7pQP5xO"
    "gxB/84C+EMjNCjyWTtoLJhOfKmSJFWSRfRRBGJIC6U7XGC31z2Tvp/IRLOYSy+gBnkMQ0NQNfBr7DutULb1YE674"
    "WaA2rrDCIPo/TwJ/6lGtIiCYCQZAUU82NhfUxnYQvKH4rJm/+jpf/mEbB0T8Afo8HwS5O4AXOrVRlHVW+OAeCSLq"
    "lvMexN79Yo1K8NifzJdUZ2vN584xw2qFiYfwxxltTM9iyieOGM0JgwyViaXMIw+MOBflNYYN7n3BDf2rq7FYOhmL"
    "kfyYUyxfCHQPXn7ZhVKVBOYCaAkT9GrTbxkIrq5OBgVnEGcuIhdvOGn47jpm0RN4mK0pcDH6gjgj8h6hEf15KiDe"
    "62pKLGQQZIRHaJy+tqwrvp4a60cbDc6FommjVTBwJ1ntT9ltCmQ2h9wTuh8HEibCj80v/jJkkf5YtxaW5kvAfz9y"
    "vRlUii2Wfq9CexYmOqBI0lPD1FAy8HekC21j4AMnpEPQ85VTCQYAEYLBplBP1EAEO2S1oU6QrudfuSEtigu3RSP1"
    "pXjmrD04XOVRrGwDBXg4nr/MMdYbjqnpPPRxMvOpl+DP0SfrkMdYqw/ZTIGY5hOJ1hx7Esj5D/8h5eDS1/izjPel"
    "KGjF9pFCs684E9Pq6qko3kDM6jsi7KhUtWm5dqH97QlPByBqqD8XK5C1K/bMWeP7Aaa4mIOA9ICS6K2/XCxBik3h"
    "x3HuitL3GGjJ9cNQCk/K3gd+6mLIvu0sb78kHiiFIpbzb3CWOcsAKTYE+O/nX4jCRecEKxERT5pAkiwg75aV4aZX"
    "/jeUtdnOvlutFvR3JBgLZNMrpmzAP958DQTioLQa+qSKqe95b+O595DsiJ6SqsP/VrQi8URM8Y4KoBqAYc95L/yX"
    "1o94JlG+gp+Gnvhz3hP/pfUknomeCMI5kf9/FFiUJ/wL5QmqOMvlesHpMGKmEYfQNkvOjZHONLT2r5hMz5JHxHZ5"
    "SDwEqAOom92/2A50/RAG4WOZycZOn5qrxI6j6ChK3yFE1RL26EQNFyBRMI2MeNAD6MGwHUzvgNzmGK4afy9o+xvt"
    "f6Zjcl6Q4D5pX3yhWj1h7INkO0nt/tTH4ryiqzGQzB8K6uLv9f2s8ErCC7CZ1RykQ0r3gRwS82PIHmItxJ+CbwqQ"
    "dBT64Xy61kCezXUs0/bz5vdOELVxPFhhAPcetBbPWTm2Pw1uBeVFHbGcKWi9UDu8973AoT8zGrl3zjKkZC2GFmKF"
    "47OZu8w+QKo7F17iRGFok1y+IAzXPq1CeJLYrXzupinzrRJSNTIbfgRfnKk0JRhITe/a9279FBLTG1L3oD7PBc34"
    "iSYLxF/KO3ZnzE8r7Y0+cUlbQGsBHHjIOWGScAot8IpGIpCyCdlMkYi9ohRAaO1gTehdRP5sCl7sm9X8Dx95jz1x"
    "plPMk5N8wyNNlWVWZzEFfgNyHN9NSTTTBfnXYObN4zPRG97DwQF8jJRwycsYSvOdIxnnhZFZJw6O2XxGt/bm5smj"
    "REfoPs+T1J63O1QyD904ebDfsJ2C2QLFH1ij4N4XrEO+hb3FR5T0Lt9NpnOHLJthmHwcYv10LwTm+40YZgAb1TwU"
    "vTKNQy9igyjPWM+MbH33bi6Ux0jEZO/C1ZLxs2Bmp9MgI9ncMoyOzry0qC10ToLUvuFkyV1UKE/SFpS4BTFFY9D8"
    "QcgXSwBYQZMscWjSLdHYaBdsDV/0rGh4VsBL6MWc5WSIKRLsm+z3hYwllIIB6yhHQ6AM4FZM+YZxndulz1pE0fZa"
    "m9kcTQTOdI2JyeDXTORv85QvhB2dFkch5vmSM8+xfnQsA4MEreE/i7xUUhBqtKq+oKI4cwEHThyjT2Mg2oPBRoi8"
    "EbINOv3XZbACKWW9Mip0/FmkMaUqZcn+Ij1yCvDf+8mXHNUBLb/pwzSRVaqgma8DToim9RSfRsJF/uMT/dQieQ/I"
    "AZPQ/ULr/hsypsh57Yt0Jkyhw3SK41wuBLnLAQnsa+Ct7mwkoGASuPbKuYUDY74cBx7gX/qlwMkAEqk/nYbcRYSd"
    "mglChB1Ik4BuMP/caNDpvTvhE6NnLPUgc8hDLsvT2wlo6AiSH7K7Uj5UjMT1kW46lFBn23Hws2JNG0duncNNxbAp"
    "DzeYRnKHG8bESA61RAkGtbeByqUY7mKM73D4y8VSY8OLrJVbD88+VIfPZtYH3NVpx8Dhppp6wDwFdg1H10bkCp4f"
    "DcyY8mbsZp2KG/ZMzkENuzPruD0gIWUf5E8+8IGRnC17HG62ilSzf8rFi+H5wl863Nufifj7uHrK0etW8rXaH+tJ"
    "Xtwot2/i7oj/Yto1P7xQQWG3AtED2SsJ5pjoeXYrfJHgNfeTUS4d5guxFOhREUxDO9JZyeE5kjyNEKerMSkIi2nI"
    "Ka1IJ+aGWGa63VbVMa1hdodbLZ+8XMOecX3EUcBcoQPtIV8m+Tt+ly6+VW91mNEN8YlZx095FjnlYgiPV3Um69Wk"
    "oRq6yeaZtBqrn8SWmhsmdUbADLFewAy9zEGLrTsni82YSKeR5ILEyCPZQKUMxRq/F8Iw9/couvi2YKxdLIRgY7Bp"
    "p9P5V3jDrwoSa4FSd6C5AEqMhuo6C1cSohrD/YTyCKSxQLbCb9MIYL5kFBz95PEEMr6AeV1Gv4nayJxF4rTnT/xZ"
    "iPY6+MuBL9EvIJVqNhJINAczfUTvkTr+vXaWDuXwhzPU878d2ECSbVTc4TZ5+1vjA98OA3oDDw9tMhc+1pQfX55X"
    "0tvt8FatmAkUREzQljgcJzKQZaza4CKroXgpxk++87h52vCRYm2VjZPPxra4skl2qj4b20mTrWid9gYA59GK7JIJ"
    "2bovJQz5eY5GUU+e7zLPO+Rly/TOsttF/UnO5KzSO8toNI6cZMgjaqV1kP4u+s6feSlfxd+M5TUdvxpjfhPqp2kN"
    "WOwlRnTalI8ao0ojg7z6jF+FRA/Ua1TlsbpaeFkJLFt5G0N/skGEUsMrNn0+B+WNmB33F1HeIO+A8y1NubgPwnty"
    "IpcXp8l9p18TJLae6bXYKKqjqNn4Ht/56cwq2r8ROSRMoX9GWEq56Tj0sZNlhBd3tVLNTJxRiTeRoJCcVcKwHfN9"
    "k4si3+fws4luzvnVjLFV7tvm2BVPdAcUCUVYqpBLNbaM4z7RIi1JOxJiWMzJ1HgIppORAZFxypFRGIchm03Ukn45"
    "GD8kpVOBtD/p6xI7ONSL3cQtaOxQSG8b4/lqQ6YpmY4r9ibl7GEvTWeJ4ZhInAEMCaY1S6OMPd7MxEnmeB+TfR/z"
    "491fxHbrAdco4gOHGyTOYfaGtYY2TJJxHfAyJi9LfCoQspntU0GRwcYPuTHTDogYoY0u7N5wF1JjHybHTDl6Dj2s"
    "6VA73JiG41IfbLf9C1/VKsaB5CF8mGHSj/a9X/B9/jM9CuMo++WW/Q4i4WGpynusmImIYm76ShqpSeD5miszGwyk"
    "M/XviHAUY6Z8BmiahRTlHn+TGX+TpTA8ofCJ9HoUPI+C51HwPAqeR8EzQ/A8CoEvUAhMnv4mMrG7neFoZ1phXxu5"
    "q0nCODSdMtnlCUZ5Cn85k7x1uNHSJbnDjZkpIx5u2Czp80D6UbiGI/pf8/USt8VhL1XEKGmZLbaPfGARkokUFbsk"
    "A4iE+ziYWRcPKvbEnUOUQUomRz4IXk1pm6NnNOvoJ3diUFNpaJ4MuteUnp9X3oACgpJeLSBHGt8o7igJQDOuBBPI"
    "k2gVl4XjB+UmU3G+euKwLh5dReJnFEMlfqrhS47N2pofF+Vj5X7Wd9w7kRE5LRZq5jtL3C63zoIPIGIITS+LykuT"
    "tS5FkNpVwY9dbEdjS9cqJdY1wk/626LmT+B8zXERnePi2URI2QQXG3p/lMaHo42oeqPEEpWpD9UNjB6K9nh+r8bV"
    "hV9sL3Dw8pffagPs3CWJc0AZQqC8mvlfp8FMeEHiXCP+Qk8Mn/Jn+qdohuBaWag3pzeMD0VrZ5xvHIQcaxpfrsR6"
    "Sj+H52Me4rziP9NcWR65UfXNR7rSPcv0sPeNZMBpOt6Pe+h730PqUsXWMfLZeuI9k2Yu/xl9JPbleiUXM7HICW+v"
    "Z17ihONlGs880sLOtEDolpSQ7iy2QxBApuvZ95EIKpHoaevMUHqaGzpNxA9y4Rc/0PWNSfORv5/IaRPLGmIIGtkl"
    "i01Glhk5i3i6ncwsO5Q/JJ74hh464+QzAaz20KMIKpfFsmKOCBaao71SJDQiTtlChvGLLKBAC854GoR35E2Y6b6Y"
    "y2cyy8XxsU76eufmdDvGNsq+3GdynU1dPkVWnfkSOPuMGw8SWXWQRJgUZKOiHLdByHazKOeNuUN6tak3lmBHPo7k"
    "ZpXqxU/jOPRmwzDUJk7g4jn5e4fidFbeBjOeMuoJcvHo6V4yUvGkNySSTXf6eE6hIrow3CRbSGZzFDkSARwJOVEN"
    "yzG79e8WQ7BHLwudHo9+FkenhJfslJDgXvpQb/v97g4D0WdaagEzTzxgLoMUbnvAhBz78+/YFwyPdPDYFxiP8fDY"
    "HYZH+BbnTd2xb+fix467k2PJ7oNu7VmSc6hHu5bsPE6WYHJAf4EtRJ4DXOSTqONMnSW9omIXUXnB/xn2e/iE1+8Y"
    "XF00StWmhY8t1PKZ+mE5oUV73l1Z4RyLMpyBYGbdjK7OGm+s2dyCDQizmd1a3as3FpNzLBFZiFWEQWd3lwFq2iyn"
    "BgeW6O6qYcvtfXLR7Q/bl3b/7f+0L0YKYLQBpg/W6s4X/WNlKup86U/eWI4n/Hd4xRBLymVvrPUM7ztRDYEvWAIF"
    "ixkVolYaVADQzcXoButBfmx1b9oEWr83VCszxlBHEFpSkWP9W8AqplhOCuGENQ9XhC5nuvKXqNZ88S0QAqj9fGlF"
    "EZAI1n0ST7HBAahb0KnG0/nYnrOKLHgLEGOaZPCYkVx88i5YWdhcIKFzCfD4IJFaQC9nvHgAqoRLFKD/v38WzprO"
    "2eTzfyuFP/+XGI4Xs8o/IPtg1yEjZdA4lOnTWgU/jUT8dUg4/O+JD1ru6xwpwVFqx0qh0OuMadjMRMfqzMhybMn0"
    "6zznCBckiQvo/bBiXvGONqdPBh1HA16IqlvCqyX9FtDG+lQGA5Yzn/kiSSsrWJRrJPElSxHOb6+SHaueOfvtmb9G"
    "HrGvnpOmUEPP5vVNsdcluk5bzd16VepyrWgD5MODLPCldEA145Suk2WGcnaeVQXNsF3MC2UuzMKuJh4NRUo/5iVI"
    "qcATpqEKW2QT/f7G2Y6YNo9gqrSTt/d4YZFkn1rxlX11m1pc5dEDxFJN5+5PTzaumO5zfp/Ihr3FtxHMIHCaJ0Pu"
    "tAxAL1jKInX7GCBHWYr8q5L3uEyrJnHokTLPiEedzaeHBdxQr+PQuIrVwDj0cOo97KHHipdTeOx48duTaFSNrWw5"
    "ue+TJ2XV/vl+5fNUt4D9kdrpbkfX6V6EyrRbzZ1k1jRyVi7x9yQLawWO6B5hN7asdMPUBGWIZPrNvMCbc21u9a2a"
    "h1FApFXC5gloWZf55m76noRj4wCL5Rw9C7fsXKbGVXplNWriJWwOxTuzamp9x4wmrZLbdwyxwS3qybniBj6RWuXy"
    "sQqDVvPOFpEM3/tqmSvz7Q1oMZb5Mi83689wM89PFxts9Nt2JHxy8n6mex1EqGHZfXcQWTcQeoYP3NNLKo8UQA0p"
    "/h7LD/J+LZInPgYEo/ws1mlzjcvvl4WkJe7fSmBMT1Mvhlk47h948UU2SlAj8ssgt5gtFS8qbNGHdEOLGTwPsAOZ"
    "nx1zJzyQHM09H4N79H+9Xxx2mIQz8t7wREePns99S8naJB1redCfWVI3lEfYGZ1GEI0DaaUK9tl9rGLCPrtO5NTf"
    "HyXksDLs2rWeun9//WpFAw7RLS8+sI+uQSjG+IytrqKij+YLYMlf/CkcB7oOagp/firLV2ak8PPaz2IeJiJD+Las"
    "eaNUnDKelmf88MOJrOeHm50hx/gO10mPklQzZc0sSLfDypPBGBrMaVn20kfa52TLfbpOxDtVh4vOcuZAB8r0fLL3"
    "W1m9QkjefuOVQLT+MDH71Bn70/zIUXK6572DT7UunubVZxDOcH0P3z7oZwJPveJsd32pJ2xJ9Lbbfjd3mZL2//vZ"
    "oomQwz0J85Ll7njpt+HETQwjXvKqW3BazmcYnpWTsDf1E1cTlZomSo6WQ01OyxOxH2uZHEOWp8uLKfyAkUrODZwh"
    "2+3QQTBDvjgXnGDfLGhX2wQvZLG1l9te0akBs5X8rYIR9ZIR/PokHOyAJjvjJF0SL2+3lhh2OBS1cfnZlgIV7//Z"
    "YRKBWXlJSpRaWt0BGHfzqZfu/XdYc3FkbN/yQ8y//MQ64nd6x8Ex8tSXI8+pWEdku9XOyyB72bO00/Ib8K3O9W2v"
    "veNpJvYk4Cl5LR7fI2JSenRTeogQE3hthfh0r26tdw8EXq6t8ZKe++0/dCb+LShdmpkOsxhOHCrmKXrjT8JztRQn"
    "1aL0/HM438PzX1iWk9/OIxI9T4zyitIIJKDQgdxyhtEUon45uIr4xSTivF2nfG87y6XzsJUYZyf7yn/AwV7Y/fOD"
    "CrKbMM0xpeDbnc5DLOe2XlBa3Phgw4v37Q8te9B+1xmOBp/gj4+lcpxc2FEvsm1Kxrs/0mVeEucpA3FwTvc0muAp"
    "5xpnfKLBGXfbMFiEeNXcQ4nakBtRv66z3PsyG6If+FBEfXtbb22kczYSvI6n4o015CC94hFgCbhj8R9bcZ7sOJQ8"
    "I8UxtGvEyoaxvo/10IHKuyLfFcw67UfiUggSF4au2pP1jDnSbUVIWR0tlqA5zpyZ6+cbWGmfV6EDmQjERvNIeowK"
    "F6Byzyv6WtX54j2Ld4eQapLDJHjzFsquBnwywdfeJ2I+dRIDxunSFLCyw8qlT3Cf2PO9W3nRshN0SgdhjkHC7OUR"
    "2fjD8yhQ+qL/4bo16rztdDujT3b78l3b/ti+GPUHQzoTi3H844p6DzPnPnDtcDrX0b6HQ5eRjHGj76t3Q32C3Hi7"
    "GXTt4c3b60H/oj0cAvZ6o0HrYkSDFWKDUfB0MFusd5b/pT3A1JUyUGpE6rYhrULUVmNjoSUwUdcwnKE1imOP4RFK"
    "l3jxA/wi9oTxDjlgeJ4H9sSBnGvC3980dPrCfh7SnWbM7CVtA+Rke/F6IhE0qVrm3k4M9TriPG24GI7SrjAOvrao"
    "rMIreVH02/n1oG0Pbnr2cNS/tq86vVa384/25aPVqX2CAwdBv2dftTrdPQCWsXh7RkHGSIP2dbf16YnG2ozNGFlG"
    "0T37Peag+1t/uVhSKlLf8YIZ7vUnoXvj0Ig1WzqUGhrE4E93PM6ewLv+x/aghwWsrlsXf2uBLPOh1etctYcjI5o2"
    "+jc/2k86GoviRdhtfjy9Ebc6fimV8g64sbOQess/eBgfPYlbWr7AD8/fj0bXQOet0Q2KiCABXYDsyGhdlRxLMWQH"
    "GPOJx5livNkKy7EOTCpdepPD83suqsk/7FRgYojJNLVs4gs2aMu2pL/tuMTGLB/fiX1Lh3pREFcdi/l8SgLT/F/J"
    "TAx74KLJZebpsp+EkYrRztPASIE2aWZ/BlnHCEwWwLpZ/7khTpMmsdGXusyMtb8Nws7G81j/sdHTfYi3MX8o7lFa"
    "dwkrFrdwTIJvvrflGCnGEf3xfjerybF3W6ANrsFJpKQ32r9pLGO0lOlTrfbkDe1hdpE66LkBAjOM3EdYZG4xmWB2"
    "82iOdFnziMa2OQ0/g/b/vgExckiJBW340fnY6rZ7F23NBFRsZE7Z4H59+EmnZcrZpwN51rgJF/ADD7wIZjMclln+"
    "D4/gKHDUWaIqc/gRub4Q1W15ui3Eh2YxsuEhlnJDFO6O0bybx5FpIrbnDMPrfm/Ytt+3W5ftgd3+ndgBqkOadbiY"
    "YA2pIGxpzM+AIMuUn4KjneOlE+CrI8VjEfZ2VoJMASIDHpXqGPGp6vZUqeXvV8lRrLkGI26KSwP7misWwtBrMOru"
    "XfszD7zFpb3WgXZVn3izNxxLpUgdwjCxpK1p77K6eZhcsCgBEts506VMLb8fWIpVUIWX3ZerOQP2cdluePcMJpkk"
    "FLH1YvdEJn+iHYyN8UsnQ23r7bwBU9zOogHyhePsV/FKGXQPStFWqzw+zwYkDeqIFJ7I8pAAN50YN2jqT6DfqeOe"
    "b8zTn4lq0ECmt/NlsLq731rGGvZvBqBqXdqt7rv+oDN6/0FXu+ppQxrvzZ+B8ZjgSIU5ugl+FtJUwU6CkgZ1EM6n"
    "jAqwy3CVSIf+ZGZ3EyBpUCsofmawzZCkwb30b/0ZD657clarHqgGONJgJn8+fzdrZcqMDYMIHjVfYsjC7Pa51zUT"
    "oDRUrWcBJnc8FLJS/PkP46iRMlp86lEk5d7AwD7Po44TIxrjNLfEeFrsX3KIvVuJuee8aZD4VFODqw4aF5kYNRRx"
    "K+mAhcmAjb35yxpGiyGKBdLNQLieABl424nn8Y9hEwbhSqWH1Bb7lcgTPlr57vVBnOoNr/uDkX3d73YuPhlv8cl9"
    "jNc94vfa24xB7pPtQSdyjzGPRZFwr1OzexzoYjptvFdAQf9e+ysFtI1Z/p7KTzqC7cDhQFJpxaNPKrDwwRbYiQVb"
    "HhpH+nBGOLVstHuP39L73/9SiXG2WptY5O6BIxNwDCMU5iD1Q5CEcSQTTIZ46INgJzmOARp/5rHEkeGds/D1rH9P"
    "Z6XIgMIAc7qf2QEWNn0wA2SpqUgeAVeiTwkkHWRTZXhT6saDL6JwKkmObUBQMjXhE8MXjWyALpGPa++sOj6CAQhT"
    "RpS9SW76EPsIKd7Oh0OMmHiQgQhK9PF8XiZGyLSEYnu8ZcR+z/XuDeNnZs/ZPwvMGs60yZM3EPvfSMkxnk5GfZKx"
    "hd6dNVaEcWH+GT8oGW6WztfnuGmIw5AFrzEdzzPArABsliQzU/88A8ASjNzwPhM1qONnwZmWDel7u35Kn0OUiOlZ"
    "TOSMNWeTg0j59AwAylrfRvCMyYcOacM8GMPeRknOyut/oMlvNFbEsnw9vWSoA6BAiJWkhQORcGj570k8uoOeiStg"
    "ltZnEnyz/l+L+Un8JSoNLkqpU5V1rZuzzqUlhrKiwI9TXnXd+sN/CE9Z3fXTWN31vwJ2JMtjJdABh0koT9OykVDE"
    "kixDbwya0ZtwLxLLgx6wsjs05LXXT2BRIxC4Lxcv54UfLnwXuvwS8N+MYBKDUsnE/7+9d9FO40gXhV+lDjP/ih2D"
    "BehiXcYzC0s4YW8JaUvImcTR6dVAI/UEAYcGy4qjhzqvcJ7s/y5V1VV9RxKynLDXnlh0V9f1u9d3sabbvY01IvsC"
    "3mzAm97UczmrrgP6J27HxAeRVv+2XLiH40tOw6GWo96Gfqd0pRXfkmiGFgUauqHpiJT91t7QIjHSYeuM6L6FGkcO"
    "Nd2bIdIy38s28kFabHas31zf1eJfqPC/yExSE0xEGqZdB0SaRW8kIq8LhCeaHwDyMO2QmYOckq5kj1SmZJC8rBC3"
    "15yCLB+TI3RLkivvM5KokGgR0RHd25kXiPFAyBqXnk2/mKT5IyRDSJai1McmWiPvBv71kHIFsAsA+P7IiefAKu0O"
    "3GHg3WUjVvIqUoiuprHsiPoA+pqN65KyLUYOVcWbAPmiD+ymL0HWcqm8SAWKFKdMnWUB4QJgFnEX58MHjXBxPZnP"
    "JBmfjq/FeDS8FfZsy9Zcy/GZlmPzLJeuqVfYxOi714uRENG7cmE5QXh62I1wR33xyUenGHgF3wXICq79ILCGFLLI"
    "HJ0idJ34JuMwLS6n4ECfcPgEhQV/BLIXnMbGzpbNKbIg9fB95T8gGgEQhjCLlXmgb7ylFSjAJsEkcOA++SNgpnEY"
    "ERNxYnqyEOAshoZNDWbHwMlf4Ggk2cQ/2C2dt9qd2pb95W7prHPaav8gKE4Pp/S/4a3zsVrZcSuDiy9bG3d/Rwqk"
    "XEPgg1jXwg163oiIBQEigFz19euNnc10ope2vbQKCd2BB+KbS/7+JThloluwYaILBNPzRsLt/8ft4eHjRz6BqdpX"
    "ZzgIKc6kasTfJtGc8Cow3HD4iF09EG2NUN7XnNQDXnPt8yG2GHVDYFcVT1VYSMpr7V6Y/NosZETcHI+4Nx4OfX49"
    "R5JaCtxrjxEI9xDlJNqkCnudE8XUcGiEICcRQYNhjebDIe6+wTLNJGk2FQY2Mrvy+NwFux4Ia8P3CtBlBDBT3ckT"
    "w6N8jXCsAtjFvO0lCXqUYBsQjjYXa+3ZIxB0JOxp3x8MPLz7CkkUM8z5CDCAFkvbDlJ+5Z+CcmmcNY8a7U5r32kd"
    "OPvHh4ets9ZxG3eZkt+Ew8oRYFLswvO2ugfC9hRAH4s0hFCIlPQtnsKeGLpZb8OubUn47dmPDdonnEC4Jwmsz9oT"
    "8xBISUP94HfPoQ6ItFpSZtxVHFdmCGi07YiNumnI92gKsgqiVMXwwAbutT+8xd9w5EhrZOU+OYDV6O7OZMmGAmK0"
    "MZdkUE51ArSo5AOAVymbb3UaUUEukHN8cgF1WA23ZiMIqz+h8IVseXY1Hc8vr0TGGokxjrxPBHjcGgGwOx2jkMxf"
    "RtaLVSsAvUYVBBHR8+A/8wCG9GeBYGcegO4+tsAGzsy93BP8DfxEJV5EPoQWon1+eMhM2h3OuQVSW5gKoZ6DrWFV"
    "U5oU1qkKpBapGIIlEONaMwTiBMDSYTRS7gkHJRuDLAAYwoCxOs3h8LF+xjROLVlTAxRhUbHicnrqQ7TyqCEiu728"
    "gZLg1h4N2fk9xsLPtjassUx8WNYYGXiWu4klhL+SOexsOi+0i+kovMRBU6lDbFQi0/eBF/6QzFoRbTQyZJ5KxeKp"
    "Zp1Cyq/dW4Ei1+H7JHHVkAXDqw8QoOejwL/Erw09s4wEawQU4xo+AV1NFu7iG3KTEu9uVav820yWEl1dyGEMgUZK"
    "7jhBQ8LPIDB5VnqpdUuX0jDvx6L6aij7+9bWJm+r1j9YJc1IHVcuhcnCZHIu4jsp07RUV92n4vB6j8rhOzLaItRh"
    "oZlMKSDO/wzosMZKBI/0Q4ptfqga3OUa+h5XPVtcGXtkbSlttYlbkiE+D8c33rTnBp7IowMvSybMmFiO+B9BYja6"
    "+31nCBO89giUXb4uYNGaxnVAh5ImXXwpZSGy9Ko3WhOkYnsz8xHsGD4wxQjUU/P3zBIdaJvCon6LGPwTNmhR3aGw"
    "3hCX0yOzvkiRfFPvCTKuAApdJRjAVU6Ef3UrA4S+S+TIMtQbioF9gkGBE7TXHjnN+QOube5pQUxWw+Fcb2B4EcJA"
    "OGoEGjLPf4/BRLekX7BMoZaeAiD3slLKOwqYZw8t75+NZ9GLmPj123JvO3KMspGLv/SroHteFOXY/ywohnXzDQbV"
    "mJRKvrTFemyHneAZsHFk6lXM4yS1qouxFoK14z2p8OkAKU/Q+YB6JXR9oVKm5TiWM0GhS0r8cSGZcXYzFmmijT8y"
    "DMOKz7E6WESgVAY81OXCfkbuNcm6HFj7DsNpD1oUkNE+Pj3S4RmWYV0bO6uhaELlN5RsnuE85CaL7IaIul6topyf"
    "PsXmv/cPzw+aB0VmWMubYcxZKH+Cm/W7i3yxNyX0PgIkideH2YKvuk9Kobf64qlYrPTLNEOlzrhD1ggYv9qte1V3"
    "o1avunVvu7s92Nle97br1Z43qL3Zqg+2Nqvr8Lbf3erVq+s7g234c7C17npvvOqb9e3tNMtxJO3f04n/mQGJfwXp"
    "P7LzhqBrUrFe8MmI08fTQElTRQ468m6SFn74HgbbP4V/YJKWk6G+cOZg/6iwq4sjsrOEU5VeUPJnTf/U5XCpVfRB"
    "jS2ifV14PKwtq1p2HTXQyHOnyHAu3YnsDk4Vv058WTNespUFNgSek/wck8GZUxmidyG5O3xwA8CB0pwekp32lVcQ"
    "U6JwE9Lf1vhKI9xs53LqYmgoQML/rn62b6B4IUC1HMwqRnZ1o/WLPyr/elH942OtsnOB3118//LFr7++pj9fvfzX"
    "S/5+6F/7M8xjDb/g93jeHcKaxjNt2enPJ0Mfq5crJu6OboV+KCxbB8p6wPU8+AeY3P7ZB+EHwhUItwLDNsQNmj3s"
    "2xi6Euh6faLpGjYV1LJR2B/h5giaV18ZUVFEmLAYDA9h2Kl7o4C8C+rc1gYx0d64z5jHKMZOW3tiPOEAEPHu+IgH"
    "cQO+d0CjsqdkzeZ78e6dePeeurIiarqAmL85iJ10GfelxA+uKD8Pjve3v/1NnMGfQ69C2CB+aKLVkJvBll+jSYbu"
    "8Ube55nAhYuud+mPUBgU+PUYjdl95A3kLWCdBV9twUrnQ+AustjbggueQdcDkN/E7950jBiHQRSshcfJg7x4Th9Z"
    "A7W5BeL43Vnz9EPzQLwA0AhQZn8p8cboJGBC47D0yLSpIpBC7gpojX8CXAdoeu/bT16A0gGKJRBjNOT3XeSAL6EJ"
    "2gAjB4b0AbcCRh0iyAPaaGz5AloqErrSd1++Ex8DOjWHwc1xg57vA1UAgfW7XfGdCABo3al48V0ZfxRo+vL7C/Hd"
    "3XdIiMbTrg+QPiKDCbydELlnrKtI8MZZ4gGUS22QQOCfDuAh8jfkv9gJFtFkJzCu+V2W0c1CXi4R6wMZgzKaGVwc"
    "5Q4KbEF/RaGFfDxc3EVc/ces1WevmFZ58Z0053qXIEd9QmvIDCT2KSU2QLXAokd8ZwTH6ODuk0WaFQ7FshT7+Vgi"
    "lj5j/juddQLGR/oXhwBNeAjrKNYOGQISPuAyFxd6CghbCQMnfB0bAwdW7XTXOZ9csMunGqm0BkpdzwsqgCSU0wGF"
    "AAQexK+0A/lDJGw18eDkD/QpfPexUfnFrfwOp/Da2V179f9VLl59h1IuwyRw4akyumtZs7hEwGXByf1Ce6pzpXCD"
    "O7WPnQ8grh04B819UvGdn1rtg+OfnMb7TvPU+alxenR+In799YXNvN8iV5MsrCxifNx+bbN0+53Nsc13v/5KrFEX"
    "KUS91VU3AaEHGJJRZEEg6V6SZqeZV7nEe0V2TpTz3V7PmyCC8vMyiH3+/8EbQ1CUgrLBxIAFIROTWx3lZQqX0pi9"
    "nP/fU1DQbG2LBfyFof6gtcibArW6VhzYHcxQ+4Z9QGMfEhIfeArI60PvM4n1U+8GRH7cGObEtmsFwJIUlncNIlgu"
    "EYgyuJV+LSHswPLxClNaTbE9rx+5IO8msX8h3xsHEsynU7QY4N/UL4sITFz7/EhL2CQrwPmHfkDVCg4EIsXVbUAr"
    "QvGFj0BoIzXtgjxdgPnf/Ik0iQSg0JkXU1NiJyxBaUtw1gmk2yFMWR7+HgyRVna9K/eTT9KDJY+VhRxEDIDoz6fw"
    "oDcdB0EFwVkoJF3r++7laByAALbG7ptC9VwWysMM7VJDd1IW7Famf4JUMh9pkOa7bynmTee92XyKtj0WCVROli+W"
    "ckEmA1O126wDhQQKAdOFX/WNbRAmeDRS3g0BMZy3Q65tKqClRIKlTSoYr0azBDIh3kbbvhLrW1UUzamj+AcISTY5"
    "Cbu3SQn0HWlYEUn6Bg0kJWWUBoXbTewOtpaw3VCGRbgNAXsWhB443duK3mjCVaNtEkkO60PjMR21zs4wMeL71ulZ"
    "x+mcNg6aTudMX1Tr7VKT2kvYqus5SGRdTzXgcXBVAesA/iC6QYA0Y71INYXT5tnxIQiOTqOTOAXC7djg8lD2okOo"
    "3tvH7ZPjs1an9aEZ5TysdEjpH8sTjqe6v6Tz/8fbhHO9i+8wdNHz+h5nzkzb4dR1Z09ZetYAJhA1Qw1NOjrKOVwj"
    "6kyDK3+iqFFEI9+F/jvO/5w3T1vNg7h+Hn2dpdeieTFLs8X3IOUA+1KqvcwbVTo5bX5wWm0SCFiACA0BoB6tuXHd"
    "W4onMSWdnt+F62BnKsdwnNJkVi+VKKBhcbh2JxNSYL6U9IafnLbQmHnc+dE5ax00z9Ss8Ql8GmnXbrY6PzZPVSP1"
    "M9buuN2k7lRD+E0nXkA2im7bXUhDC8CCZFRqCyzFxDzxi5Qj+2it3pi7td4L+yztYfBYL8ITZK0+VC+lUwjf+z+x"
    "/YY9SIyJ21SyO6ZYLRuTxNu3AjMkNc/gbJtnzXaHiIaNT/FGKBzBRuwmbTO2Ns+YRDFS94htkOWAGcghflZpCDKT"
    "SF+z2DioTUqRdCgvHvI/i+1EOj5ZaGvKM2lpRyOSDcsPLH6Sgg47AJKCOKPPxTsRxgeHZie6ZomYUS2bFGmUe8AA"
    "/JntaCOq7IVT2xPD8fi3+UQNdCDYXtO9lRInKKYIdD4o1PqGk1ArAofMNBzaSCZdR43O/o/A8QahI6FeDc4IJKgK"
    "A11lFKgT0E1B0x9PX+hZ8WQiY46CtZq38/J7+M+eGCMw3PiBJ4Cb0NgoNZBLtowISpoagrNyfYQf46HnqsmkdGki"
    "5JMs2hwwf8WaJTIDNqaGpK1xcnLY2m+8O2yGq1du6/LecXYlxRae156IbBaoeeYHqi2LYnInU+YWEuHkLdM7FUpx"
    "WtCMwKd+jnMId1gJify6pxH7BVEYwZTFJCsvU6YaIY7ZJ0xohqO6cFTiBRHdMtDZl5mAFBLtp4AiPVo+COmUg/kY"
    "g7uftUZW/9L7Ma7G6Fil/a9g/0BnL1mIQj1QPSbJn2pliQ/re6zCg34jVNm/5gH5deENPNLFD2heQCqX59bEdmBV"
    "vQqQkY6d5Nrm0bvm6dmPrRPHWPvZ+bv9w8bZmfmsc/zfzbb5oHnY+kHVsTYemxJyo73/4/Gp+VaLRofHP4FMFG8Q"
    "ytEJr6gmkJKqjDcSI0AIb2C5IP3mgjVS0A/ULYixk3iS6JwAarhiEYiFoB8LmxKh2sTHg2ea9g5w1CZTwLyGEbSJ"
    "OIhqTisDCCxpRaoygGKhLxOjNLmqTny8UkF3DIO9RrVIg6hKaiCNfHg/SbxTkZ2K0QsCIam5JrUxoVi6zMOc8DpT"
    "hQ4ly0L/y5aFDA87MpGGl5ACpMwop98T5r1kQouaeYfalxm/lUHDkzmhiOcTWfAHaG0xvMdM91zY8j5vnUsV0QHJ"
    "ZuTIIYVudfH8xcY1+B3zcJ6gY9F0lHz5F/W1ToqZIimFRDYSubsV1aBSr9a3KtWtSn37NV06xsZO6j48oy9J7tiU"
    "Jjkczrq4uOAeMUUym2zeHR8fNhvoByKHuOAxtCXZmvrPIJO2j6Hx+YkDSIufYRkH57x9QIpVu3EEuH4s1azz9vkZ"
    "ok6Rhd1Fo+EWO0EjDC5xV1hSzq2Aqad1/O6/mvudlOO0ROZHPNf0QL0ljxMP6XvEAXW4otXnSdXZB8A7LQQb0cgl"
    "9FAZTypEmkQs6lHapr3PfkDqJdqTtDMMEX2KSyTqQreZgi5F7TjBECZYDdUb9BciNYYyT4uU1mZdB0ZG9MJhNtoH"
    "jTOn0zoCht44OkHJoNFp4u+QsCBf7zR/0AaYowaGsFAky0U0lIUcnMgeZC1HSxNooztsoujQpv4aR+9aP5wfn4OI"
    "c37YaZ3od2fFVmpSuxTawVp2eL+WQL9YM3pOAGLLjZlnmHBK71rtxunPzvvD40Yn86iYYdNdXf60eZfoyuXL1p2T"
    "uwbZu3VP9CX1THV4lyGYLGnZtJCvgRx3lpRkVSuwXc5iPpI61ZF2DM0rClM2QtCpBAXVYGC//NktgzZXxlSeHTI7"
    "K4ikbl/d15Kb0cBnH8MwKBurzwU+3rSXxaVPhb1AEXLGmMkDf3eH4y7/Ijcj9gsEQucPuBfeA/LLEWc/NioYe8Xo"
    "x75ICVMfzEe9aHVzXCPeOeCxdee93zy+aejOfRDjJ4DuNVl9A1QL6H5G5r/+GER1XIIuVI46A3kbkNIxhS7G169P"
    "6Z+yCDz0t/w8cUkzgd9X88Fg6JWFHJBUuLLo46UtCPN8w0esjVz/zQHZeRnX719j8gtkeYpUGwpDgFoGWh66Hkja"
    "Hn1geL+6JPSz/wm8vPHRjVv5fmML4o/SskLW4PB6SyXODM0jnFmKB5TOc0DA5bXjQfN9A8iycwI6aM05Axw4RIP7"
    "L015B6nenzWbB6Vd5FPVrfo2iJanrSZgBZB7qcCiwf9jEdkTebY6afbdlu7QxhmTi8blyEXVwn7zwmB8u2gJeEnR"
    "DrMphVLKnuLQEekw3iDsNzSc7oozuW0f99XDUwLhi7KQNV/QsWoXQUu8Fal7ySAWbYZbSrM/BGEoNgKlRzMRDS/4"
    "uv3ujtvv1Tf7/Xqvuz7obnc3tzbf9KpbvfrO+gY8ra73yBXCRln4duuNO4AWNW9jY7O60d3u9b3tje3um1qt9qbb"
    "396Gn/U3Xn0HLXCYfWu3dNACFR5Wg8z6wNlvtI/boG4fOu/P27IIaIMiXUNKgY4g/iVIY5fjtck1ReC4096V1cZR"
    "NTR6U39C9SQBupUBHI6jR2aES+/1hEzkFrBqD+54No3d9Z2tnXXDyRtFW2WiCm/ZTUDcrW1tvdm2IHW3Vq2uhxrU"
    "br1erdXThLl0CQ79mX3AVcqZLOeg7UBFUKRcUuDl0YW/RjsD6iSCSuMZRcrK6g6jKWwLkh5noJJhAeUYa3fKzaJf"
    "ydf4Ta1cunGn1/OJvgLaRX8AEv9RVk9Q/EN+VwqJoaZ844FkB8ELU7AqGzp02dB1ywlH8JJcyZGFELsPFhtIySBl"
    "SxAra8mhbItO5bisg+NPqtaoKYqKUIpWWeSkhWF2ylfsGrjkelWKPUvnUUrhIktn+T1pS8t6vw06+7IU0/L0W8r0"
    "T2sSrwTCUPz5W0G4iQKVsjbDliMDYwIVKC6ordd0mVEBUZwj7sMXzPcQs6aBMIUruoaV0WF6TSo9eVFpSnWgxERp"
    "yJSPC4afMFfmHkRY5y8jOkZ+NvWiWXi0OqwDfh8esBK5YNSnymGV9zhT0MAwbpESd02n4+54GtpVQ1G0ZLwcXQr9"
    "ERne91j+UWFApzLSUNRrpm2gC4xBcCwguZEaIkRJujp5gEnoQE7cXVUaIwdXJmSezAiLCwnvVoyHpDxaYkiiKMF2"
    "Xn3PKG3F5VL4KGJGNll5cOUuxsoN3skIsxg3vzfrVWgQxafiQB0G6oRMMx5ZlqImqXReRjHRK78r/eMoicyQ09mQ"
    "/gFynVAggbL8GI3nIeVYa6ztox8p3u+p4M+ykKckMNgTf2HqAEmbyqS5BLdAyEFD8Eaf/Ol4dE2XiWEeS1IEZCJG"
    "9rf3Zuz3WCAW7jHCz2B2E5ahjYiyjyVTKZBJr6iCQ2KmrTDYQCjDn+RSjOPMkULHL7UQIc+U+RF2JgZDNCWgmwEg"
    "iBug667ylWTWhR2DDkZaVt8buPPhLOD+yYWS/O+kDG+jdBj+iGJ+4mItDidMMUKYcoRIkuUs0730Rg7opp9CTGgL"
    "ZxiDggb7NTLXK1cTufSEeB/ROuC9wZCD8AJdiYba11S64V67E9svYzbWTZL2BW+rSGQxk8Lpfaon7BPNI9lOx5ed"
    "8BpBRs9QHzXMLWmp3CU0hJWWFTwIdf9J2KFWoJ9y3sLpreksKLmA1qJdDJQaAUUwo9c1UI9nwBsJNCXk4Az1OFLW"
    "T9kwjKY0K8EYO7Ye2zHldh56PNMucViVslAo1+eAnL1BdJS7w70r8CcWsyYlTbzJpAtnDF8pCwpXEW23XWYnzLWb"
    "K3/mkb80bSFm3qj4owAvTtFfXcC4ayOOfFGLk9er8NQakf3v5agqFVhoefEpNga7ns5CN300FU0wBNW+bYfGY7wO"
    "r6j+Ak+6mk1xUiyzkfQcxpujvz6oHf71/NrMKehiAVBAMOQ3cuZ4EyrBTyNB2fBdp51Hd3KcGN5O2jt67Q7RGV9t"
    "O970a0Gex1Pu3nzpb8AH4xBrEAQj8jrYhI2NVKqjJoDJH0I5jfa9ZgCt6VOWvdG4xapXla94aph1tPMDp0YCunxr"
    "BiAYOUEBJ4CQeRz9KRMpKScLBMFQstvTiZYAm1ULj0Rza7I4LvBYysXaN1Z3P8mRgh5p6nQFntj8+03xT/lBeGJJ"
    "4px1XJux4yIj4gRpSt+yJSIkSQCUgwspHCIImSTKBiIgiAES6PP2f7dBmZdxFF5ABIwWpqyaCkk5DiAgMo8fdvbF"
    "z/B///N/jIVpFz/HmKO1sq3MlWVYRTnLSNwoqZXFMnoSloUyNRinix6GMh4H6DyDNjxCODXvXABz5TS0HDa+GaHv"
    "OoWAEj7bBlVEBpCG0Cnq5LT9g2F4pTCVCigMQBImeJvoYgwjoQD1g3MwDLBJO6iFdb13b2J7xyijTqpskCj4fOA5"
    "6effxTwdXqDFG72dTDxCb5CKdF4JfdwR9UKpiMJpkfaUY31htP+Iax4BfVWqhYx+KLPLi/QP0ZxKhlNhtkFkE2Md"
    "IwFEDtRp5KYK37gpLWtqkgolFFNykYD0UvYVM1wMX6Ht5yUdQ8/zh9p4+pLxmbBKyTtUitE4ITYS3UbVJwvMt2NH"
    "ZXqnar9UHgizUIZClz+SkBEeJpveytyHosTo7MV0d8qDg7yP0ECuNhVr9oQ7MLay7zN71T1t7GxpTUL2FSX7m3Xl"
    "zGT65TImbZjOktaMVCoY5I3kKc1pE2TCFyvsDFpI+kLnRbtoEEwyA5NeY23zDhe4sNL77NbXZQYLMyzjS8msfE2x"
    "kn6P/GUHA49MfFfuEB0O5yPZEOPiwiqCCNR+f+6RkBS24DwUKOSAQCVDuKXVhVGjDwqVZHtAU+lsP9MvNMjwZcuH"
    "avlDrfyhXv6wXv6wUf6wCf/fgP+9g//tlz9slT+8KX/YLn/YgWbVPRWB78o+yMXAlSetISUM1OKUEnqVnJtDcy5a"
    "DuuNFS4hLYZu1xuW7uzci8CodAIWytf4pdQLPu1ijJ0K+pP5tGUsn4I4O+hQViqWdaRLnEl5KvhT57B11iGqbORr"
    "5eww8jvpuQxfomeResoxBCptpXyELrg6XnYXL0BxIJnWk9pw8is5i5JRFnxkJcaUpVTiY6sXMkED3jfou1X1Diaw"
    "/Qf8p7aF/12v43+3Nuz5oLZGAE04mbB01Vn63LS4+nEUlIExX1BqgH2nfWY0mtNk5jybOU9nruZDG3Mny9mYvnDp"
    "dZ4tvwPlZKCyS5uJ3b+EGVGYu7m6Vo/VruROkMJXiCxICvIUdaPvjHQc7lCFp1yrVTb2O60PjQ7eHoaZVoC0wLl7"
    "AXDvsBzthcrxx5SMszmTf3qPL6Qa550fj09Vee2wYzs7H0ezAD0ZD3T4lO0uSp5P5gx6Y/JPsOtZwE577vVeGK33"
    "ycxSVSWuyxYpOxbnPjnvrCx9eP5cXJmXwgPbSbJlA5kkY5jVhjqRIU8qW6/+TjUyX6pnnLNYp1U2a66E050C4wCY"
    "6g5vHbYxIX8BITSaQTD8ZB6Qu8SFkeMi3D2Epv3D47MC4FIyAUA5LHeap0eY5chB7+PTA+sdxuucfmjIq8v2fvPw"
    "kFJuOWedxinStea/T1qn8Ah9IzmyaxF4lNNeLjCyaEOnvQLAZQFgBA4WAMRckIl0vVxgAdnEhv3mAYOO9L9kOwr6"
    "V1rfrwBrWYBVkBLlAlz0VJPgLn2TKAq5yEJCJ0sThHWo9cnp8fF7k37mbJ8Mr86D+PT+M852t5qCGeQTZa2Usp6o"
    "Geg7oHKY7kdZdOXFB8N0KlI8AkQnA8yjo9szxJQYTnwFvp9Ls2MzfCyq7V9fe30fvgCBnZXtWOE0pteY2/XGBFsx"
    "m7Nxa2kw+Y1S2YcjjQmTBCCOdmB/HMJsA1d0iHzY4i+aH1oHTYBlMwz9q9K/FSgtLu7EYW3/uP2+dXpUhAzeF9bC"
    "IVaw9heFtTi3LAxtcRhKI5a54JjEs79RgFwB2z2kXl2ILfSNvm+96KJFKywbnv6t6ohk1qAOLaCqwOMjbKOJEH8N"
    "5TgPxe9Vo1zbpROSl3+JHoMVoCbzD4bxaev1eOHk/Lg5qtWcGy2XAF85MY2JEJnTb3KZ59Q4S1kSLHdL79mHDi8u"
    "vkwTx1LXmgEdhWaaDe3pMBLvIQVbF+7CttEUANJ8alBkDjZJLBS9aVLNrA/4Cu0uiThmr69GMytmo0rtiO4Z7yLW"
    "q0Xh0CbQCVHYZvGs6EQMAhEvjpwc0x2pMZXZY7BgjwkWuQKblymPZW9nHqWPT3dehNhiq/zI5IjfuRmqblyCphA9"
    "8j0vFp1uO08Yw9TXMzoIoTzLqJlLBO6MLMwqXEUF244HYUgF+iJguhlvKIu8Y1QueR7QLYHlZbDHbzkPQyD6PpZG"
    "ROduzIBjuqCUokFB2jCH36E/GPtw8JUD3jW4I1sa34vfT8gv+RLbMHhpmLnypuRCBdOmoAG/J/THqhGPqBxzySXm"
    "0oWdCCifU8TCRvE65Nc7NaJ2o7Knyp+li1GpcAHdgKIVpA/XGtXypJs6n52+eu6IXANhzGBwK4rZJsn7dzyC/Z9L"
    "a2CYqa6UajqgFaVoZSKba4Wlhmdj4Qr6GDqUH8k8R6lapMjlSFb/eM66fDyG2J+enp/gcLDq/WMMno2PHRXMyiJP"
    "+AlbpIsMllZIvYaE3dANnSTdUIqVDD1h6BbllGbfNGuGFXQ4YvikFFcUZoBVvJL3OAc+MqUYQfE8gR1cZeKUSr8f"
    "erQHVOgiPBUFABSTKA9V+5ZwDIwYuugSTKRiPkXuInOmzezM6K6M9sPHCXBFMWBTjgN0w+nidCqquVofjqX9Ikfj"
    "ipyBwjUk3DJVW4KWaMs7F5FqWpKGUo0Qj4/PcCkKizmaherZDa17a7ZUfoJ7VL+JnW+5kBnX5rbKOO2pBAl7KkkY"
    "jlEhCmxUptUeTWGxpGIrRPyzaoXliPrGF2amlJV6vlLPCylgF9lhf1ky152Z04RiH2YqM6sLO3Mb+Dmuc90pemA7"
    "pkeamXdlv1pz9mvrZm6Ua28Gf85cx0wDq+yNjYPGCWaUPmp24M9Ow8GbveaHxuG5vIDEzvGQVVUhZ9yDRaqAWJLi"
    "OA+3akjuoIUamUHecjoYb9xsA+v9+aQZm4quPzJT8fvqsx+bjQNYRMoHILLMPQJy6YU3GjvWRLrjvk5rHN5wOpmT"
    "0WnOVeCKczWboU/xeDbujYdqweq3MxkP/d6tke/8uHO8f3wY6xddZjFIJ0yiqIqBKECgnGLSLz4cnNtwaSmthPIc"
    "oo04Ol4qjDJZ+n5tw5G7+L7VPDzQSRbvDUigQpzvd85Pm0a+xm8JmJLm/ySAU/qx0zlZq1GajVzwwba1GsnGxyit"
    "/rAYCGGch4sSm1G5QzryY4iUuhQIhJL3FQzoyq2cwygTxOqURsOAMJB3OudnKxD7aiB2T9pUlJBwBt3z9tn5yckx"
    "Srb6yO5/1kZvxU65pLIny/hZOfcKkUihpY5sKLhHJ3lQIq/0zAWxQmi0abyjJu+OD352DponzfYB5+/Phaik7fpD"
    "vis0wn3Bz0ipPqBoFy6ass99VTrQ156Ifkijn3feb8NfR2GJg2lyw/Zxu3G232qhdoilt8jg0o0Ng6UA5pMJlyzH"
    "6QtpsXoK0luIDm46+/UHSGicLPuw+UfsjX2auuHzwhcz6Lmadoj3RSq15CVglN72541OhCKpOKSRjVEtDYV0uN6z"
    "w5+7+wYPWcGMZA3lpCFongkBkixG0znVNWNNy7tvmJHU5taSlbwwvqgcnSlZqDCNy9i017IENpP5SB5tQmtht2v/"
    "0H/jB4UjoB7i5bC4DSPFBhHaH3ALpHmNsu0A1F1yOU0CVrUNhhklmMDqPRtRQYZOeqfpZ+R9nIzoFCy2BSjji08A"
    "+Zil3/4gjUDl6X7ZuGSZOWwkzkfzNNzOo9lFyGG5CFMMa1VyOsuwQ/I3pj8zGmG1yYCSXyW00NWT83hdEaaadHym"
    "NUKmvwipg1x70pIlqgTOf2RFGx/UNDlWIqjZXXv9Sy8FxOyG/+GagDjBqXGwZhPOb5L8Ttqn2InKemMvXMMWwJrv"
    "BQ5XWELV1agbp1ORcVnoyCuO11dVKfhdCP68hH7kG12JcwAqcNcFhIm9kczWOGZzFbGScZFtJo9AWSHDHtpuKCu1"
    "XROAKVqWvKWaZNkhFYYDUAE5MscxoAjSxX1VMhyP4tfBtudRXHgwb7C1HFHojjqbJxRzlymIhzn7WByd44vIPfN7"
    "LCTExoUmbiJxzkRT6Yqq6Abf1jaq671qb/tNf339zaC7tdXd2Pa23d5Gf6u6tbOz82bbXa+9ebP5pr9d397Zqm1t"
    "ba5v44N+dfCm1uuVygsvPBUPCzkApRMu+NwHoA+c1L0LW5fyYJcyGsTHS6DAC51eIgXPOcYIWVtovBhJzBkrg/Tl"
    "jJtJNHNGNZnWQsuzuV3CKLmqdQFfsBy9etEe4vpy3oqzBbf4qtPE7LyB0sXz2BhJHLyY/162O16ap1KWPJF9Ajxs"
    "tqyXRDmyvihOPVJtGNlHka5ZxE4iSXPK6z1R2YpXkck3kGSPU0SlSBg1Xe7P8CnN+t7SLB7Sh6HCFOkm1yYT7yN6"
    "SlqbU30lbVmKOccqq5R2b5Bh8ilWC8jN4OEpyJjmuZrgblnMdXUh7csQftzNzc3tQW27utn33nTrA2+7X98ceOvw"
    "d72+s9nrgVDUq9brG+tb3na1ttGtbe/UB+vb/Z1+d2Nn400h4SfbUFEEjtLNIAt9XdAQYuxPt1qrerVtz6v13c31"
    "LuxL703VdeHfTW+n7nbXNzd31rv1zR2UIqvV7tZO7c1GtV7tuW9q1Y2t6mL7U8zsYkyvWu11t7ydrre1vj7oeVsg"
    "q/aqO7X++pt+dX1zfTDY2eh7W31vc3tzMNjq1rd7b3q1/kZ1ow6S7vp2t9j0ntwvOMUqWdwtONvxoIC8kmnqXeR7"
    "w4BgrfbKD2YsWVAe8CBezGgp7s4pBoaFykZFbBCFvk01lBT4+nm5WaMfIfogGklcOIWpzhGrXTWVg6W0RAhKfGfn"
    "q5uMJ3Oe7q7hdat64Bp8+9VaZb+6TrdG1TeV/fr6nuWwa7dWVwn71Q34aivDmKqcqpU5w0zHii6hOcyb3MBVPWOq"
    "CkV6ecUwxsPgNPnauq6UlOQMVRbJzLkssh3AyuwlojdezWyNsXWNcVd7heypPSFvYXk4FU6g3LcuV8JE094UExsj"
    "+KDopnok2Z/NsPu1DcFPKzyqTjXJfri8R3ovo3OEOUEHMn+ySpsXaKdd7kl2PPQB9FSuUePYcKKySb1a5R75Q/Oy"
    "WfvGyJMIwjkZ92L7tU0EMH1csTZlvQL0jcdZU+5WOdEwTbKajswvr5O7s9FJz0bWxLgcUUJKOUh1rb62Hj9WmRP5"
    "rHN8QrKao6Hm5Piwtf+z86F1fEjO2qqkCbsya07Caa4D7R3U5/Nbg0XD/9A9HqmpuJ7P5pTYmdyBA4COPcEq70xe"
    "OZLqx1lbg0BQhUxZ1JzoB67e7+m12mEDYXZuzjzOedMx8AIzq1OOMdDEAKY+uzI5ozXlMMXr+1a71WnuiXajvXZy"
    "jA5L79fazR/wXwJwPhKppoZJwQPM44o3cBLV5Xi6isbJLVCLkTiGlzDBm+Z0iuXWcFk03xezl1R/jf6evJSnFIj9"
    "eo39rNvH7ebRSUdWCXSwyhL89ZMsrKNy5I5l94JUSoFzJCKtPLnktCvEKsIAEVlYHUM9NMpwE6yYrPscqcTsEfd7"
    "Zsa0ezZgGKYbaxrcd386nkzUrYv5mQYQOJI+khHiJOwcDxJamavNl6l0Q3A1liUYMKW4H6hEypIRaPd5pTFzel9z"
    "uAoLgyoBLVFv0+udd1bG+98ngCb03LduPiOG9G/eaT9ncTF//Xzb9yO47K/umld3zau75tVd8+qu2bg2yQllyTAT"
    "ZESyWNuxlFTQlo/UA3JBJztp2fNfqiNUBqOEFUXAjH8DWlKZQKvas/kWpihH1Hij35FU6aiaFpHHspgCEPHPymqS"
    "MhS9ShqHXkQGMZ5xz7I4Z+9qrKLcOP+8r2vVyVzmaBlw0mFZS9QZx5fuNHEP54WC4xS6qE9Zcta32kpVZFcyOlLJ"
    "DzKuuNKsTOlAZtneWDPZP26DbnKGsb3H/51oVzSuIiTQxGEqfhWRBMw510RaOYsAZ17nJkpk56uo/Kv6WVlnX/36"
    "62v99+Tjq8oFlZx/9ffMERNQzdrU/HLxRm33WOX3QmbdFMR+wrONEZBHO9gIGVrWaaZRzQWPEnG02WgXvCB73Muu"
    "e90hWNTwKfOLRJjJQr4dcU4UmeDzsoxHrTRGdTHLCmPbUNjEQkVVhDbbpAgFbGozarkNpBVsLcEItifSqSWnMOFg"
    "EH8wYCPcW+4rSVAw7HPKKKsWKS1UyqhKn0qjHvcn8ztY+K0Gp8rjcfNdaCMMrUXCvQTIC2bKYPcR80VOy/MJSI8v"
    "cX7u8Ma9DQQBlV0RrXuLmS684UBcu79xXVKetTaioQ7B1khNBSMWQLa9Uo3FiGWO7c+GGTDFAqjHwPWrenYILtLi"
    "SC9f48uwVtKybFhR6eJPbdNKWGyOjStVdnyAoWulSzxcl1hIH46zPMMZ+WnqIMlzvqf+K+e6Zs/56WOT1DweJRgJ"
    "+Glv6qORA3gyIp65OA1dXyFkKZr9JXliWTlhiuaZKZRiNJ4NBpYojazAAS+9KWDbKP4V94clxW26FZYNj9UCN5HS"
    "nV5+ij0IG0IXn28dEnoAstBb8nrMLmmqczb3pZve6ZX32Z8p8zNZlPFvR10B6c2mV9JYHcz6YyRPWLOOitRF3sve"
    "yI4c64ieEuTLvwPYfVn7Tj2Jmtljk+HnshdlSTf7Uc/0ls/gZ0JP8rnsSf6yelLPVE80Q0qnBa3CkYwn8gvjib7P"
    "ZzhMSiWUVArkYSaYp8hc+9AMsw/N3ZoEYnlqjd7wCCjElmqfdH6GzBCyizgCmpBeJDtrFFeKuHYm01NTdayWazm6"
    "43a8o4UjbRLId+FTMin+PZ3rY868i/jWR4hk+rZrxItQcO3Obndd2Gk9mf4Xs5w+cnreNMtCMp1+NESMkth8VDQZ"
    "RBFktNlFEXSMM51CgQ9pDLZIjEAyY04OQVjURzSbvWdbAF/8a/djo/KLW/kdmMertYsvG3cvv489rN+9ffuH/Wj9"
    "7u3LfyVymVSGmYPXEqQy+G2Su74SloqcYJrUpbHcDs1Ev7B//wzj4o8z/atxeKj/bh/rP98bH6jb/c/KSSLQv9zh"
    "UP89Gus/B/qDi8LEZTnO/zGZtxC1ykp6nTSfIlmvH89dvIDMX2iVRU3GJgN8QiNxsqD8aKQ8Khvnk3JTQi9Cym15"
    "vQgpj0v9RQhBhhJnBEV43tZmbfNNt+5u9r3Nqrve36m5Va+70+96g/V1d6db3ei9GWxt9be6Xbe/M9iqd73N2s7G"
    "BvwLXxQIinhehnflX86aChtVKXH15Xw8D2RRciISezInsvwAerPs6SrVry6zLFMti+txMKMW2rddNakZmVPFfOTD"
    "MCM4n11OZazfXHvuKBAy7WqFi7ebI+uGsPK0ZNR7oj+fADEAMF9D32P4c0aFx41v45kC2WgxvZVpnwGDPHJMCgxv"
    "VDsleXgM0j9Tp2zmiq3uTG3nWlihSEuMAiVGa2drO8Ibsg2ILcCVChwumab0LtJQlQryHHTpVs/rpNrCgitIZPyB"
    "38PdcgjEGP71zQT1EHddVo5D1q7qvOjX7oSSgRsvnbPmYXOfttvwsY0mVFcfkjP2fuOE8gQ2P2A+p7P9H5tHDSNp"
    "YBjXIMvfqk5g6hpTcPa45xW334ctDzDFETtxez7mphbKG4bs7j13pC+L2Fg0v/bECA+a3IBvpj46/2LGez4hvLfh"
    "Ko50cOF26tiMANb0Ge9pMOuUfPiKwPs+megZ5IwM2wXyoKuurczsWenLbbAduddeMHF7Xubwzy91O/sx46I5FXt8"
    "xdqlmZcVz04vveMDoX2+xDuSoiXGKjxnKVsRYBXFIdG8orwXueY8HOt03J/3+L5MEnK21ivMtmA7TV1gyI7oB0Si"
    "r73elUuzRfdxGYZC1J5nq1z37Vmr8BITi0jq3T8+0Kk6mc7w9SbI5ZfSndzn+8Cp9x+OrJAYhp8LBIBRzx/6qvJp"
    "2L0ZL0H8wzgBkJtEqNULpdWL5r9bHada5n/r2+TqcXzeYQigh8edHykQqP1L8/RYR8sooombjm7zKdukp8c18owd"
    "qGLMSfizVq06mzs7PG5sn6SSYO8dh4EE6qaXSmFIV0gYOQ59fMx4bzS0eFrStkYjUPYkP4HHM7wolzBnRrn8dNrq"
    "4Nbp+clTs6/RAc4ROHsyREWn60ZtJbGew3xG0QowP9puaFStl+E/62Ur0ExSEkmm+/qA13jVGOAA/wF6jXQLer28"
    "Slw3eajinSVeCwGOVhQYE6WuIHwbvOUW1gi/Ae1dAtNbicMkEl2GiRtlpERkrFjghCzvG6lOkH0jmWzG+zbviUli"
    "ADHbSTEKavAwC1HGTXU+16JkzIZ+I6itnlh4jTumekyjkIFW3BUCW2gpMTgJVal3HY8R3rVh3soHQP1r0bnKRN9r"
    "OBS8v7tluH4tjum2MwWwGVNursaBZ545BbslQ3DPA8KtKKJVggZxA+nQNBXC9xLpgCQ6EcecqWRuWKgzulIZnyon"
    "4cMij7i6TtgnKDUwkVsOWdS77Zy3G+3G4c+/NA9epyLSbo39VSPGYId2zUFTGO2aA3LQ1Cd3OAl28JcNKqj41Tac"
    "Xn0drU7AKkCudphEOvaajIvtBDQwsMCoEyENB6RISK2UoSdy2d4DcUNlrk5sQOVc8Vw41ENDbfZMCWXsd2TiUXVF"
    "1Zzi9keeysj7jAv0JrA+yXMMcSgFwvcYPogDk5YiYQFhD+SgCWIKw4VQ0b0gtYxmIED1LWiVwZ3m3KknmAzz8Rgl"
    "DyUmdzKRczBQplavwK52FYFLmr8qHxUCUkh21ElzBnAEnrskQrOCqESIKimpNIyXRrkS2BVs3OvXTKKXAnDlYuBW"
    "NgGztoGU/HlDIFcasIHQKDuwAsJHJWtllrCJgi0oQqfAUMIR6SUaqbI48XRMjkenEcWRHYtsqsoovPDI4GFi7g6V"
    "fmvvtw4xFbeDGgOZi5QFzMGlkp02TZVA0MsCU93sLi7trRjxihGvGPGKEa8Y8YqsrRjxUzNi28iy4sUrXrzixSte"
    "vOLFK7K24sVPxovJedefOdcupwczrNQRF+a3SfclsUb17eQ7lGhDvGcg9xq+G5qJ+rbt6KonVDrgVHXhvfjp+32x"
    "sbWxrS/I8b450xMVb0kYhugGWrx7LVoD8Q5vFLicF924pl3uvLUEk8TL8Ld4smGn4Q0w3v7yEH3/Em8h+A5FpcUj"
    "twD8QpHasogOKblX8h28drdwZda016JJt51jcjjB1QIlRIemnmfWhUuYmEqpN+NLHnd06XECydCFZuiNLmdXazJV"
    "Ull70KTc3adsUnsMvd/Yc8MtmI/0HTVi3OtSCj2x7sje63yf5lWZvMCntI30UjG3/Dt26C++HDqTsrrytr2+cK67"
    "5lIT7tsWIUuvE8ZXG52K00K1xCVn3LtzUk59X29f45tXf9InATm1JGEeM3O316MLsEucTzYTTeKfr2WEG3IDR0WQ"
    "J1ehX4Xh3ScML9UZ/yK+8ZrO4QksEmCXEsy2QGBdavjbAiF1Uadga4USrlJd+s3G0jkLeF9iYFip+aF10GzvN5WX"
    "4IGjiE1qsGHORynu0lkfsccxHqr+KqSXM+m2DbjHNRY4CBARnIk+CfYiLR5LeVb1xhOfnFVmXkUnpUNKB9s4TpS/"
    "zMvueHQnOjzB3qBvzZSijh2gg12/D9NXomBYFqKUzuGJncAejfruFAT44QRkMm8mnd74EMUEo8DR/QSdYG7j7IUf"
    "61h1lTUgG2lQPjIcSws5l/x02jg5AdEn9Ck5PW+34UHz3/vNE8zt6zTed7hK9ym+Pmyct/d/NF7TC6dx9K71w/kx"
    "KBIXWS4ISRBuSHO5naMcaT3B8r8wvaNWu3GYN/ndvLVFN2M39gSDY9g11wBs9kmiZN7okGQkrl5j1BGX0/F8AnDZ"
    "9zBWn6B0V2j0QSF6/7SJGbYpOQqWY0fKsoaEYg3djNYU2VD5qpFi7Il0BKR+sI8yflXGPsq6Dyr3zkT1tTiRnsY0"
    "RXZll2z1tUXe1TJVFhdcbmR3UEjI2uE9ob/MPegV481hvBm8thAbUVu6IGNOUIeTmVN6FKBhZ6Dixh8arDsS/ZIR"
    "EaTWJlORqh3OpkNHQG7tuaG/Nvu6S/8rKdIO3fmod7Un/dYxByec5tDrr6AtG9pS4eZRZL30vAqLZVBYPFPC18qI"
    "cC9xzuASRQS5SPPFsbGA3GeOQdaZ4hmSUt1945mS0sLyv2oS8FX2llX2lr9E9pa8FFixEF6VGJeS6DmUjXkJWa+U"
    "VWu9Wn1AxudwomuROT9JvXvdLf8EpDMym42NHOhcDMXOe85zVRH/U3fERTAcviGRI4/nUwClro3cqjuMJYm8sTYh"
    "MUtPdOwiCTbtqSYWZo0NWrC8sbGBOQHwYQbX1PD3tI0pNhfrkPIrrMqJ01hZCXDHBav+clNOEt9N7/ErFZfT57tA"
    "mH8C8BbLPvDg/AAKEXO23EDY2OwTMbI4sqQg9LPOR7vxeVNIY05eiLQ0MVQ4z6LYrHPJoTAGVJn2sYcbjJthnU1K"
    "LKyTyLgyiwh884lFo6tJzhwaI5ePIAw/M25UJPemTVUshkDd6dvzZyuBGDUnEme+TDkk/cBhxOmto4rI4TuYuVN1"
    "LH2JntUSnlUdoyhXRK/gb7LfVzMSs2qpmDsq0JAdQ9w5LBXHdS+nHreQ1xHRNqMxXlrIUFg0B+lYXOMLC2iNFLUJ"
    "HDiOHpGjfkpJ63HFpdR1LCQwGXv4qFKTfRCPIz1FEKNAVY3CQpK5tAWEpGIIk51SLKMiUPqQKThcKBlRjJpkJ18r"
    "VqagGEV49J2oPXgnao+9Ew/Pj5VHM4sA/oJEtUiXD5bLn5fAHKeA1IF0/+HCo9hJau1M5fkir8Kpsax3HAafmxUy"
    "S9YNsU49xNmN/C5F6x81G2fnp80jzC3UaqNv3+H5WetDU1UUnfJlyv756WmsCRWfkAmEyEGL7vR1oV/NawWBBUzN"
    "vRyNAyzeqi42pZhPV/XRmHvMfaH5+gMqFfzlNIY0Pn1/rWElO34N2TFXJ4oJEYly1lL1ofrG9iNZZOPzXmlDK21o"
    "pQ39BbSh2GasNKKVRrTSiFYa0UojWmlEK41oJT8W1YiSBQkMJBz1uUYd7NbEc8Zd7UC1PO3IRAacJJDUhVSlCQaz"
    "gqKkyryt/SPyhFQodc22lrHEZSpSxjiGg5yclXJj4l+2O1rA2Oagv5IR9+BgomVETPfGgd30plyx0J0GGNigi87/"
    "J6DRZZZqs3Rg+j6kahvFPikk2BtrsMRduROwDvc6EPOA/eL414shRu6haxbeifddjA1/KRNyCnZhKyYMJ51FoWo3"
    "yduLethwjC+6typsh5YW5vcGpCb8BxCXdUblmQkGnIxk//uN9nG7td84dP7r7LhNzirGkRcqhV5Qv0g/3gX0jAi0"
    "WmP97W9/E2fwdOhVqOyk+KHZWcjrZfGSGwZ+Fduqh8rEMUyzdkBFlxuZY/Pm9MyqK4eAfAlIee1OBUVTBSyGtkFy"
    "KYvueDzESgtllYkC/vo/8/FMpy6H34jL8M9sDrOHf/vQJ08UA86CNUojT3avqQeyYiCFUplAnYFMjHsAtziylVE5"
    "Cbu/eeEtZVExGa4Yib6/PPfM2FiOoJND0SLVr6IZMR5f3kHQwDooKrOJkdE8rOHxEH+Z9OVEZRslbypX5aE/8Hq3"
    "PcxkogJQw2Cj5eTMVr3PximJNGL5pIz0QInZgezkLYm5W0pGfo3HSy7+iAlYpI+fIlHxTAKVf0YjeI03ialHxCuR"
    "nEvg1aMm+B+lTl3l3IinxKCQB2XEUKn7o4l/yNIRZtVfPGUBYRXoOr3xHC1IO0z/dLQRrNOhJBMABlOAauB2pBux"
    "YS1bFVDw5Dg/NhsHGOSp4oCy0gXp0yaGZoQ7FcpNc5/sM7K0HjBjhxODsBqTneYmIf4vKeotktNCTs9nvVeepaMi"
    "O8KXFwtmxCmX0GyEu5TSqQ7eSjmJ4tnt9KGqP5ikOIetdnN1oE9+oEmncI/DbB9rS6bzHmPjJc6uTvTJTzT1KO5x"
    "rBbTf75HmbXP8Pba/exfz69Lu5jDqHTtj/gXMMq7+wBBzqkuACBLg4GIsFb03LUMuDSWK8mMXhmOlc5TsuHjqHV2"
    "1Ojs//itorjcC71utZ5lc2MjEah95kvgyKvzfszzXpxZp571Ehh2BuPJPlhF5JsHi55qab9ac/Zr68770+N2x2m2"
    "D5zj9uHPpa9x0gxhy2XSqcf5mIw6A2dPTptnzXbnEVD1T8qyH47jC7DuJGiQE3gq/s2DysHky8ej5xnnsAQYyTz0"
    "GIh8q3xfpV+OQcwTcP8VtHxLUkMqpHxDssMyYGIhoWO5cPJ0MkcqMEQlj0fk9OWHnN5iZ1FeUEK4YIcrN+AlNv/n"
    "vHGYAv4yk2cG9BdJfG7DeTpowvj7MH7zsPVDi7NqTWDafo97Sd0A8fatyNiBFNCDmfB9zXk7awfuzS8kp1C9L8wi"
    "sql6sY35X1kbIxrtA3aKxCzt/kh8eVGvVssb1Y2X5Rfw3zL8enlXuieFv8MMobAVTj2UwKHTx97lSO9fZZcB/GAa"
    "tJ0Zuw2t1Awfsp3Qh1pwPaWWzgO2M9L719pOmEaB7VQzvM923oU00KH0K4476jsq/YoTpl+RJHBZCpBmTQ9JjZWQ"
    "K2/xZH2xrHjqHj50CkjIKpidJTqa1jo9E1y8v3DHhjD/64T6LBaNT9/qcvahZXLPbASwaoZkOY2kuk5GTiHH23C9"
    "jjgWO+2ccCxsnx/1UeC0C7nWxWHNlHY2djYNaadaxHMuBVQKTabYiRTqyqSdmTFAGWNa0BJPNpYSxZOQcKxIGE8E"
    "n3O7DAp0+eTp0DIclxbwPb2fCF9Oi78yIp0yuUHMwzNkDBnqTLLGm2Y1KbYDD4/oypACzGUakn45Ih2UU+5Ei60g"
    "mZEUwtwMlpIdLYdAfPFlPRmAM1h7xrmbjmoLHeE9lckCMJzFwXMw/cW/dj82Kr+4ld9hp16tXXzZuHv5fexh/e7t"
    "2z/sR+t3b1/+6+/PPr4uxb0LWxuFoDxRq4t95SFGGlWAs13nEhoV2FMVaIduahvJBex45jf+sI++obJ+D8vSJdts"
    "YXQrZxWIdGkaS/9QJQGj6t+e0HBIU1KufbI74c+o+EB0XO2eKuetR88Q05OH94xKVsnl/HTfyXNZsycmJXkqyJCV"
    "THGXI/3KqDqsoYqLmsYaar30AU9oPqJGlnSH50HL4KhKrF6BbUT6nHQBnnKJvslr33PRRxE9zmUhRISHit6cAYpS"
    "aou6U3cE/JPXO/QBStA7fZxf2xOLWYT6krj2g2t3BkNSkRiZRDKELj2MWYAvLNPIh6hd1Wl7eh78Z45HoTBr5l6K"
    "9vnhIY3BRdHkedoigIrBVHhVWAggvIGZA06OMeoAiRNCUFJNGx5SqCHhUN1ez5OhpRmEkAok6Bo2snSNjJpVEyZ6"
    "gtSgO57DUs2iZSRZc9nMZEZG9IeAHeN3EeC4VE9gTksw09LREwyzsvol9A9NJvMZkZ5wKXqgiLMsrAatPl3PLLQi"
    "uKqPCKv6ZGpkhBQKv/U26LJtVImuQpXoKlSJLr1onSJAMEplPKiQ+ZWBBciiP9PYh52HResMFMsSxHib0kkUYyZ7"
    "D8+AbRNjCSawek8hHAUewL704SjhX95pgdHCsvggnl8FfvoDnz7XXsgKY+VhZtJTZCuqRusitBK/kzSWPi6leybD"
    "1FAyCYzamwnMS9aMwnKqvnLC5vpyIXGgooU8C3UOhkO2Jg96jfEifms8e7JAylp1gVWAL6UqqKJE7ui2sBd63F1e"
    "YSVPQpXhi9KLWAU+d3jj3gZCZt4NilTk85LWYNbnM4KUsupAfPPBSjmLiwUtFdPeHyGZ78p+9gzsZzkxWzmWgPgs"
    "EjifLPLmEDGVoUqOIprSRk15CDA4VwezkTUWg54Cq56LURPYMGtrFSWFBxCnno/cT4BRqFaVhaorUaYyqcBi+OmU"
    "eYoS0Tj5RYYlQ97D3c/34q6s1xdRWM21afYo2aFkg+GY0Rq2hnyQM3sZwSk7zujRKl2+iDHeWGKG8cVcbv5kJNsl"
    "1QHhJJxJCNcByeDEc+Xuw/A86mnz7OS4fdZ03h0e7//3Y5xv6sqM1Sfbl55i4caIpufMQxedtCBjvSkw77xvHB6+"
    "a9C+33vxI5mrBjroeX1OHKPRXvZEOyJlqWCpSHwhI2SnDmNmGLL5KPKxH6jDjgjCe3axRlDHpeDIErzSNZDQTSmp"
    "z4zYJROTsGSSFcVf6lZrVa+27Xm1vru53l1/0+29qbou/Lvp7dTd7vrm5s56t765U9uorler3a2d2puNar3ac9/U"
    "qhtbVXOIT7C08TSIjFCt9rpb3k7X21pfH/S8rTfbbq+6U+uvv+lX1zfXB4Odjb631fc2tzcHg61ufbv3plfrb1Q3"
    "6m8G3fXtrpGkX+3zxwJMH5WL8fCTh2WxfRAy0IbE9ZYTZWWtO6ZyfatUuPGBiBZNCmV+zaUkT5pFgyeNikxsOYMp"
    "Jo++B9LhfITI00/jZcDDAtieJKYW6g7EKzQH8EcAVygScOSo4vuoF+Z7z2Rqv5yWI5vHHzUO3x+fHpERW1mK4zfY"
    "Q2/04t1L9LFYF8enpI6QguuHFdern9eBWcF/dwoGsmQaetlrRc+SNGtpS1azLPFPc5rv8KocJxL+p7Br7uLTiYgP"
    "el4Md7IsPVk40E7xrpS0pW/Xy1R21Sxiz8YO+NIH/R+33ZYECl+0Z66oFPZfiq0MVbvj985po/1Dc9krq1ZrADY7"
    "O4gxW7jKnZ3HgyAMsceAZ0D0zy7SAZmSwHrG5UJDl5NWuyM9QlBBkXqJuiUotQ8aTHBdSnyj/OjE9TxQ/EMuUBqx"
    "ZIFnTW+gU20jUeyDp4zG2fCR3nXpSqOep4t8qavCyIDDxjsQlw6iUJu0xKODxo25RLSdk9WAQ9THwsQaewmSq8fW"
    "EGl7jzXUY2uopp7R0X/sBdSTF6DuGNAKoI6xvsCi6lmLInf/zBUBoC9yKsed3zbNRbHNka2NljFR8xll6VFWGlpo"
    "xHpmr3QHeUx8oYySDzm9zk/HzrufO82z9BN7ay3uZhwiCi4keR0GhqUtqZ6IUyA9PXBF74/PT/OWdHPUeGstawBC"
    "1KOtq7owTBZaWPu4fdD6odVxiHKnLe63bQvDmMqDnIWi8jEs7DdPGl5DYJS2bLSmTVj4iy+TbAZKiX6a9Z63W2Qt"
    "pUWnHWbdPfxl3L6+NNd8PvKJBTJv45mPZ3wXYLI9dVv7vJYNx8zMPguG1272G+aS0cTBK3s4AN+LVeRT1dPmD62z"
    "ThOL3tPKnMPmv5tHVjxGEbYuF0BcvevpmyqZN1Yzc94GXDdeFFiX8Y96lBd4Ya8VT4cvr5zw8goTuHT9ft8b2f7z"
    "C1laFzGoWkbT7DC8iOKIsqZKaqW3X0qTBEDw+aiPjgGn7/fFxtbGtryF3IONR5s3Gtrc4eTK7Xoz0rgmQ7dHRoh+"
    "n3Uvmc5XBQMYb6aku0ifCnnGN1fjQJ1wBWjWqAIIPJKoPRiAmge4ez2Z3crUbVSNkFKUBvK5EueURowq7O5y9ePw"
    "RB0SOjm7Vta9bqrqnFUemZZWAeCqkL7nApkT5533FXUmQsOH/JS8S3ZTYEy8FcPxjTdFZUMYzi64YoVhyB35a7mt"
    "WDMT/Rx4haHzgzTQlNkLopziBiFvLumCbgDKszQE6KvZUtg73qmMBwyggQWw1YgKWkMtBZNbaYUlRXPSaluKzqiZ"
    "oqWJc7olWgDRIvOiMEmfF7Sf0uyGEJS5XOJJ7CnvTDDFmgxJodts7ekT4WGYn9BQ2+zLy2sP74X0QfoBXq6BMvT5"
    "ygXyiYfAQUbiS/WuLGjzylqjLUcUv4E/xcrjxsTMocaDXWEaIxChtSlCcyeWivf4JvnGh815Z845vjoYFzAQLTpI"
    "elFtTdq8AFRdLmc/8aauvHLmdMaE2UtJEPy7Nx3jMq/xHlgOUzBDXmyaOl3ea8wmOFxKkl9jTCZ3uuw83y/Ss5ms"
    "fC9/oWecvmbEDNCcRTF8oHulG0pya7t0yE/I/x1eX7vT3+yS6eOJ8j3uo2V0GMQzKaYcYp7/ujWbjMIF2p0xsqwi"
    "n6TMOZJl1xBDAOd6Ux9rMABnqxgnKt2A9oBidn0AMnSv6BIT/c27DUQoNSySfdc8wyw3/s6+0z4zPqDH2fUI0g5F"
    "gkhsp3KBoUhpiQKQUMj7NhH2c/xKAVCfoS96yo4s4Ij+cDdshcJ5FSwMXH/WLraKVptGc+SX/jVILbg6AScoOI3m"
    "GPAUxLQ4AQ/PKErLy6WT47MOX4W2fml0WsdtR2lE/8WlK7SjqcIawbhC8y0LTagEEioWqMJnei60JzhVvSCcPwvA"
    "QH6u/R76JzGn0m62xkDhlWJvPGXvM7pOnI80DgtVUEZ6JfmwL0wSH1jOIhFDv/3MyCmrinkZFSB0D8iL/I1w/hzn"
    "myzSh1Gf46Hfu32ashBDG5zCIQVncX3U6hC8sLWE9S2zJoQcTkF1qC+y0cC3Hkrg0L/t9NrhtwAZjlLJOS5YFtXg"
    "i6ogzN4sFWkzpfd8NtjWWb4BwhBmFJwqToBwaXxSpNYEX/1jjnd8ejkdzye8uviGZ5S6S+yjiESZuGdFZCN78wsV"
    "EEg6iPShkOVvbdjf6cPP4f2J4JIgI5ogUGS3ip3zU4nj1iTj0ngCpGZHbVoQF4HweJFAE0HzqgPayJzW10OKpkTQ"
    "t9iEYjgfl7CTiEARSCkoT8dX/oSidFI9jgK7Zu5HAkF71rK2zH/nWLFeZCDi2ArVbVmwC48kDmWyPhoLLwuFJST3"
    "lUVIGcxmeyK6QW+Vh4KaSSTu7B5zUVFF9jiy372UmYHgfYv3F/JuqfEOJ0M9nbdPm40DjE3VQnr+fNZSRiHvSHOn"
    "EnYEQ2KbMNnzRoe8jdwuIeWacp/iuAY/CM3r0Je6WRm43Sn5l/TDCXoP1QbyhY9vXjUotMSYnpBNqO+vIvzVpb0c"
    "1SOFS4Sck66L5ssqzaJ0jvX6EorP2epFuJCnVC7k/bs+X8UDKVh0fANvmLXGj1inFYuDbGCCj0IMAsZwkSH4hY+6"
    "LodrySvA9FI/4ykjRvgTPpkPUf2budNLb+awCBn+JiCmqj907d73Blg+6hO6hg5c+NJRReWih5Fu+87cn+dil05Z"
    "aIFyuTZoFJOPouAU1yJ0H/kTSIIgzGIFCBQ4kTwNpoE31m9I/EuBe80hr58lD3K1PS4NkK01OIetsw7fjAGGOjQX"
    "XQ9mCXpBMhwWUgsyl6X3MU9zzNpMGbSjZiqHM80kH81lXvCWL7SlMeJQbFsTaEpSghybFEUymZwdH34goQylQv1j"
    "/7jdOW0ctPZZYMtK4pE5rXS1K4X2PRPNejHlzuBpT6fbJVH8QkYam3VYS8M1AVj7Wg+TK8QTnLqjYDKezsJHtAXB"
    "vEtlrIJAx7gUBJMYC4tO1OKCxTAiwjgzupScdNFuQwb8nJXgiDzHtz5l0jPI1yOivZjki6bRn0+GpHORR1UQsD6M"
    "TiJwwFrbyCK9Sh8rTjZf6zbcS+i04Y9iClRZuk2RzqQ0RZpdilBmZbPBfYh7I03CZC99wXPAocknC/mp5KQwIO0f"
    "HYv24pLOW3JWthHCVJdRRcQjIF8sTAqgx0qQEWObaL8GEsl7Z2/knqonZ8U6nUpSU6nXBHfOaG/l4OHVkQvRlY+g"
    "SiCGanro9kjfkq7+HxKCEuRTfE3bxk5zchdwUphgUqTQftiOIJC+w8aAuvO9MIGGcu7RkqwAZRhw2A+uUGnA8QmX"
    "BRkobsk9SHE3vlgsi9ikZe9lQeaJ2VoY3LWmssYoQC8LS81DDykpfwopf5aTcYgRiA98jU0tAAyA0L97o4rkWipu"
    "7DFNHH8ua0aG4SJZknw8u8VKkTT1q2JWjYh4BKwSABnECThwWD1qKcv2nmPWRwANIByO/sDKs9KXdi26nGVaNvSl"
    "elaekXKJiq5KOxr9bRnL+EkkzYZsreJpzfbRGNtgBj/1F/KX9YV6pr6gEVXgbNij8UR+YTwBuPH7GGePjq+lONQ8"
    "ar5Ze4IF9PZwh4vcFpk7XuTyNXpmRW5Ro3taYBHm0RdZhg0IRRYSB6ciS8k66sJmgcdNM2uAYo7SEIXbZ+DVF6NQ"
    "T+nOZ+N1Aag0yUuhq1iL2BSByjjJyofK56XiPUQ0XOXfMgTHLFLzCFm3/mpsOkckTCREBr0GDJiMA3/hiy6MQ+n3"
    "0cAAaiaFK8pgsiECmU5Cpz1X94TRAemL/mcK6pPqr8zqg+DI9khpZSw9kUCXlYxNuQDqbDYxsIq9CTWF2DbHE5yp"
    "6DV21AyhSb830xE6Kv+gjTe6MacqTGll93TtucGc99JRbsDh7GQ/5JfpXk49bhdqRUjvpFrjmEmFI5UztClKh3wq"
    "p9GkvcmTMPkoCgmYhdeaI11k7lKCB1xCoYJ8pm3uTK60k7Bt1sYmSFPJh1VANMg5pIVkwzgS3GOpGTccjyuBPrnM"
    "mLDae5QjsClQXkRHGt3K7z9J14uJcYyJ2YSukPhYnBQu1F0GsSzUz8Nl9Qwim+1amkOfE2T2FLKcSwSeW/p8Mzev"
    "QZy1EXwMHffHN2ir8txrq4naHR3q7TTajcOff4E/VIbD0G2wOwaR2R6OU2NTLmAFMxzYreyHcLLN09Pzk05ijy4b"
    "wcOYG6O5DhSXEUJGXHp1Y22/ugn/24pNJzKHMjsWpk2xLI6ajbPz0+YR+0li0YzD87PWh2ZZIKTsdxzLdRAzV+it"
    "KosUNvKWYFPtTSKQvSW4wmIdzQ+csvGUepR/ULFIJ7wQ587CQzpvq2PSDpRpc+FriMy54HQfaOs3eM2fSX9LUtdy"
    "BIDH1thWcvgTy+E5+mOaUGIIXNfuyB/AH8t0lNzY2VqCp2R0BbEHS71YyAN7PRw3wXIk0sA5ns8AgtRdDqbV+M3D"
    "VmEKGRvAONED3p96GBU4GI7dmXNFn9oNMfEETs+h2/rstvoSzJ1FG7JvcGTUUeg1HB/GeBnpd2SiL0D9FJ8aj7xR"
    "nx/wJqiTi9CoyLlmxH0V3Y4cxaDyr+pnpRi8+vXX1/rvycdXlQuqAfUquWJesZN7muFTz3h5wxswnzNIOESq5pUB"
    "bsWyKaQA8gIfx8G54MePXPDQphmmrlIt13KUlW2T3EuEy1iFvlV69EuhdCxeyBChyUiRRSyovWvW8YQ3Pooz5Gn7"
    "IQeJOylGWEhejbbqH4zF8h/A8eqrl39P7/meZ/Y83fw0cgqJnIGovn4NSGmx9bKIITErNi9MKle2EPMl5dsirYFd"
    "26jHAWgEox5V4/rNY5828jAMylTbSXrG4WbMYcVlAd9Nbx1v6F/6sLdSP5M+Vc4NDIRnQJFi/3PePP1Zl0YvmyW7"
    "VEMWFlWCelnuS1apYsbJBdJQs6nIrO5j6VQWn7i1Q8akw0JXhg4UoCReoUGk5oSePDMUDUOI5Spd6CHmTXvk9AWg"
    "NOy6vd/KUlMyzp6manooJ2qB99P1DEWrwloYKmda4wsMPS8GGLC316CR9RbT9iKaXJxnZCl0KZLSfbW5lTT7RNJs"
    "QYXN4kMG7wN1cfTtamo4e+tHYQ2t9L51AHSu8zPavQ7PD5oHdI0ZqWUPvbnXwFCmoSJHeU9kzaHprENHO+rTv+St"
    "94nAewBroZ3Aaaiy7uZ0VAOddTQ+H+R2+unxUavTedRJLj4zNYf71ZH/s1OEpeB99GzLWUelBgOEMv8OqbnhFBrW"
    "64gElhi2q3hoSTEV2qYuK+X6r6FcZ9EQU0mKE7oEMldIU3ocdf7eGrlCtWKpeaLYWEhDfX5qf4zZhCHKsgAS9FWQ"
    "AZUX56a5cMFxnn8u+0SUij4b4wZJXN+WYSODqRXa1iUaRlIYcaFpxTn7t2lNQS23MhtXwuTWwZU/YQVYQp3QF0yW"
    "7UGWgUuxPahKYLKPiuojYoNIQFVZRChuo1Ailjg/PRQqajcsWEmhfOq9SsKhz3gthENVltud6oL0fSXkitdVEZbB"
    "1qUxpXKlZ6CsBoE3Cy1Pf11TRpRerswYK6WlyL1fETuKZnkclQKw7fxnPJ9K0Wy5QXR8908R2T00wyLOyMENkLxH"
    "IB0vZM1ez5NE0cWnbyerXbxCttubKdw1nWATqm/bj5CuT/uRXFf2jqS7I/fiOekT45KwMz3BtHz1i/hSxpaV8JEh"
    "jmDzfME1d2OKpS9dNFX9/VyloxCU85GS9Bfwr6ZTy3Wpfux4txS4Kyb7fwVnZYt0PJVO8OeJCYuC8TfvR5iwoASB"
    "LQ3MH8GP8FmzllxpI4ZOpp/6Q6O1lnyHYwsXyuVxLWv6wdPH7K9cS1chXqsQr1WI11cM8cqiiKtYr1Ws1yrWaxXr"
    "tYr1WsV6rWK9VgL508d65UonyFpG7iS4GltlY5dciRU1UU4oh8nkwhp+4QwelEwuviJDNy1/jZlpBdoCnWc4UYbX"
    "7IktodaAGsW6A1HPuNKX/ilz8SBGapJiJuSxzf+KuusHfEkHnCCe6nHopr2J70eq0ptqZE9TtFInVCRvV9qUC31r"
    "b02xElLmqeSoWdg2X8+Kn30h838EHgo5cIUgU2iIohpgDDYW0PtSsqelTikTDgud4Mpcr7L7xgDv20/xm7SkmEyY"
    "DUQPSPT7vKl4nqiUjMaIMZxkuIvJwkNnkal7s9Q6QtXqEoIu1FLWUte0TDYvB6WjZV8b40Eog5sPTZDAclNOd3wt"
    "SxIiyPSCTyDSuijkSm3EBdjljHvyygZ0CA+Ip/Vq5N0AtqmSVgiDIcTSk4RP5TP70543HEpvoMBuTm80ZKftdrpj"
    "vb0wi/ecHZ+f7jedd87+2QfnQ22zGKuJTMrssbadQ/jZEJi24KRSOy/+tfuxUfnFrfwO/P/V2sWXjbuX38ce1u/e"
    "vv3DfrR+9/blv/5eKu4jHD9Va7MO36PB6BT+KbxLifCT5yT64PUmTuUZzSFnd8ul5vECe2zi3KMKY6l0rbhMVgRZ"
    "i4laNr1LRuJ3Pzv7x+2DFtacX2iCCysaKYS12PY/1FYeI97fmOE6ArSmr7Ji2dXXr+s7OyzewcCX7gS1dV3EgmoA"
    "oCTZp+KkTGUEElRZpURoyEPqr1wfpQeybA7io/YXJpsZS6XJlBlmNwXxd+iNLmFKUjq2+QAJoHQkU6zBoiaIDXgP"
    "RdcboL3B2sYH2l8T2X6UKnzzwnjRVcbl8yIE6P5i+l9UCssT/zMZh8kWwrdhjdM/gyZgrBpGW6YekO5xjwtwqg45"
    "2qufNf1zMvXHUzjoT97QcR1um/y4ph8bq0KaISslR77qaoP8yAOKDvojEG85gBN42EeQ9LJmvEzKJpDimn9fp3z1"
    "QOX70GPryjdUboYBPtyf9Lc1UzeJEZhklDAK+6ZHBT9qVGp+dKjtuaDdkXOyPKV8lQECGLmpYjVL1fRqiAfN/dZR"
    "4zCxt9pDess66EJyXBYsFLO7ZmFVnr+KBjUbFeM24SREL9q5/gxQeh4U7L62pO67xXymkolRqrdUUkCsBTKxeNjk"
    "ENLsbyJkptCXmXHYKQi3qGqXRIsWMbkbLKZA6GetssMR+N8nx3xaPOox+luA6i6i9nXvp8J+/YDfZ6YHGqSLfYz8"
    "wYD/OET0rTTYTYlVw7Pmaat55shilnukaGB7s4wmjB9tNvJ8rM9ITfXfCc3WXK4JCauFhx8cVWS4XJJOCRzbqd1u"
    "RuMReRipMFyV7MsIj7WRXrwVNs0RFRElKeKfoiq3Cb2jrAHRHwkTkrWaB2vG32WcelnwhbbkSIJ4USB9oNQMaZA1"
    "GJudiigGGFUzqY31ZfAvIqHMSMYVM7FoMeY0EPoSgBbvXcLxU4nJng/QIC6n7vW1yyVJw5aYtuAStlzq+H04BvZP"
    "eYDOa8lE37xuG11NQR02mYrdX5VdKRLfgCJRVPFOZesmD1N4/0S692b9SVRvvaqvp3krpzL5MzFj5MOB0wY4R5Lh"
    "YlpowtH/STXQ5M3PEaDSTixBiTBOegGNzQSPpGjXJ5D8E0DgHvc6OYD0lxCqU1Ex/di0GeLP4wL0VxXKcjBgGQLZ"
    "M+UvRYWTNMqTSFeW7Br05ELJyitouV5B5k4/D4+g9ZVD0Moh6M/lEGSRswcIjUtzBGr+W+ZSXTkBfdtOQJu1lQ/Q"
    "ygfokXyA0ujOyv9nSf4/MT5hcgH5R5/mMeoBiLjLztyztRT3H3v+a3kLfEKbZDTpZoJ9OIS8+KnF3vXZ6p/0kXlf"
    "oBrHn3Udlfcz3qn5rOvYRXrM1mlvYOIc8ZtYjER/XqBR2FOKuhzrLLtd2F+Snh3rLKNR10m4kjDgLO1d+J2+t4h9"
    "FX3TddIMC/rTtAZhqmKHOBlf7ihwMJ/x0RsP+Fw5Gtx4bJ6WO+pdjafm28j2xxuEW5rwyrq/Md6o1Ulzi/EG2bI7"
    "HEYQW99XXfsBXa5SWHmQjHc5dvmk1wpRIqUlrCl8HSN+dFdzsxpZc1afZeSUSgKKxx4kC8Qee6w00HrscZIQ8dHH"
    "sKFdGyzS+7S+KG6NeHCxhky0XWxbVFcZ7mVpeLlQxrAoVXrsw0sljI890KImhjThaXFrQ1zWKZD1LZtiF8qIVUiW"
    "KHSzly/f3Kube94zpoqJi2xrEqNbaFcL3OvGEoUVvtZNk0LTZxhb4OLupeki3iIfJ19nxnOmZdUEicnq2Vm0Fyjq"
    "UUxwXgAM+4+DFP3HQYr+k4Bl/95g2b8/WPYfApb9RwTL/jLB0lZvixO0BNH8abImxlSqx+bbEQXtcbt/bvkUR5wp"
    "DIZyAzaJwiwwZiy8qRZndOLindCSQSB603EQwDs2fppiqqhiJsaRqMXUQrJ0B+MpjoZWaNg+NBcP3amraid77ExL"
    "JvHryeyWfJizhNi3p01MZNg6pCpyWA1IWbzE9TyYia4nwhbKEv1hI13XxR1EX+PGyclha7/x7rDJTtJYKJMdtdFO"
    "Jq32khzRnOkdd6YrI+udk7RWsMzJX7u9njfhvSCH4Qr7HcD5uZejMZxhD9cwnPmToR+W/EFbdK1crVbV/8JhDvQw"
    "xBkqxBnKQjGcCjGcsvTXZpqvJ8TXB3BYKLPOCGIGw/F4+oLrsUhZeRSs1bydl9/Df/YEbrZegzcZ9654XYanNB4J"
    "fSn09lIKM8yHqeYa2p8BtMOV0BXFCH3BkT4ImU99xg7Y8ACzferWYRlsBT1Df/QbdA6blWVKyJR5qcK1dHnHQtHo"
    "V45w1fV67jzwhEYen6th82wq7yq6s0p/CrMd5Zg7zHEQ3BewSuZ2EjdfEo7HMVqnCRXuZOK5CBES3mY3fg+gSOK4"
    "iOH4o3lQRdXdP5dHVcLqEtJtpmnQj+ZTtbKPr+zjK/v4n9g+XvSiMsvalKADfXsV4tUK1mJg/fXCJNJKAj6TWoBJ"
    "BHCJVQKTDmZVJ/zPXyf8cap251i/llLy+8H3MQ+oSb2MMs5RDFz4riERd7+dKJZku9oDijg/L/MOF0c2i0YQragA"
    "rbAsEUpxpDhmLqaMWhFAuy52LKeJQ6LmrS0fcRV8pRI+pkqYhWfLCLRZSSghdS4mStvEM2Yg//ac++KCs1Yynp/Y"
    "HFP90xTQv7J8naQkPli6jt0+PalwvazRi8nWjzn6VxGtUy51C0nWmd/e7zJ5qXfIDxbas+6esysoLjfT1qJCPpGB"
    "e4j42Re9KwH/udTDM2791uxLvzV934eiv8rbhJK/3BN92+NSHT1/Kib+aERpleyac6Q07IXyv5WvCfWN2dXU81Y6"
    "wFJ0gCRn6KfUAFbC1kNVhZAExwqAyhpfy9AXVJ0vXVVS5UfDi/nPGFzoz9AIoKhXX9fKfEANMGNxRauSJdQhCx40"
    "ibAbUHWMWjL/fF7FxnUJQ1WEUBcCjFQj1AUF1fnQHshjw74xSvRyPMUbqavZbOLEPoB1B57+RdF46geWuQndlsYT"
    "mZQsrJQ49b2ASuPoziiRF5EA+7qLcU9RB24WLluGiJp5wDT6SUpiv9Kr8INg7oV3aHpGMl4v0iHwKnUvbT90u/Fn"
    "arLWQ8WKKXySw3Vjr4wkKITduoXaDIDO0YwuLwMEbj+4ojqMmYUfC1WbzC4OmVGD0i6znrS5SSENCQ2LRzJEADFH"
    "pIuBbUywy6pEnVodPhO7Cgm1C5agTu0mDW1z9iUD3ZMClmJYVihOP44ixT/LwIrcGnsaVlJRb8EubJQuvgibZhT/"
    "rhBoW6QhRX9PIILFZhHjMTmf1YwSksnUOrvEOw+bxGlydiGZOcWDxpJIZwH922BlOROhljZTTAgpS6XUOb1n0vik"
    "WpZ6GnkZv7NnnMKY8zpNY+eJKVdSoTMFSgxpKEcZh5b5hT+llJXXFbTK7aqoHSVJXF/AnBJKK9YIVz7aCmQq2J4X"
    "2L2lFF+NCWN5NpK48Bbv88EGm3SJo5jFKEugyVtgtjCUYBiy5duc7uPicKxHQ5bO6cySup+1fclMNK7ol+CtFuqY"
    "ybjifYZOMWv2lC0wWtPcPz46OWx2mgdCSl9CSm4oOo7z+gLQap6enp/A985Z87C5D3/s0QW0UYkcep4idAvcw/2O"
    "g977zQ+Nw/MGftY+bus5pKgS6AU9A0gPrMTqFJ5Agke4GrIYwcCjwAvB/NqdTMhuBEM1dUZ1TmdOQQxrUqBYG40r"
    "zNpFd4qmNC9I1obwlEgxno+GXhCIk8bpGS+leXTS+ZnsUQCM01tBHwlJsuXZk6JLzvxD2MNrr1/hVv3pmCaaqXvI"
    "xOdB+jrVJmkVQxDSiRHOSATzCYYrBDALf4qKPdoDg6vxsC+MQbV9QR4ZnlCj03rXOmx1fnYOWmeNH06bzaNmu4Ng"
    "AERRWPgt695zAIjsonF+0Oo4rTbGehyen7U+NEV3Dosee+gYj44MN1NQaSIGTU62/0BzpaXnRxSTb95ambO4uLEy"
    "nQnc31q5MqmsTCpf3aSSZ+NNFQ+joo11WEsx+FpW1UU8RLJMufa0l2pBzaA5CkWMIuH0exbAI/+SjpzQjgQr4y3C"
    "G2f5crAeQ7Tut27HJmcUxVM6pFd5vVGj8HGYSthEIfUzcRx6kzMMtYlii3rOTEx5Jxlv/ZHDlMHEF6YSIQ7YFCXV"
    "eHgPM1zW5PLjupOXnBF6HNpWUra6iMEm8YSSR1gglDr/iIusK+s4C0wiw96TWsXNwJVCftNZKFrIKDHzr5HUX0+y"
    "D6AYsueaEWUZtkQMzvjYqLSXSj8KrZa/zl5pPhUqtMxHtsrcx5RiUZoF7CmPZK5IJXQFbBZ/nloGi7DcP7VOk7DY"
    "NB0nFXIeoOisJJ+vJfksIt7HSZb2Nbt2R/5gyQGTy0rqyrCnVrBmL6iwwF+SdQSdn1rtg+Of8AlveniLF/EbklbT"
    "6IdxP0qkx0m+kvhcMjOYCJbZoIAWRLlkFyU4bEzogXOJenfSCSFlx2qDPzvNw9YPrXeHzQLLUG6rPMuUNUZ6TZn1"
    "X9GBKu1AUOy9u3uSgAJJcQq4umlLxMoDLj/cID8Ftt3aJjyrwIVV4MJfMnAhmYOYKlWEmZSjHLSQIvVXj4+IiDmL"
    "p1stQNMWKa7ypwi4UJz0seIuspjCN6eoKzke8+zpz0yCqkvDjMK8b3aSvS+Am3fk1K2/y0wPJslbIOYjHzAJ+pM5"
    "1AL32sPyLRVQB9TdvEwRx5Hf8A2HfeP+7kaCWxfCgseeRHpBjXJJZuMbeFNv1FOFzK/cT144HhsmfvNuaaTFkgzK"
    "KHn8EM0KGFljVPOhniucUm82NkwwOlqe0tSp3Hn2kEJfihFdFUb6IzlWwE4GtCEpnezJBHBcmAd2QLhDNKWAHo2X"
    "4frazOw9LgcjWFO0v6wXxLq6HgpG5XZlOEc0wbCVCV0p4NXrKqcaxMR05BpwgxFF04rcL53YCRFsPMdq8QFMPRjc"
    "iqr4x9t4nfh/RGvJQ6P65vpGtQ5o9GZnJ+0S/ytFFlnoPB8F/iVuynnnfWWbc+fZ+Ax0Ffal9/yCj9LJ7lMGH60U"
    "s2egmOVYyBLkKOS72gFI1yNj3W0urUXwFPbjGpaFNBu63D8/PW22O867486PDCzyPVCuaBvyuJoK9bPdbHV+bJ6i"
    "G8ZI7ZbR2vQOYhf50RidBIDp01TajaPmgXNMXezWqtVy6fhD89Q5bx/gg53tcun8xAG5ul3a3azeGVwdxrCXIV6J"
    "cAbwI74I8VYYw5eQ9NygXSPa0VqkGSEzvJTawMfS/mGzcUo5P2HG30e+/udbsbP5vd2DBwKSeN9oHeqPXthfvQqn"
    "/hLIbnIH1l5emBsOQDzwRyySJO+9ZBeYBBYIHWa+9fteorMfM8rRre22VYHvx9hFgMlgw6g1HUMH05lMaDdfZJzL"
    "y8jmIrDqe0by6pnaMOsOAafcqeGeAyP8MEX3IICCspAJfKvVyuZOOYysGw8GgTcTU3d06Yn/93/r67v42h/NtjZI"
    "7AACcYN+bl2/3/c0jZr6pEqWZHZgMXJHYzlA+J4kAZnu8BqdmzANL3xEsxfIdMoqvTBt5QDXgrwB6CkyuuHtngC2"
    "fjWrTFzjLQgtOyTwwhqADY1mZfzRhX2ayhxC9GCKfJs9CoFwg5iGdyPM6Hh1oCgb82Z7NexgEN7nwheYS7ejfr9m"
    "j8u+D2RoptIuuzeUL3kAjFfMfsczgV2bYe8wSRdhgCgqviN65P/uyZckeKj2QInG88srcXI7u4JFosckzgNnRU8c"
    "/WS3xEPKkzNyYXdv9X4qcACRD6D4Gr7sqelgkymIXjKvNs1FlUgU7ifg5BTleO1jGm3eGzMC+/sa53XGO4fRpYNe"
    "nKQ3/Az/Vzk6qhwciB9/3D062j07+/i6VtmB7br0Z8EFDoRGgLPjyvZWVdaR/CX2RMoaanX/7/9SZziePjtaIAGT"
    "CM9OvpawZr/mnnEuCoigBU+rhPcFJC1xQb2Ze0nUlowBu6X/OjtugwQ4HnquBmd1kw7UUF38YHxqRYGjngPvEBk+"
    "OiHwYRG/Sq2qFgKvcRCrNxqVYA3ets8P9UxkumeahtQed5k296BXAUDNnFwqprul9vt9cQ6dooyop2OGI+0qms2D"
    "chsurAktz3nmRtLshOlLg1MEuwzMAlRHIR/m8VmeC4KC3ndk4hYlw3MYd1FmkzdTIHGFlnWyRsH/PiFhp7ZTT17c"
    "Kar35dfS6FfQtskkPwJ1qvxraQYPlAANhwxPPhlPaLPviFZpEZWzm0pRwhRdtTxLA0g8VpmpQUAGsBLjm5Ehekc6"
    "JrHU7L1J/tI6y7UUnI0016DnGNK9LQcrIXyM3Irn9BoZIWoGJFgbkEXEGdQlOmyS98sq6T3vOKqcQVkg3CgrAcNE"
    "UI4I+iXSWxyLHcimSIgiWoU0U0ioCRSaM5GfzYFH0shM+seXU3dyxW9Ltt5DGQeAXHKyc+uGHr6XGgqrhLidXOO1"
    "uMZCaf21gQUHpGTw+BS7CnFIXoc5aJNxLz0EKaWSkemxLNh0xf+u11ndZC8lIT+SKc0Derwn4u9QYw8EvYwwq/BT"
    "Qr49wThdFki3yoJpA49pYLvUfwGcoB99vkjy9vS4N34fqTDzJlBMcP9cflpBVckfAHE2PpVRtqlI+GvpHwSS//y1"
    "JLHwVyJp9BNRkK5HSTOgyqmoXE2AdaFdgCCKpyUNGFFuqbcfKAnI+I6B4aqeAu4U+W3AqfsojF2rSVZIFqQ8IkBA"
    "pY+DRC2LrhrGuAhoyS9iiyf84vLEaMHDcsOMX0QgDKANaYQseXx39/8DFTz7GA=="
)


def _pe_canonical_registry_bytes() -> bytes:
    raw = _zlib.decompress(_b64.b64decode(_PE_REGISTRY_B64_ZLIB))
    assert len(raw) == _PE_REGISTRY_PINNED_LEN
    assert _hl.sha256(raw).hexdigest() == _PE_REGISTRY_PINNED_SHA256
    return raw


_UNIT_BUNDLE_PINNED_RAW_LEN = 56118
_UNIT_BUNDLE_PINNED_SHA256 = (
    "2f920a8ecf147777200cf97ab1cd4925fd6265e98f4b3d457d013b57414976e5"
)
_UNIT_BUNDLE_B64_ZLIB = (
    "eNrtnUtv3EYSx7+LzsGC7Ce5NyPrg4HECbLZsyFrZrAIks0iTg6LIN99q35VlEYaSUPqYc+jPbI0wyGb3ezqev6r"
    "+s+LXz/+tL76/cN/L//386+Xq08Xf//zorv4+0XuUp9D7nNO8tN1OcjfEkOMYZXGKN+GlR/rYpH3dn5Ko/5Pm7QO"
    "q9hdfHXRS2P1YwillLEONdVcQ8l5UzYllMsi19eUN3JsU65KDiFehpAGaSZKQxtpcsybtEp9WkuzRW4ox0MIVyHU"
    "WGIZpIVV6aW9sSS7ulzKN5uyjpelr7kkua/eIZa1fO6qXrPRI3qdHBulZ7lKL7Za3dRu6svNwKUfRfqwTonfNUob"
    "9ijyZutRhLrSYXc+7prkrqFUuYfeU56CjpP+DKWXdrNeo3eKScaS5XfPS1qTTyXyI58G+S/H46jHS5C/We7XxRSl"
    "8/J54BVLkuODHE1xlPOSXBNkRL1eI58KbctZ8n7UoUqrVe5QY/bx3+qvPIdejgz+ZOUb+aRPrNd5qzHorG1o/0pG"
    "F5ndK66Td4xS5kWepcywzMVar7B3cnb/ZV+BfgtFOE0G77++l57q6HW2cq3S16rHdEw8j1HpS8fCDMx4hY1MS85Q"
    "U1rLmtpkpaWcpW2ZKqXwlS4doXn5CeuJhidqetIqupK2qqycyBq6c/9jXFNh+ZrSlWDrJRitxyif9Yws60NXhHRC"
    "/vZyXpF3cqGeUwo/epauKDnKtYGre1+SulrlWcn6KXYVLUa9Uyx2bltTC+llh/LjjjAymsmDflAaiZd7KN3oK+dB"
    "2nsSCcnExARRJCURmequKFlxVFmqMlmZ/KjECnn0SixKVkIkPQxWyaXIVYOSS9TJjbBuOUPOzpCpsu4x6r/Kd531"
    "opHQoyQ0yDcy6qIjGJew5GeS5izKvKvJbNNiegJTz53cR1n7KGKjn3QtY+dyy4/SdJjLynfHLO+VGV7J2fFG0CkF"
    "FX0eK39Wpge+JGvPy5elakeVBSc6jrwiS0n5sepOnKnaUdFvkiy2Hr5cZQGaVIjy20hBl6lye5UCvWpN8PeeVgut"
    "jPKJxajLUrm9kGlblq+0LB8k8f16UnmKmnRXXFR9p+vo7vo6MnWpLl5TuggQPawp9JuKnqMrSsWbrh0VUAF9SNde"
    "ROvpbbWohSJHVRjqV6OuSqX+qJpUiHbWKKuxsP6iWyzyV4VkHNuaek0L5Jnibpgj7uatpW0hOL7qkn2+SHxkRl5X"
    "KP711cWn33/74+r3P367/PnDL+tfPq5/wz3z9Tdv3n374Z9ff/f927/99OnX/0wPMMvj6+yBqeGPNNdu66fIpGqn"
    "wk7H77ABGWaWR32lA7k9CXLdlRDJWFZCeHJm/sh9I4SzgXh8GZ7zEma0jHB7mU5H8warQNWLjE2gFoUy14QNgHKi"
    "zh43IHvOUJNS1R21IApWBq4fXDcwaVNzzG2Ei0gYNGwWlUhZL04iNXFjWHtflB3kSeZAE2soZ+1Uce9S0ZlFQ5TV"
    "fnvkclauxa6vvhDu0I8uY30ma51pbU/Y0s5Zd/Xdu35FWSh6bBQFYSMyOeliCVeNEo/BblpCac/TofZSXr+P8vY7"
    "oRvdHTbd3ZZsT6O97TZu5oERh5mUFp5LacLxonxSk0cNotAo73NT3n2eknuk/ItJ1jn3m0l9cTH1XWvnjc6Ow/Xx"
    "ZM72bO/fXupL+/W7Of7MRoeHS4cHImXzS1Bak7TH7ag6IPui7JW7T/Q7N4o8fIo8EJ5YX4cGG5c8BJo8YptkeCG6"
    "bJbKUULaXspeeUpoZi9tji/HM5v9cjzUeSASu98fEVlOf01evz5Y8ZAiGzNiGwuhwY1eXoZeDobLhJelkMZhZqMD"
    "jldr72fEEmYCsZU+8upxhEm2ea9bdLMLAlXYvsHLFNqg0LRM4kshuUWeOBDQVBSwphiJIWaeTa/4baBrhp8IsQLx"
    "BM3NMUVRZLAUifcFbAVAfzDd2sIEAp2o7WYGDoX+7oE9KUajBlYNc8+qe2CFKc0avRii6GZ+nPoM5LS+DX4yFBK0"
    "oYiQcftenGdn5Vszr893pdDEOnqfbq+ccN9VVXFNrBGh02hUaBqUPn/jy+UjVOwzI+SxFg7Vyd8hbeBc9/qFHfS2"
    "jbX69O/LkMtyoHIg3SpCmwO0k6FDhSP3UF0CnKypJ5peUqBTzQ4IAJcVG1RJR0m024HkUURP73kq0ek0keaiAE6j"
    "dp2iMwRV3kO30CFy0uhkM5sOrlvTVsj5gOeQPlfhIlVmldwiUvKGYilCCi4fgaMXcFs9sHGdSYXLgu0iZUhmlHYz"
    "SUnBU5D0t6FrO2lDRyHnq00j/eulZyskrtgxuUt5B6rpVPv22zfvf3z39S2Q4JbCMm/J7YC8dNEXM8yUnGyZK1vY"
    "ChjuZ9yGzA8Q8gBMLbMYEoC1CgM3MaacfYS9R4i7sAw6J3Y9P2Hyjb50+mLpNH0x7H8HAK6DdQcQ/dLK7LFFFk66"
    "Mb4gGge8yiSkNMi7TVaxN4DuVGMs8p3+BiprR26EuN/DQJqyDFWIyrzUMjArTqSPsbeife62QrUZRpfr6KNARdg6"
    "X9mwss9067wd1eyGkGCWH2MnYtr6rTP8nOtNobgZ99FSza4CpawB2GPAfbENjv3iz/3e3t4oKocDS324t3vpQlsl"
    "4S6RfFfpSxct8c7yFbQPmczPyP0CeUITpQyk40X6nUwZhMF73hDsHOZNHnaPmmjKJ3nUj/T9Acjrfec2mPThw6Th"
    "1HWHx/aTObOfNxhXN9cA58R5FK7po5obwLj1CSjlDZ52aopjKpZMGjFkSElFh4DbFaPqjIpCZhvpqKpe8LC0zWJ6"
    "DMmtZPqMKCWi0kwUPqn0OnrGMgsy9LB6vJ1scE/ruy6VeS2dqkG2BLK1bajdore75tpOmw8bVfNMOwUcJafkB9fL"
    "rpr6VPtKte4EYWtyZwdDrzD0kTIXplF3kHPy3GyS/fETGEPXpM9gFhYKRkTkW4mMCrNXiy1Fy+22JNNkJTqafXWy"
    "9lU2Pyd9jTtW1vc/vP3+zQ9vfnz33fsP33/z5v0tO+teR8kxOAoe6vm92jhSA125p7RBdCea1dggMzSafqWStpDp"
    "aa61kZZ6squRVkzsaK2geSHnyUCNTLKOVakg2ATG4d7+3pWsB884Hu//g+GAzyYf9vZvt1yGZeAXdLXCaHM0LaRA"
    "bSOayUBOcEcWcUAHC2hftowtt7/z5Ryx0wI6HIU1oLps1xSr0EKfr5/qKyRDYm+r5bV2prflum4JkS0h8nASIl2b"
    "vn/lr+TvtT+LsN06VQ3cZLk6Z/VoaSoI7SOmldg9b/lKvVgttNfSLb9EuuV8qoZutQVR26SlkDOBR6PxFWpdaMCs"
    "lsL5JVM4GzW3tNBjTQtttNtSTU811bTRdktfPZ301UbNLSX29FNiG5W3NNtzSLNtdN5Sd08vdbdRdUsHPq904Ebx"
    "LcX41FOMG423tOUvnba8gAYT1E2sO91ayUTBg66AlgjdEqGXJ0I3Gmyp1Z83tfo1KO46u+ERBNysDK7i6NUB/Glm"
    "q6sA/tI2vir+q4AABNunyd1gR8G2sisPydog/gKo0AiGtZKzEK7xptWQYuzclgwTe3YJ23eA2dAoc3jCSds7wOwn"
    "ZhZ8cTx6yyw4mcyCbDvoAt7cNqLkiGYcrB/ILnj7jw//ev/ux5Za0FILWmrB6aYWtFSClkqwOJXAvvMraHXDkUnN"
    "a3rCEeoJdzjBvc5o0RU0mXwyLh+TQxHJYVta2xaN0QslRORkhIYLGzeOVMpS6rd+jUiobCaYv8++87FthRqQZR3r"
    "Lfh28xRiQELlafvrWz0c6yX0HKquYS+WoXqJF7s4ilIPp5DG44bmltMMg77c3Xpxd3ST5GqOqJYItOPmb1LpPKVS"
    "v0AqDcgh06yxhVQjR5JwNFpBJitt0vHJLKSAfqfWq3J71YcKVl01+5Ora7QiKBR4QvMzx2Llu24r4LBfKmmvu3ly"
    "CS2zo0cZ6YfG6C5Os4izyWF3eUabGStG5TTkc6uUgmUekHMZB2hnUkzlrj4vxq32LPM+G85woGl4TRa1RL4XCfg1"
    "6XOe0ifMlz7FtrdXDq3afrKYE9x6cK+o2koDnqOKr9CsnQHebD5S5cIF74H1vsCd8Si6H7KYJYVPLlKjuDDuNFv6"
    "qCdrlvR5ZMfuo01lfbpE0OJSTRa0NNgmD85YHsQF1khFzx/dBjGPrlkP+H3Qv1UGBCySgFzo6FVvPiGNSWgsArkw"
    "EpHpGH0lojNYrIGnELFPVCbgOVM5skQezPSRFWyq0SwE7KXokZBkNe+pkY833KwHi9I5+MKsjIxvsGKFUPeeWIuN"
    "uODnyzF5lAqaIuISjdcfZwp6s0JaEvsrJ7E3eXSe8igtkEddsQh1QZL0Fqn0+H6xM70QepyiFniciG/C4YfJKmJ8"
    "ZucYpy5THEgHos8CVIXZNxYf7xd4x+Js7xhPS34njxFp3MWkpfaNSG20CE21SBR7r2SiPQl53DMbyXZ6sSfDSCqS"
    "CA8k1w8+kojnLdJOOv4SEk02tSIUzTvWpM+TpE9ehBgI8E+9t+2TRVl4oigdHLljNAF0m22OoTaFWRKpGER7xN+F"
    "XWSRdKQRKKwJYwjyMIJ4y+59GxdIH5V1w4t7x46oDMszPGSpyYJWwqVF75uEuH6VBfGTgrVhXiDbK9HkRQ/W0lJ7"
    "DIkVbMsS3Epj6R2BVvCPMRo2bCI2UmwXx+Ba/QjCMqHBmxcrgsaq1wisefZJP9M+MYR5Zs/HRFSo0tfsaIMejLkj"
    "DLDPzGYZPEJkOLoe/1nmvIwvcXRMwoQ4jthAIIuvd6rsrnW+kyqg1CyWVoKpWS5NLj1LLtVFqLKKBIkecakWkyGa"
    "QbQjmmUyckRpx2L12h+VVaCu4PiFmMjguUJweTKRFDGdiJAE32ywI2akOQfL4vrhxS2Xoy5C9gxbpjQp0QqYtYj/"
    "2UuKYYGkCLapKzkthe1jIxljdtxyXUekyUC2oI1/QD5YHupABokhviyOkpEOPXIjMnL8XCCCY8y+sSz3mC0p0tz4"
    "iuV+YnlZ5g5Zjo5js3iP9RkMQLFeFd8CV2UYsX635cit4RXBKVjhhd7kKYiAgW8Dub4aqxlOq3hgs1xa+cHPVH6w"
    "SavzlFbjAmnlCDR/csWzL/kpth1wT16y9W70aDheJ6we85+Ztyrhc6JqgMkyZFrCt+X8HhxYKZZbWaeSOTP9bcNM"
    "fxtytwSv8VCmcYGhM/k70MvqmaqDQdPI5yRfH3xaoo5Dsmn1jdsHvstTHirWXCISVW7Qa6dW/LNJrFY+tHnamkR6"
    "skTqF1UV6MmqTIYXnkq2Faur01FNZyDOka4RwmAJyOIM2ECRcXReYyhbzITIUgdOrIDHjoYtxn5JcHy1X8IiT1v/"
    "4p62Iy6g+ww/29gkxBEX321c/Ty5+rKs/OR3Dqb/e621DEYrWLaj50wW71mNXv6NOIlVy7KCm1ZHrnczJTuCGYwx"
    "LY9IgQAOmXMXZeXX2dViiPIwBrxy1LgxWdRZ7guRfRv9hLLuPSPfEGw9dpT5CwMyqxp+jSiQVRSjmo7G+nX0SEI8"
    "h6dU+rrZGGdWPLvJjPOUGQty6bEDRu4zxUgs5hDhhsXrMpr3ieqWnk+IL8eQUBpPMBwxkiSD/Bp45/W46HvndT07"
    "r+fSL5IZ6mkqr2AJHGH5+Odk1rfc+iMsPt/4+Hny8QU58O6lIZZNxUir/2z1m6sV0HcdejCsrGFZra4ivTX0a/VM"
    "D54JeeNWX8UQvaGYXdHB4UfQr/qcwoI6kWVuRJy4t0UYLDPfsuLTNSaZmSmG7gLzda3JF9fiE/ksZiuYPZStwiRP"
    "qWOqR0cpd15tsljG4mls/PASOr9tHfGUrSI8EymYfjFh7rzauFOT26NUWQBDHr1aJ1Yn9usAljuB+xuoINd7zXPq"
    "iFoVc8N1uI2rzXTXz/OGg2w9z2kbhaPYQWCHC25ttHAjXQ6Hu7VNOnx+Tn6Tjml/gyfu0IEEMjwSyNzoGeJOmaU4"
    "fTkGaiCiHDxHPpCH3rvNUi1LBdq2Ko1Wr8XqJFulfbaWsRph0HxpO3Sc6A4dJhU1jjLmdGdvjr/++j/bfxWp"
)

_STRUCTURAL_MEMBER_EXPECTATIONS = {
    "CLAIM_SCOPE.json": (4779, "2cdc358ea585b61a04123b30fa83424c9d76cd2507d1716cf3a944b2742da769"),
    "CLAIM_SCOPE.sha256": (335, "dc748bdcd6bcb8221beccba9b99ecd143ccb25f2ef9f51b6798ceb1d16654d28"),
    "CLAIM_SEMANTIC.json": (1351, "954e5780c67ac9dd5cb099d6174659f68a9e2cd2a2c1649676b85d1618e1df0e"),
    "CLAIM_SEMANTIC.sha256": (338, "29b4383e34b81d802607e8a9d9e4c23cfec60b1d1f0c536d96547e94ba352d8d"),
    "PREPARATION_PLAN.json": (5823, "e0c141d97d078cfc958c0a8098e65fafbd79ab317325e0eb525cb5ccf308bec1"),
    "PREPARATION_PLAN.sha256": (340, "22fefeab395fa9be9c1718685b08b3fde74f17e85014bee67660ad7697afda3b"),
    "PREPARED_UNIT.json": (12388, "81f8ab435de30a86eccfa118d7b43824218ca7c39957338e339285d26858598f"),
    "PREPARED_UNIT.sha256": (337, "93afc944b1886c442195d1eb41b5cb4aab58d509f648194c1c72b739ed57c5b8"),
}

_OBJECT_PAYLOAD_EXPECTATIONS = {
    0: (35, "3a2b73a11c72dc923e86f194de03f39b05cdeb05e0d0e642dd0a529ed4726750"),
    1: (120, "81c43f45c70d0c436a1b9c06a6172baea7c6efd87f3ac471e1540d5933747056"),
    2: (290, "d6d73ba43c3aa8585ca8bf7e456487db3b64fd3525fe1e7c8e16e031dc13f324"),
    3: (29, "712970d821540b14ee452b9bbf0f314d91fdfb69d100a76580798e371addd064"),
    4: (130, "0e706d1131e8e1f25604a34c12678284380002afcba19e63a116609a05647fba"),
    5: (288, "3b7feb2ad8f69305b0c0be522139fc04fc193f1fd7f802b773b3061c59eaa89a"),
    6: (131, "f6746d1ee7feaf9c82932bf06c39aa11f101b3f913fa3e21a194f433883c8a79"),
    7: (292, "87e238077dfba69b83199a62cc8e2ebbcebeef03894e587089243ab7f900d1cd"),
    8: (40, "2b21b06a4c56bb29d797e85750c8ebca0837ae7f09e9213835fcb3efc51da6bb"),
    9: (138, "4ee4aaaf0e63c6f8f1a90eb9500477b8883d58449ed1bcaebd6aacdd966f7c75"),
    10: (291, "1594633633cde401888dd4a9e22a6126bc3108345eacf60e8f973e9d11453bf2"),
    11: (127, "840eb26f730b559bd35ba465cb73f6ce53d3bf7230a63fee8e7fb739bc266230"),
    12: (246, "599cf50c8ca8c2c6e6dcd5659626c6ddb768221f6e4f86e12a8ec09250933130"),
    13: (36, "a9e7f0a2fa84a77f7455384837381ab528137802d976fd3c194bff70f899f58b"),
}

_unit_bundle_cache = {}


def _unit_bundle():
    if "v" not in _unit_bundle_cache:
        raw = _zlib.decompress(_b64.b64decode(_UNIT_BUNDLE_B64_ZLIB))
        assert len(raw) == _UNIT_BUNDLE_PINNED_RAW_LEN
        assert _hl.sha256(raw).hexdigest() == _UNIT_BUNDLE_PINNED_SHA256
        bundle = _json.loads(raw)
        members = {}
        for name, hexv in bundle["structural_members"].items():
            b = bytes.fromhex(hexv)
            exp_len, exp_sha = _STRUCTURAL_MEMBER_EXPECTATIONS[name]
            assert len(b) == exp_len
            assert _hl.sha256(b).hexdigest() == exp_sha
            members[name] = b
        payloads = {}
        for k, hexv in bundle["object_payloads"].items():
            b = bytes.fromhex(hexv)
            exp_len, exp_sha = _OBJECT_PAYLOAD_EXPECTATIONS[int(k)]
            assert len(b) == exp_len
            assert _hl.sha256(b).hexdigest() == exp_sha
            payloads[int(k)] = b
        _unit_bundle_cache["v"] = (members, payloads)
    return _unit_bundle_cache["v"]


def _member_bytes(name: str) -> bytes:
    return _unit_bundle()[0][name]


def _payload_bytes(ordinal: int) -> bytes:
    return _unit_bundle()[1][ordinal]


_EXTRA_BUNDLE_PINNED_RAW_LEN = 321956
_EXTRA_BUNDLE_PINNED_SHA256 = (
    "1c7439d9518bbadeb65e26cce64f85523111deaa3733ce73f6599c1655b91065"
)
_EXTRA_BUNDLE_B64_ZLIB = (
    "eNrtvVuP3FbSpf1fdN0YcB9J9p1Gn4Ex4BOm/V4XpFIJrR5b9iuVPkyj4f8+3M8KZmWdVGQd8xAtW13OymRuksGI"
    "HRFrrfjPq7ef3v727y8fv5x8/fTx/Murv//n1ekfv//529n52cmXT2///PLPP85P/vz67rePp2/PP/7x6WTz/va2"
    "6aV3H3/7eP7v9rk/3v3r7HR689t///bH2/ccqnv191ely6HEEkrJ7Z8PueaxDO0/SsylP21/l5piSvF9HtP07vje"
    "XuvS0J/WUM+mf0/7sU91+rd8qKl+qO/7roY+17HG6d/T6Td5esepfVuevmP6N3/IZ+UDr435dPqvkPN0xA99rO2T"
    "HDe9T92rv70K01L7dzHWOh1qmA5WpjeV6cs+TF/wtk6r6afFT699mL6sxJjexpiH6WvS9EUfpq8cp1N7P33B2fS1"
    "dVr+9HqM8TTGadmpDtMR3tcwHW+sWZ+ub/t2Imfp7XQipS2Ib0htWX3Xt898aK+0z02vjdPKSj+tYuuoH6aLYGu5"
    "uIy6xNM6Mn/3qV10Lux0KTYXdj7K9M1b5zd9R5i+b2yX21a54vJPx3vfLmVn13L6fZiuWD+tW8du7yyc41DDtNaS"
    "qn1LrCmlmnlt+l2NaZhWOb2nck7Tz/30iW466Ty9EqZ3TitO4/Rn+g2fKLVM72tHqvyUp2PElHWU6dN1eld7dfqa"
    "6Td1+p48/Vim309Hsatxab12hsN8HfrI+bYrNF2rPsVmCe1qTFenXRUs5pTPTT9xltO9nu7PZDXTVT5rn9BP07vD"
    "y/6JH67e1/it+2pn156I6TzatWn3svT9dCZ9e62dsX3ug850uq6L/sQP062cXEGzzOlhnY5dmvWWMh07p9yeqfft"
    "YZ6esumfeDY/NbOt3eu5PZ2O1U/PauKpvfL9/hTrysbVT7E9uWOzsOmpm57G6ZXpiZyevjQ9z9OTPT2rk+ttT19t"
    "T2J73kN7Lmt7wqf38Wy2a9Se+SFxFLxCP/2+fab5Ax0tt+dwOlqZnt8htf8Ff4rveIrXWei1Zy09ezi/40nV81HK"
    "cENQnyxnWvO9jLg0Q2wGO/002RsGO53K9GNH+EgteDQjbEY8/TZgru3rJ7Oa3tmCE0Y/Gyv/1cJXO0ZJgdA1hSyO"
    "0D43+Zmk8JXciB9kxEM7wvSpdn7jmjD0wIfjBZ6Nq7vPbz0N7VnI9wiVpZvOpAXMcQrG4WJP3YLktPR309fFpQHy"
    "+lWdfm6BazqlZrvz9mE+7RbCtNngku16wCz3cTWRPW1zCC0Ctj3vFO1wIm33OsW16efJLKff9qm5nRY9M7/FcTTX"
    "g/PJzYE0NzJH2hY1cUfN9bTPTNG07aVrZX8c2vvd1byMq7n1obp7v1vvs929Gjb79lN7cq8+0b7tfdWvz10T4X7g"
    "qcrsWVtOpA1B0nagPc1sK3qeTuWxmd1wsdcGNh3t1YHjTLkpm4O2MZguXm1eoeAfmqfAYfLsV3+KXy53feCmYXj+"
    "TcMyX/CtrcQwLXx8Ujf08I3FN+75/m0t/vrbqy/nn7+enn/9/Pa3k9/Pfn939pny6psfXn//48k/3vz8y3f/419f"
    "/vg035Qy3ZJOC2hOhH1WxJ1Mr2GK7UTjtYtxxbVNl65MCzltp3X5xk6fa3Y3TotO7Z3lHd+bOLUPmLy5FndLt7kl"
    "XuX8t13P/Go7nylbbIXOVgKhAELBpAUGNn4qehAeWhjouIrt7pGrkpP2fKLlnQPbyHacqPdUFVvalnB6MFoZZnov"
    "GWoLYG07Gs9sLc3FlTlyc0Zn2NWZ2cyND2e77+zsy2RHN9jF7VemXL+O8QYLvOSV2ndO7vjau67mMnf1BtrjFk/d"
    "lvc/J19jqw/by95pl+Euu7y7jeRWuc9WeTmu3s8yt49xcZeomsSFdhgfaoeTt0zTf7XEtKWt0e1yt+zypvraDXuM"
    "R4vrS75voW2m1ba5yVDcCg+huHVvr/jgivKdtpnv3lcuqZG7le6rle5I/C6PYYceww+5qLhDWU+9M6Lfsyvh9rrv"
    "9roj/rR/Ggt1D7v7FrvHmdLwSFbr+dMBQmIfK4u6T/vsTssdH8/felZ1KLa7I3uBcHf3aL11+k7gpWHLu9QFWtAH"
    "WklLcGt6DmvaGQ8VH9d+3Ds9Eo5jf3OJsKDvspCA0aynvP82UqjIKvotq7qBCGiolEbza1gUdpjTexr8uULoC/Aq"
    "BLjsDD7ZkCsNJtl+ldmJDA1MCTIG2GVDt8C9KLAwhJuBwQHssuP4adoFCMQ12+LFHdgV67wBEtc3XxV5prj3XMdb"
    "nr+255O9CBl2cX/M+gSAO7sMjBOaDNsoba+4/V287wmAbzcds2/oNZ6g6UhJNqqdW7s78un1HTZu923ycWeTd+um"
    "/x/yB7zejVVyA2RuI+q+/PNtLHU9qF+w/Qj8tzSyUBLKSrbZ+EIFSH8P8W2G+PaQWgcsN5jlN75RTCPvbiS39nfD"
    "gWXgxBUYsHBeja00QLo7QjjwDVaNlXL9ZScfFtvB5mjTUXLDxgHvDiDx2p2FmNgoyIC5k0G4K/TECBsMnB00iwoR"
    "o/mthJcZm4fiSB2g8IwtJPNywt5VcHiQNVouNa0vTCt7T7Se8qfS5XINRmxW+92Pr3/69fs3l6CgW5udx3gg2bJ0"
    "W3jf5jCq0sVmbHIRzaVstV7vcPqXYKZ3Hz9h2nkToM50O7mJ3Qybvgiv9mnBYKdHoIW36fv6OnBFzEBudi2XVtbW"
    "1G01lguupgBYTBzzrM9bQMTmJpsDy5fedx0IubmVuKt3qZvCqFbfruJDPq+Af3H2q+9MjIBPJ7dlTIbmiprhBzi6"
    "EBvN5PVnBpXKPcFiwPg7XJT4Se03LaA3fyiOcHN+gq1WHKfYwXD4zZld2+C0R7xd7z5SuNgGIb/4db9xtRcbid0B"
    "+N6+2iV2UVhv4E62v/XdFTprWzt3s+kvtDimO90CXHs/ltG2baN44sZhG9vx27dwHiLecjVwkiMWWOHJdN9Y+y3A"
    "4Jve62nMvsPR8eb9NQ8c5mTkbs8hz6+0n/csSlOStgYRjZEe/YJmoZGNWCC8d/hG9EtINyIKBwNXQYzOke3hgFJJ"
    "zxOSLa0JtZpWQrsy2v71SboJdWuT180b8nb2nMsi+NPt29ftiHfD0a+XS5Yd6VDTqTXws+0065K9XU22rh3z9qRn"
    "WWLW4FHZLPnW5+X6NvK++c9gOXmt2v0GxD1CvSA8jjzgGcmezAMgjYXmQqAss90oFirGtnmociOjZfvZHqBqKguV"
    "4NG+p3j+c7D5T1ENk7Wma1nQL//7u19e/+/Xv37/808nv/zw+qdLedCNZY59SORvW/mNpTNFpKybwQVFxoR9eIaX"
    "rHhUTFNntJszsLfq2ekH9ueZPduIxk6d2casrxKJAuWySqwPGMRw43qvRtaddxzfXv+tpf5niw93ru+qVVSuVWZH"
    "HlGv6arOOLAj0b2tWGPhGrfPS+gmY828h//v7I5Le61X2bUVa3kGKjugUKVB0WF586qfgJJKNt72uGfm9LYKz05L"
    "dVrqIdFSbT9+s+94P/3/ph5GU+8s961xU6ZPlynKE/IjxyfQt8fFOO2nrVbmjT8nve4e6XW5zWPV7QjTtnA6UiyF"
    "tqSegPdsG6PDxZxIu7tEWrd1J+ceJjnXLduplMdJ+HXLd8s/FhKx27oTPY+dmOzPgD8DTnb2p8AJ1MdGoHabd2Kr"
    "k7I98/XnwYnevgty8vg+kMdXWGjG9kEN5EvPOXiC2J4Pp6M7Hf2x6ehuoU5w3yWC+1PY44al8g0k4yLafIB9pzGF"
    "DdsJa4rxhbCxwMUmw+xl8UuAbTfsbATjC+kehpVmEbV3BdCyzByrmlrUsHvirYwgPztQxPnoaPNXAPbYKPfwaKnz"
    "1+D39+SPvDjrwPkjB8MfmdbYkicAttvJ2/RK45Wc3cIh+e7/O/mvn77/1QkkTiBxAsnhEkicMOKEkRcgjEjcxI7K"
    "N3/glXkb6TuNPdxpXPElN5bRp91Gs485ef1WJKv2NFSlW21mPNIBgXX0RLiCfyQSW0STrlnTNGtz5kOVZ42bpLCi"
    "kBbYQVTeOwsLDMS0zLvGTSTbXuHYv2W/E/v2nJvkSrvKJpmyF4Ihh0DWskR2q2RHwaBeHb56/ezm2OdlMKd7rWxQ"
    "eMw6zpgVVsQsZV/kixQelVmNxCJlA4lVJZUj294PL968VMu9GJSu3Z6yqyYvhjBOxzEK+7mxxTWOQNRL0vGcrs3i"
    "mMX1WBa12t0lFxktq4ncs6B4qiyb+JmaXil3RgPc28pG7lYgX65EZbIo6gAqy+rmFYtZKsT25Mgj3xX3m2zpkcrp"
    "ms/QqvTYdJyxKS6PTc1TtzWSX/Q0u5L0pZGtTFT2AhlQofLUoky1mlakfhWJO/rmzNlEariBeNBzxaUwjVp1q6Ja"
    "PavMPYUFsUl1xAWx6bY61j4Tlu8fL5qAmUcKJzsvgAx4tDjOaJFWZTKZyljGf6s6puxmpBItqeJ2ZoUeEZkBFSty"
    "E3KXvsl46r3U4jIrjpxkO3oPXCNKVJl+SE9/JM9ghQXRojcyw93VNySYqfN1VX28djYd/S/18gBzUH+P5Dv0fFpm"
    "RtUwWhdsQOo0MFmh3e9K/NN97anNV2JhRNJ5JDtKi6tvOyc04BmMSxW8qFSBR6vjjFZ5VbRSX51uJ13zDv8crIo0"
    "kJFIcrqdWxGgj99m9WCtnyI8iqLRkNRJitTmWh1OGACrZ4EKaD2dsqLu1i/uFrVoKSxBZ/E2EW2DjQbokyYCFe7H"
    "AA6hcjbtPvRkZ5V8rbeBBchqb6S56SdRxyvE+UicmzEvw/4LhXjkcqkRr7t5bHqC2FTWxCZiBOB05URkEi3TSfSI"
    "hAuo4LiqxsmoQ0TPp4B0HLgKmXg2qi8EaqGCQCzqqfD5Qp4FtqyGLetfVndLj1532yOxnQfU3rJHChfqcUyBx4+F"
    "8aOu6Nsk9uSD1dKCKlc1GU4bxAC1N2Z8krN05AEz3luvDZyLOvMMJSPeCG1fiUmg0+jjdzNWvdXnVuU2aSGmINP9"
    "L6q26RpWYc01TqgSKRmXJmIWOVtJ8yvcEzpSiRpeq+VlQ9IqamaqckRM6nZC0woPXw5RJsuzHY9hnvV41HrCqNWv"
    "iFoRZlPHKtXtgeVVZ1zchkNjSO2ed41Epjr3nMAsaO0D87DDHJ00Cq6K5VSqejslzVEsrcp6+kfPevZaau4BeVD1"
    "GOIydY5D8DjyzTgyrIgjhfWJBzwmmJF0QKIqZupaWI4gdFvkHKL9dw+uWMzhQJypMIKEqM7qiBCQiB1WkWt4thZt"
    "8goW0LiwrzPCOepVybMRqrob4KGrsh04xFxrVQcTvRo6VuD1MmcYyOHEE8zK2pQL2jUQ3kG8I6H+4mFJRHrW4yKT"
    "OyEy6bHsOGPZuCYngvYC0qzlNqDMOuIUlmSdelXv6kUfBwRAzydKFdNHnf3E2GxpVQifUDnfDNNIDFoqfaC5xxWV"
    "vMFYoHdHswK+TXej5XOR6NpyvoHjkKtxJsZspQ4X7fz6KgyCom+LieqJ0cvSukHbReKYdEIKd3MEux4PTeLV45mL"
    "xHoNz+PVE8WrsFKBYWAlA748oWMTWNeIf6ZyV+dOjOVQcydGPE5TGgpwQZNJ5cmvR6EYWodKSggoIJQqFN9FprKs"
    "hlcfvYa3xzLJD6jgjR4/DlZi2X3+cfr8dQoG0ioLUplJYKtNf2rGEdC/B4WckupQ4sR0SUpU7fOVDpA4pcmU8rok"
    "zIEpG1DjSqZJhwJWCqsUDMbFOUpMxRR2JAcL1i2pthiNrypMRN1kGvOZj1JqoIKYTX9BOYp+J6Q4fKaWnZgCgvQL"
    "YMEeksC55ycuke5ZxNFHlDW6Axl/GaXPSpeiIs5NFQcgQDBl0QFFmWxYgGpaqy3LiKp7JaGapTvTmbz3aJoDMC9R"
    "dBvpeIwooi2PKC2DCU+QRezhkICHqBC4DsHBjRhwL3+cXn6NXsCs2S21yaEm61ZkdaSNTx94X0EzoJtZlIZkznTl"
    "pYg22u47qxMCk169cOksV6l0z+jl1K/o09cVWYP2/bY21NiSxZpx1toFSTAaEg1sQZ077z3nm+esyHRHxdaEsUm+"
    "QZbAGakD0qOJFg5jvMdj5AsaEHKPgSAzjrAnX01CnCdhRcCh8ASiys3oEBTrpMkt1Tuel4a2AK1u+V6cB4RQCwUl"
    "IgV06bXy/x0NuPl6XniQres5D8vYi0kQ17zg1sCMi+iyO97NR7HY/TnyUSzzFIt7zmHBx+MDTKUSP0/+Qo9ayu11"
    "o2/T9jz4g1mvvSqzURaDH4rqnqiyZp8N0u+nj5GlSABiK/gclgOdw6KY2fo3Y8lXJrD89bdXXz99PD85/ePT+dn/"
    "PX/19/+8+vL13b/OTs9PPrz9/eNv/57M+O2nt7/9+8vHL9Obfv/z7fnHdx9/+3j+78ns53d+Ofvvr2efTs9e/b2z"
    "w/2fj5/eT5/8x0+vf/nH//r515Nf/ut//vD9G2YVvfpr+s52pN/Ozs9Ovnx6++eXf/5xfvLn13e/fTydjv7Hp5PN"
    "F345//zxlEX9oW/68+2/f/vj7fsv7aVu+gJTBw/T2RX2F9POoAztP9p596dcBfmk93naBeYQ39trU0TuT6/7llbR"
    "6ptHaf9/erf6+HSMS7uJ9D5106UJ8xib5vaGXklNuboRuZdo7JO0ay4G1ZgD3Fw4k0Jv2zak0xPbuHYpy4eLS3mz"
    "413izLcvuLnT0K0fYlWShqFExEUK2ytREDMldYmNNIBuhZbYs12TW9U2q9doCx6iqmE6OM6INGWZJYmrnLMARpZQ"
    "zCnBUTnP7fu2kxBN2dK9nsT7tD6O4LmM65/LVAXsaMm0nqlK4VXid31Si24gLc8AOxgBxRMpcaXe0l9tfxgxxViL"
    "zNCjLHgi5K6ZzFUl0NR+Ovrn8t5QAd3x9AxBdmnJ4IZQO1nVtMp7mGU2I9NMtFylk98ZWla91Gwsdpjj1eYnWfAY"
    "MK9kGvPRJsGALULFi/6zTXXTJC5VkNDar8XNctdme2Duz2Ltt0pq3mDfzbrzPQLYCh20Z9FV3KkwVtan5pkdn4bu"
    "RUTvNEbNBvNRrovWMlT8qYBbNBVYskuB/WNnoPKyEdlLJm4uyEux0ZM0T9TK9Ci2W/KkGFG9z7byIQoeh7+97Nc/"
    "lxWSR7bdYpBkCySRwQaddrRseBpt3KEkLauGCNhYtmC/7RG/SSYkMNJAEqmxbuTOOolLpw1h07O+3ZLUwpiG5wjl"
    "K1mpNwT4YVrq+KSu5OHh/j4UxR1yLH/97dWX889fT8+/fn7728nvZ7+/O/tMAfHND6+///HkH29+/uW7S5Onn3jy"
    "7fbsYJ+Ce5truXPKbaFbP1AMiFUTKkeytd4470w0pldSNRksmaMHcZuN16dSHtsx9V5NPaZInVjzb+FJdihfZrvD"
    "j4iNuTjvcsnt3TLP9llmajquaj/y1mdkdDzDVDy3ul22umfCeb/AdC23u+e0ux1Gnz7pxBy3st0v7rzg7Jlnmn7h"
    "VrirVrgj8fWJVPTd7vanhLZDWcWT6WK7Pe66Pe6IP3w2fV23yOe2yD3ORJ5AM9Ptb1+gjS+qPvki+ndum7ttmzsS"
    "q59JR8ut8XHBprvUxXh8ZRy3lsewlp3xME+useH2ciMiYH/36o/Km7+Jo34ZU7KIr15QcR7QwKma6IkGAbA5Q1cA"
    "VoepKH019DKZ5FxsHlqAyiGdsiilgRktofkAzBTt0JE2pCsY+XJ0rOnN/THrEzjqmRjTl0FRL8KR3kZb3ZMhXQXx"
    "ROkPxI+mFI7z9PEq/adRSglAsplIrjmGNnsDgCevB+k1AAeFAWLWn42UJNxPAEqKbpQzpB+NIV2lxmsqFyi1c83j"
    "DMA1jzTUbEqIYrxn+PAN1Jvh6CTNU4FKFkwTPgKkT1VakOLniIAmXBhnNr18OnnbMb8n/k4ZTelyuQYjNav97sfX"
    "P/36/ZtLMMFtoNa9HkG2Hd0W3rM5haqUrZmX3EBzG1vtwzVyYXcfP2HMF0IrZ7qB3LZuBspehFD7tECRk9G3EDZ9"
    "X18HrsGFIMQNzuTSytqauq3maMG5lH60VRKmt8BszRU2l5Uvve/a5uji5uGg3qVuCpXRJHjCgz6voH5x9qvvTBQF"
    "LBNe5VCyDRIy14NpRoaIRrgfEgGIUMmikdQiLk+Dg0aJg1qY7iToQFiWADbDWhlelNm2mrzK1U1Me6jb9cY6yyVI"
    "6otf9xtXuyUCszNw0NtXe7ddDGInJMm7BpMCGkwcIsg5wnVIEAglMFRsyHux8+BFtmUM0xVPCTuQBEhvgkRdtSlW"
    "fC5+0y5uAZfe9F4HJ+86OBlv3V/zsGFOKO72DPLsSs15z6JUQ6EYe84ws/s6j5vp2bqFpOQjppmVI1ETSTunDe/G"
    "rpIGOHMVOv7myHZ94fbwbWIEDSlfkpVqm5cmKJiWQnRu35BuR7Qbjn69pLHsSIeaEq2BSG2nSpfs7WrCdO2Yt6cx"
    "y5KrBvHJZsm3Pi/XN4b31XzqCM8Vkprcdprn0dq8pQJFtEgFjgchQCytxjHPpvEUbDJ5tYdNuVBnAgzRlA4DmlAi"
    "tU2PlGc0B5vRFNUZWWu6ltdIsQxBppNffnj906XM5sZSxT6k5ret/MZRn5nRAPC6Ja8luX4eu74mG/Ypef2uziWy"
    "nrLYAM9UQzI744EPnBXnQ9GrqPSFDNh8BQauwbCR6f+Gp9sHx/Ht9d9ajn+2+HDn+q4PEudf7l7S1eKBiya/WVXk"
    "ZIeRuDbaXXdcm47XqyRVxffngdeIC+nbYDNkdX3b6dhd7Nmnz5n2ExAQZwHQ1hLG6V0W5HUSopMQd5CEuFwimBba"
    "We5tQFUoU7wmeEeOT8huhm/s49NW1fI2m1Mcn5/i+BQj2NySnTb5ErRJt2WnYu4nFdMt1+mdh0nvdMt2yuihUEbd"
    "lp2Geug0VLdxp7YePrXVrdzpsodGl3WbdgruMVFw3d6d1nvYtF63cKcKvyxV+PGH4rr9Ofl4DfnYLdDpzPs9BnyL"
    "z/ANzNsi5oJmf/RMoutt/HYC7QcLB6BvDxcnwmaA2syo7wqqNYG0ZISr5rra3J+RofTV5v0MVTMqcxVDLIMBCxuU"
    "+zGPlrZ7eERE6WvQ7PuypV8ake7cgoPhFlyaJx0uATYb5+DsFn7BPBHdyQVOLnBywcGSC5xM4GSCB5EJJFFhn+c7"
    "PvDKvAX0PcMe7hmueIUbS9TTvqHZyZx4fmsPEJImLxOvkc4YdYa2Fklj9Lw6cPU0cRnfZ7+XJMLAWNaBBK6dkWKQ"
    "4hhiDIpMJHyFMZDT996wwrF/y84l9u2JNuGMtkITvtgL2YdDIPJYErpVTiPZr1dHKF4/uzmKeYnKqUBXiv8ek44z"
    "JoUVMSlT1Ivs16sJNCWES5SxScykt991ZFBJJT5i2UAOeLHejmHEKiMOfLIjYy3SWrQIVogGtZbFMantE5dGpUAh"
    "MpBJBPab5Jom1JI1tJwzVc7REV3aves5DkPOuWMFQZeUFIkqdzdxXzuuWibDGWzIeTtS2pzTnhLxPBI5le8R2oAe"
    "e44z9sQVsad5zt5y+dGiTt5UPcn/yRUYcC8xwKqKQMZHZ3xxwc9X9HqbN5a/Jk4lVeh6iWq1ipLOiOrr8nyoXZtx"
    "Sez5xrzsvSWz3j8eNJkpjwROhPVocLTRIC2PBkgqBmAHba+uTEHfrG5TTNpfJ5NWHPltpY9UJELLpzr+a0jSd6dD"
    "QLWsqi9GjGj5QaJK1VOLns53RXUsLMtD2tWm/9SqcJne3qjOh2VRCeFc3UEAGPSkCjEvWXU8EBcz76/kY6qWZc5M"
    "PZeeezOaYGRn8TLsKwndMxCnsT8pjd2j0XFGo7wiGiFQzlo69SNa18WQDPxNPIpJqIJKl2OgIx7BMwjpMAo90FZv"
    "sLmEt6bmZpWjQuYSDfehSlJdURery7s1nENb2Ui/KHLtqdJVIIJVUTZZjUs9GiCEZF/KvILiGp9ua64beXZ1d6lA"
    "UjHsrbulrk7efxEJj0wuQ+F1MY8994g9ZUVdrG7wdepShI2vjjajKlDPiqy1kMOoWwGiUBmAdcmzZUSDuh10OEDg"
    "VdXLDOVWZ4j4sNklLauL9Y9eF9sjIZYH1MayRwIXcfGevccH+1NX5CaVLklmDy9ceQGn3YNOjuQctYqWE3hFiMlc"
    "5+EkVIiEuwRza9eBnslIFUq0IWpmNrokVA17yqtyk7owN6nU4QK5UZiRBMQwZVMjv896FdQo+LiUjdxkdKZ2LYl+"
    "1d5LRQ2UKHVC8GPtp0isTOoubfDaByWh5NmKizB51uJR6QFRqV+Dbq7KREbWwTgsspeShNrt8Ngam1WoQ2nNGhFY"
    "wGYl5SX6LxsWSJeGGIXv0RF1fsYAaDlRXZG1jMs6OKuylr2WIXtAHlM9RriEmff5jzxODKuqWwN9+wGmSyab6clX"
    "ijraLYIwpT3Q5da/8DfpmxT29IPwu7y7Gl8QpiH9dvExM3GmFx4YJPK4os8/pLiwzx/EWSXfAKHA3QrGg2S94A16"
    "UMbBop36+pas0FGpXIdIZBv4xFjFva02vZ7cLYnzOxAN+02v6EDkAz1rcQHCZxEg9Fh1nLFqXBGritWNYtrKZuaY"
    "ZLWkSOe8Gh9GaIAMOhlFAH5fxYrEY48w4yMM6ILeQYArnYz1nIkb6DusqLT1huNaMMKdd3fE0SFp3YqSNUkQSKOM"
    "B/KwAiYvEJNUWSyoUTCmvQphPWyUHHoqbdIDEL4u8ZvANexZ5YHJf3q8cgFRr7F5PLpnPAqrFARU7Rqoio3Gjwn8"
    "RL5hNbZIN7/Flg4/3lZNX6iaxkYtxrZXlU56LsqxEmcY6cNkdHmwMTgz3aoaW/foNbY9ltB9QIVt9Piwt/K77tOP"
    "06evYeBLR0zfovyAjrSQx3BHVDOLxlZvqDBVhEZDbPVguMR6UX2p4+zURc+mMFc4ft3glTuY++uQxksrYqi+oBIg"
    "zk40JadgjJuq/IfOjc61kANJI6+nLgYfVHkRNlNM2YbuklBx9QLzkKR0p0raIYlfe35xVPLZHjGOM2Ks4M2r8226"
    "m+KQDOjnJXRAA/2VYGiuit+vSfqdwTiVvbwqNZ6qmg7xpFPtyapdY51xxgHWS0+MWYMPzsu4KSuzgD0UkH8Ii955"
    "9HsnP+9e/Di9+Bq+ezQMqtXFq9QbC2tHd4peAKw7U8+V9+6T+HbJ0FDiHc4xgA54hbcIq493SnUVpePeVJbX8N3H"
    "pbpbdOOjrj4swoYhHmrcxKveWCadlLZqMeZktEpV4nhcC2m2wEwZDOMcLDco3JuOrnqVTmT71sMY/fAY+30Nj7jX"
    "sAipNI88D7KybAq8sITAZahOiMwAu44km9ooZ4PdoAqpTlI2NHlMlsny7giLKZgqHB2kzfW88CBb13MepLAXMwOu"
    "ecGt0QoX0WV3vJuP6bD7c3RjOuYJB/ed0RGwxmpopAziaYSR0ePPMwjfLB646ed3sl9T/QpUp6SN0lkMQB4SXNdg"
    "2ODO/It6y731LorP6DjQGR2Kkq2jMpZ8ZTrHX3979fXTx/OT0z8+nZ/93/NXf//Pqy9f3/3r7PT85MPb3z/+9u/J"
    "jN9+evvbv798/HLy5fzzx9Pzyd7nt3w5+++vZ59Oz179vbPj/J+Pn95PH/nHT69/+cf/+vnXk1/+63/+8P0bBti8"
    "+uuv6dumY3w9Pf/6+ezkj///7PPnj+/PvvClm5dPf3v78ffpyL+//XT+8fTky+k/px9Pfv/45fe356f/PPn46c+v"
    "LPPND6+///HkH29+/uW7SzNFnnimwfZUCJ9vcPEsscPqeuVrZcGEg0g3NFjvdVYkzHCv2dnwFFVZN+9Ar6qKx6aq"
    "dhFLDRZ2saFciRVV43pH9vXzrj5oFgaCUY+WzV4+c/MhfL5Pz6mr7rWNmy3xqJXLn0E72e1ut+1uR8aVPoFKq1ve"
    "81reHo8pfZA2o9vZ89rZ3ukgPpMSm9vh7trhjkTZJ9J8csu7xfKOXWXpxXRe3CJ33yJ3xCc+m6KE2+Tz2+Qe5yRP"
    "wCN3C3x+C9xLzvaLsEbdOnfdOnckYj8TP83t8V759J50Nh6fk+L28jj2sjNe5snx724xt6AD9nfX/qio15sQppcR"
    "JovQpsFwwsUmjqSNgv3IfJGiyVeaHgIOmAlfVXrECaxSAUncG3Ks1mDTHTUXUkjkMYkZCCKpaqrW9PrRYR4398es"
    "j6fwifCOl5+cl8E3bmOt7oluhIGaTYl6MCUcEIlJetUdFhbhuGr2muYEgXuumhvdQ8DKHBfUOoieYLqoyew0M3un"
    "h3uleQx1xrQ7uvHh6EbupDhy1bjPmrAndGIFuQjIEVx6MT0NzTEapfAEVnFmWDccajCEI+wE9JN641qjrWGfwR5a"
    "TjOtL0wre0/EnfKY0uVyBdm4sdrvfnz906/fv7kEEtzasCx75K6BvNpDX5WYNXPSY97cwlbD8G7H3QFZixiySCsS"
    "kzfBRRy4wliyoYeM5OVBgJRuxq4LiiiXPTpB0u42ZEr09mjD1iVxEjeyWHefW+LBuaBgJIwmt8DWJDomMxmmnxrI"
    "tJ9++tA2RJNhJX7X/g6lzK9cBHH7DoE0p8ewBdHpvvR14K5cAMpvdW/Qw7qtVm3B0ZV+tLNgi7D1/uaGm/vMl953"
    "bWt2YUg4y3epm8L0TNkPD/q8NhQX5723VnN9A9UcDLDHSPliGxz74tf9xtVu0Ud2BpZ6+2oXiEUAALdxqcDHbYSc"
    "bQqjBsMih6EhD1HDK2YBOo10Zd0aF6uxRi38BugCIh30osqxTYwbcdnxG2u/BfJ603sdJr37MGk8dX/Nx4Y5nbnb"
    "N8irqzTAe9IyCzdZ+8p5Zw3jghg5QnERPTKIXk8iIzp+uw7ZZPD7Ko85sO2oEDE6CBkiig7sJpskQLZBYaNodTVd"
    "oqS1rVQjI6elkKHbt8fbZIMbjn69pLLsSIeakK2BbG0napfs7Wq6du2YtydVy1K7BjjKZsm3Pi/Xt6n3za9GTfKR"
    "pjd6FhVTT8ZBKkxU7TSlTrt0Tf2mTiCHPlapB0l3NFbNRNLEbSlqS98uSIe1ai5ee1ScPXa4+VVRnZO1pmtZlriP"
    "MLxOfvnh9U+X8qwbCyX7UCi4beU37saJGuyVAwTumX6ZtNNC/kX7K8l5JT06SBbHNN9AohUjXEYdhZ0XcZ6BMKmW"
    "jfxx5SoRlW5c79XIuvOO49vrv7UdcKP7uJQ7XhTAFseCO9dybRw0+VcluyqS+0RaSCN7JLAWkRtlKPUsGMfepOdB"
    "5BGHlNshfc3V59EtSD2I9jnLC/WSJEJgKG2u4BMQH2ehgNaCxsFdFu5w8qOTH3eE/LhcPoQW3VnuTVw2lNKqV432"
    "wfEJyc3YqWK1byjexnNq5ctQK59CQNlt2emaL0PXdGt2Cui+UkDddp1Weqi0Urdtp6oeDlXVrdnpr4dPf3Urd0rt"
    "MVBq3c6dpnt4NF23aqf+Hhf11y3e6cSHTid2G3eK8ktTlB9/jIZboJOeX3rol9ug06ifd3jQFpPhGwi4RWytakhV"
    "jQ9n/B8/DXByjJwF6hKsH+jXArcmCceagO/a4I7IIA8bEsKRRkZcCVuqsSGRAR9Z+FcfSDPfwwMmaF8DYT+Epf2S"
    "2HNnERwMi+DSDJpwCbrZ2AVntzAJ5ilKTiNwGoHTCA6CRuC0AacNrKYN+OTfA9wT3Dn5txWZl0/+TUSJyNTfwKzU"
    "ZAIImmSrWcCVWasjCljN+gmd+NKOqJSZ1Ndxxp3m/hJ1omb36fqgkZWTTQ0mkesWT/5Ny6a374qEwyFQdh5j+q8X"
    "nZz0c6Wk71HpOKNSWBGVBuKQdtbkPcwCz+REWdqKkiXBu9caLBuK7O9KlbevNi1cgk46N813bVcA4SZ2fioi9po4"
    "vtVcuDsqtVV3CyfSj4qL7Rpy3dkxWjlT2W9RHLbyZmI/aSJTZkMtDrVJ86kWm1WPFBbFzk5RrMXddr0473Z3Bq5R"
    "2m/KncciJ+09SnPPo89xRp+4PPq0nIDKZaqaKM/S8daDVUBbrjRQOepZubKdAd+semjzwtUm0Mckrx9UPbSaY1Um"
    "Rf1N08erZtQvjj6tkrUo+nxjEvfe0lbvHxGaaJTHAqe8ejw44niQVmQjPfv80XIQVXSVPVD3YRXZzm5EIb6y0sRv"
    "2559XmM7+5HuS0dVrKd7M6jXQFxI5CctJlA5a3FkTTxYWCOr5FSjMgTypWSdkCwte7TvqYYre1BHzoAWyjIKtcGe"
    "LAQ9e3otOuNKna+kbB0pbIqOS5Kv30+6uWchTlh/YsK6x6PjjEd5RTzqqjrUlUgS1Km0Xn7VO03gPM1dC86F/iYe"
    "fpizImpMyc5opDJlfaBm7g1rAIJC+Y3642FFdSwtro4NdNgH7nVO6rsoWra10alN6tD06kTpDtLtycTjQHUta4KL"
    "rozdp6yOrX1+sDNJVN4Sx8n7LxfhsckFJ7w65tHnXtGnrEIMRPu2mDT/Crl3uigdHrmzdRZqX5E4MFomkavg2JyZ"
    "VqtOOtEIFNaMJwRlmEC3Fau+jSuiT4t1w6NXx/ZIcuUBFbLsscDlWrx77xFi86eu6J9UVqYqkGYg6rsDWEvReITE"
    "ihpFQllprMEQaJX6WKCT0uIKvZGq6YzRdvUjCMvMDl5VrAQaq98gsJblJ2FhfiI0eWGWY6Yr1LPWYmiDAJ7cEAbk"
    "Z8pZBusQCUcXqJ8V3leoJY6GSZgRx4kcCGTxZgJlt9nzHZRYkmcsLrfkmYvHpQfFpX4VqqwngiTruPTqydDNoNuR"
    "lJmMvBJrsl59u6otVoG6wuNXeiKD8YLw8rCOGmJa5xttiGBHz6hxDtb19eOjZy57LTj2gFymepRwsTLv+B99pBhW"
    "RIqoYa1wWipjYROMMb0uXutINBlgCxZqXgPxQZzTAQaJEF/qoxSiQyBuJBBh1LlABKdUbGAs37E4UuSl/RXxPMm8"
    "xNyB5Wg4NvV7tGYwAFWrqjbatsUwev2Wy8Gt4U8CpyCRhaB4yl0d+G2E19t6NcNhCQV65uJSg88kNejR6jij1bgi"
    "WhkCza5cNfYl/1SN+Q3wkjt6NqN1w6k6kfWofqZqVabmhEKAYhkxLVPbMn8PDqxWcSv7WR5nYb1tWFhvI+7WaHoO"
    "dT4vMHSKvwOr7I2pOgiaBp8Tvj74tIxmQ2a1yQayD/yuzDxUsrnMXaoX6LVDE/r0iOVSoV5p84h074gUVqkKBFiV"
    "WXjhWZ7N1tihnDPQ58gbhDBYAs40cv6Jc+1MT6ioZ8I16MCJVfDYSdhi8peMx2/5S1xVaQuPXmnbY7HcB9TZRo8Q"
    "eyy06179OL36OlZ+thwiav9vumoFjFYU29E4k9XUyvpkUm/0SaSWJXFNacYFS1OKIZjBGHPkkSgQwSHz3lWs/H6x"
    "WgxdHs6BqhwaN4pFnbgvdPZ19jPKOhgjXwi2QB6lemEkZvXCr9EFkqIYajrNFtrZ2z2azvaQZK49xzgyoWyPGccZ"
    "M1Zw6ckDRgLA3CNRzyHhDavpMqr6hJKl8Qmp5QgJ1foJwhETSQrIr4GfTI+LK9aZhmdnei5hVcxolab6BJnAHkrF"
    "P4RZ79z6PRSadz9+nH58BQfeqjT0slGMlNaztJp7ieXbHnoQVlZYVukqwgMR+rU3pgdKVvDGpa8iRG+syis6PPwI"
    "+rXtueMKnci6tCPOFVWHQcx8seLzBpMcUGEWugvM12YnX20Xn+GzKFdQPlSkMMlV6siSRkMpd6Y2WcVYPIwhD4+x"
    "59eYiHuMhcjgrCO1Q6meSWc8W8dKyHD6RSpE8vRJlUe6oJEOUTDOktAR6HpL7TdJP055aF/DXMxEDThsrueFB9m6"
    "nvPIhL2YFnDNC26pdV9El93xbj6Qw+7PwQ/kmGcZ3HcaB/Um2CQa+DKjdztykCBFdjrosc6egzkCMOMrbPKCrauG"
    "FVBzKepFSxvMOCDom5jq4mjYp+LTOA50GoeiYuujjCVfmcPx199efTn//PX0/Ovns5M/f3v76eTz108nH9+f/P7x"
    "y+9vz0//efLx059fz1/9/T+v3vzw+vsfT/7x5udfvrs0ruOJRwhsD2HwcQI+TmDROIFnkTT38oFLhq+fAvpw0WK3"
    "O5cHfhlxVLc8FyN9DkFEtzOXHvwm1eCZxM/cDo9eZuyFRJbc8lzU6F75xZPJqrhFuoDJQht8NvkGt0mXS1iRkzwB"
    "Zdst0MnRi8jRL0LPdOt0IuQu0cDcHveYdvUCxA+3l70iWewAxNwtZu8g3c8KK70JwnkZYbIIzhkY5JE0wAMSxyyA"
    "O9qQ9s7IeRruPgDakQR9p7FVBgjtAd8yJlhgHmR7NTYkAN8VuCuCuQhIY4WjAxVu7o9ZH0/hAQMKt7FW94UTRmQM"
    "BCUeDPY3JA1jDlhdBlRuIwwMJi9gMkI1SNdUCE8iK/XIF/QMBBXvSXaaq4ZC5yRrZwCbwwkfDU4YDMI5y5LPf2eI"
    "Ch1X3uS6NQgWyD8D7ySkJ18Dea3daUnf4WmSbGaEODDiXRjHXSVu3jef1nKaaX1hWtl7Iu6Ux5QulytQwo3Vfvfj"
    "659+/f7NJZDg1oZl2SN3DeTVHvqqxKyZkx7z5ha2GoZLtJoynJAMdj7A9A6oJhabvT4mhbGkOSE8QNEupT5vc85N"
    "cXC0RydUTVoMpt3UAYDrbC46Kr0bDvXd55Z4cC44DgmjyS2wNSWMyUyG6aeG6uynnz60DdFkWInftb9DKfMrF0Hc"
    "vkMgzekxbEF0ui99HbgrF4jtW90b/Ktuq1VbcHSlH+0s2CJsvb+54eY+86X3XduaXRgSzvJd6qYwPesKhwd9XhuK"
    "i/PeW6u5voFqDgbYY6R8sQ2OffHrfuNqt/gZOwNLvX21SxQZsjnWdqfE0+lAdyebGoH+AsoTYlRF02SQpQzguxPr"
    "1hy5ANvMJuERkOM8dWiefMrmE227b6z9FsjrTe91mPTuw6Tx1P01HxvmdOZu3yCvrtIA70nLLNw4KNJmzPAoM7qE"
    "I0wzbScCiUuyGfGRtCXJ29Vo2sLF1HvFo+yY11vZbjKTyziLHTpXIzzMoaZLnK+2lWps37QUMnT79nibbHDD0a+X"
    "VJYd6VATsjWQre1E7ZK9XU3Xrh3z9qRqWWrXAEfZLPnW5+X6NvW++dUIfbMgqj1AyqyYOpkTjkN0rhH3UW28J8IR"
    "kH+GWU5OGRYbjETIl2xpb1I+CJyK7ClpbMmLen51sPlVUZ2TtaZrWZbIhq9//f7nn05++eH1T5fyrBsLJftQKLht"
    "5TfuxpNp7Q6mFJ+siCaNL+ZzJe2v4NvZbBTmpXAk8e2IVnArRx3FZqRkU/dKaBPDsa6asUJUunG9VyPrzjuOb6//"
    "1nbAs8WHO9d3XfGtmOoO+jycbUnahdQq7c6I+jLsV+NlVvYrvc2LZtKATTcbdUdsOmjPAx6xuqLPVCnEsebNVX0C"
    "MuTMzm9taZzeZbUMJ0Q6IXJHCJHLNTto253l3nRdQymtotWoIByfMN2MncpW+4birT2nW74M3fIptIvdlp3C+TIU"
    "Trdmp4XuKy3UbdeppodKNXXbdvrq4dBX3ZqdEnv4lFi3cqfZHgPN1u3cqbuHR911q3Y68HHRgd3inWJ86BRjt3Gn"
    "Lb80bfnxZ1e4BToR+qVnbbkNOrX6eSf2bLEbvoGAW8TgqoZeHcCfFqY7RfCX4/bcb1CWvbB9DewLdrS3CUtBZG0Q"
    "fxFUaNJMKTgLcYM37YUU06QpYWLvJGzHl/3zDFNg7B4e/BSYLWD2fZkFL41Hd2bBwTALLg2CCZegm41xcHYLu2Ae"
    "ZeTUAqcWOLXgYKkFTiVwKsFqKoGP4D3AfcKdI3hb4Xn5KPVE5GjeL0H6DqRRrI84mbDhZvgapptRzCKc4ks7IhWj"
    "Dvm5iBxO1FSEz4ytLYxMLYxG7UnBWnLXrRjBWxaO4N0JqYdDoPE8xhheL0Q5EehKmd+j0nFGpbAiKg3EIe2syYUY"
    "357Jk7I0GCVfgnfXsPSg3TnqjPL2bT+k8+uVf/LpPkkEBYEndn4qLPb8rttqONwdldqqu2VxiV0md4nY2GvHaCVO"
    "ZcRFcdhKnon9pIlRmQ0x4J67pMw8cs8KBdBOUSxpaHlvQ4MTuW23GM6wozQ8j0VO5HuUhp9Hn+OMPnF59Gk5AdVM"
    "1qpx7OatB6uKtlxpoHLUUytUtjPgm1UjbV64Uj1omY+8flBF0eqQVZkUNbmERnElEuTF0adVshZFn29M7N5bKuv9"
    "I0ITl/JY4DRYjwdHHA/Simyk51tHy0FU0VX2QN2H/XeLAZGMJBIXOrx5UE2ora2dBXFhpCPTURXr6egM6jUQFxL5"
    "SYsJVM5aHFkTDxbWyCo51agMgXwpWSckS/MejXyq4coe1KUz8IWyjML968lC0L2n16IzrtT5SsrWpcKm6Lgk+fr9"
    "pKB7FuIk9icmsXs8Os54lFfEo66qQ12JJEGdSuvvV73ThNDT3LWg4kR/Ew8/zFkRNSblOfLUde4DNXNv+ANQFcpv"
    "1B8PK6pjaXF1bKDDPnCvc1LfRdGyrY1ObVKHRlc+M3ul0O3JxGPd5axJL7oynElPJKICyecHO5NE5S1xnLz/EhIe"
    "m1yEwqtjHn3uFX3KKsRAxH8236s5WcjC00Xp8Mgd64yg2zQco+UUyiRyFUR7pN5FXqROOtEIFNaMMQR5mEC8Fau+"
    "jSuiT4t1w6NXx/ZIhuUBFbLsscAlXLx77xFi86eu6J9Usg1VgTQrUfFC5yVqj5BYUSNLKCuNNRgCrXLWgU5Kiyv0"
    "RqqmOEbb1Y8gLDM7eFWxEmfVbxBYy/KTsDA/EcK8MPMx0xXqWWsxtEEAY24IA+6HcpbBOkTC0dld5H2FezcaJmFG"
    "HCdyIJDFm0mV3WbPd1ACSp6xuASTZy4elx4Ul/pVqLKeCJKs49KrJ0M3g25HUmYy8kqsyXr17aq2WAXqCo9f6YkM"
    "xhXCy8NEaojpTIck2rDBjp5R4xys6+vHR89c9lqE7AG5TPUo4QJm3vE/+kgxrIgUUUNd4bRUxscmGGN6XVzXkWgy"
    "wBYs1LwG4oN4qAMMEiG+1EcpRIdA3EggwqhzgQhOqdhg2XpB8l8QKfLS/oq4n2ReYu7AcjQcm/o9WjMYgKpVVRuB"
    "22IYvX7L5eDW8CeBU5DwQlA8BREw8NsI17f1aobDEg/0zMXlB59JftCj1XFGq3FFtDIEml25auxL/qkaBxzgJXf0"
    "bEbrhlN1IutR/UzVqkzNCdUAxTJiWqa2Zf4eHFit4lb2s2TOwnrbsLDeRtyt0TQe6nxeYOgUfwdW2RtTdRA0DT4n"
    "fH3waRkdh8xqkw1uH/hdmXmoWEKmE1Uv0GuHJv7pEcvlQ73S5hHp3hEprFIVCHxjFl54lmyr0tXpUNMZ6HPkDUIY"
    "LAEszkgOlKjFdaYxVNQzobPUgROr4LGTsMXkLznp2jCLfkWlLTx6pW2PBXQfUGcbPULssfiue/Xj9OrrWPnZcoio"
    "/b9prRUwWlFsR+NMVlMw65PJv9EnkVqWBDelIxcsTSmGYAZjzJFHokAEh8x7V7Hy+8VqMXR5OAeqcmjcKBZ14r7Q"
    "2dfZzyjrYIx8IdgCeZTqhZGY1Qu/RhdIimKo6bReP/c4z5XDQ5K+9hzjyMSzPWYcZ8xYwaXn+0YCwNwjUc8h4Q2r"
    "6TKq+oS6pfEJqeUICdX6CcIRE0kKyK+Bn0yPq60WrUwpj0rPJayKGa3SVJ8gE9hD+fiHMOudW7+H4vPux4/Tj6/g"
    "wFuVhl42ipHSf5Z+cy8BfdtDD8LKCssqXUV4IEK/9sb0QMkK3rj0VYTojVV5RYeHH0G/tj13XKETWZd2xOl7q8Mg"
    "Zr5Y8XmDSQ4oMwvdBeZrs5OvtovP8FmUKygfKlKY5Cp1ZEmjoZQ7U5usYiwexuCHx9jza3TEPUZF9MKIm7qO1HSq"
    "bGzOzUDjSakhsktIXP0KGmM0VpI0DII9SYGeUYC/FHgO9amxChdSzVLL5npeeJCt6zmPUdiLCQLXvODWoIWL6LI7"
    "3u2uIR0vHVeefkiH3Z+DH9Ixzze474SOYkpcyicK+UbEk9O9xkP05p87+QesUkeJvF/jY0Y8w8xZGahxdcZbV7dc"
    "SpWyfOGrfELHoU7oUFRsfZSx5CuzOf7626sv55+/np5//Xx28ufnsz/ffj57f/L108fzk4/vT37/+OX3t+en/zz5"
    "+OnPr+ev/v6fV29+eP39jyf/ePPzL99dmuPxxHMEticx+EwBnymwaKbAs+iaew3BdcPXjwd9uHKx251rBL+MQqpb"
    "niuSPocqotuZ6w9+k2/wTApobodHrzX2QkpLbnmubHSv/OLJtFXcIl3FZKENPpuGg9ukayasyEmegLftFugM6UUM"
    "6RfhaLp1Ohtyl7hgbo97zL16AfaH28teMS12AGfuFrN3uO5nxZbehOO8jDBZhOkMQvFoigdMjlkFd7RJ7Z0x9DTh"
    "fQAPJB36TrOrhPMBydlpVjCvgfSpmh0SwPCi+QFHDyxw3aByjwhZuLk/Zn08hQeMKtzGWt0XUxjRMmB2DNyjYFNB"
    "Y5LSToeFxXmOgWHlE1NtUKtBv6bCehJjqUfDoGcqqMhPstNcNRk6J1k7U9gcU/hYmMIqTho+Z56tDZJwkMAR2EDm"
    "Z3MHO5vRV8FtMZ1bSoBVOPQAkrRNey3Gk9bs12YH7W8JnRtmtH1vy2mm9YVpZe+JuFMeU7pcruAJN1b73Y+vf/r1"
    "+zeXQIJbG5Zlj9w1kFd76KsSs2ZOesybW9hqGC4RbMoQQzK0iQAgPyCdWGwA+5gUxpKGhfAARYNn6vM27NxkB0d7"
    "dELVuMVgAk4dALjOhqMj1bshUt99bokH54LokDCa3AJbk8OYzGSYfmrQzn766UPbEE2Glfhd+zuUMr9yEcTtOwTS"
    "nB7DFkSn+9LXgbtyAdu+1b1Bwuq2WrUFR1f60c6CLcLW+5sbbu4zX3rfta3ZhSHhLN+lbgrTs7hweNDntaG4OO+9"
    "tZrrG6jmGoA9RsoX2+DYF7/uN652i6SxM7DU21e7RJYhG1i73ametTTKWm+bwsgaCsQe0aqiCTPIUgZGLCTWrWFy"
    "cvA2Dg93HufRQ/P4UwIBAnffWPstkNeb3usw6d2HSeOp+2s+NszpzN2+QV5dpQHek5ZZuMnIS6AxQ6bMiBOOyJ6I"
    "ohBIXJINio+kLUnerkYTGC4m4SsyZcfQ3sp2k8FcRlzsELsa2ZQMNV0ifrWtVKP8pqWQodu3x9tkgxuOfr2ksuxI"
    "h5qQrYFsbSdql+ztarp27Zi3J1XLUrsGOMpmybc+L9e3qffNr0YmRxeUtQd26BVTJ3MSywpl7hH3UW3GJ+oRKMQN"
    "s6acMiw2GImQL+3S3vR8UDnl81L1ydIY9fzqYPOrojona03XsiwxDl//+v3PP5388sPrny7lWTcWSvahUHDbym/c"
    "jScT3B1MLj5ZEU1CXwzpStpfQYW2ASkMTeFIUOEVrbixo45ig1KySXwlbnKAeK9BK0SlG9d7NbLuvOP49vpvbQc8"
    "W3y4c33XZd+KSe8g0sPZlqRdSK0S8Iz26EYNi4MkGzTO0x7jshlxNuqO2IjQnn1+xOqKPlMlE8eaN1f1CciQM0W/"
    "taVxepclM5wQ6YTIHSFELhfuoG13lnsTdw2ltIpWo4JwfMJ0M3YqW+0birf2nG75MnTLpxAwdlt2CufLUDjdmp0W"
    "uq+0ULddp5oeKtXUbdvpq4dDX3Vrdkrs4VNi3cqdZnsMNFu3c6fuHh51163a6cDHRQd2i3eK8aFTjN3Gnbb80rTl"
    "xx9g4RboROiXHrjlNujU6ucd27PFbvgGAm4Rg6saenUAf1oYvxPBX47bw79BWfbC9jFSxwbvgK8MImuD+IugQpMG"
    "S8FZiBu8aS+kmMZNCRPro2Dme3jwo2C2gNn3ZBa8OB7dmQUHwyy4NA0mXIJuNsbB2S3sgnmekVMLnFrg1IKDpRY4"
    "lcCpBKupBD6H9wD3CXfO4W2F5+Xz1JlMiPdLkL4DaRRT7YiTCRtup6aJuhnFLK1rJEIVpWD2cxE5nHNWhM9ci3Ze"
    "I88TQgxEqLJinnoyANSeSD0cAo3nMWbxeiHKiUBXyvwelY4zKoUVUWkgDmlnrSm4vcUVXk0SZJK0SZc0MT1od446"
    "o7x92w9pVmuv/JNP90kiKAg8sfNTYbHnd91Ww+HuqNRW3S2LS+wymTjLle+1Y7QSpzLiojhsJc+kOyMxKrMhu7fN"
    "UsjMI3GuUADtFMWYT5w0b5Z8lvu+GM6wozQ8j0VO5HuUhp9Hn+OMPnF59Gk5ASti6jdRKJm3Hqwq2nKlgcpRT61Q"
    "2c6Ab1aNVFPiM/XUmOT1gyqKVoesyqSoySU0iivnnRdHn1bJWhR9vjGxe2+prPePCE1cymOB02A9HhxxPEgrspGe"
    "ff5oOYgqusoeqPuw/24xIJKRROJCx6qCakKtJ9F6EcSFkY5Mx9n3dHQG9Rq4Con8pMUEKmctjqyJBwtrZJWcalSG"
    "QL6UrBOSpXmPRj7VcGUP6tIZ+EJZRqE22JOFoHtPr0VnXKnzlZStS4VN0XFJ8vX7SUH3LMRJ7E9MYvd4dJzxKK+I"
    "R11Vh7oSSYI6ldbfr3qnCaGnuWtBxYn+Jh5+mLMizk95jjx1nftA7UTatQBVofxG/fGwojqWFlfHuFrT39l6RK3v"
    "omjZ1kanNqlD06sTxeyVQrcnE48DdyNr0ouuDGfSE4moQPL5wc4kUXlLHCfvv4SExyYXofDqmEefe0WfsgoxEPGf"
    "7bs1JwtZeLooHR6542wi6DYNx2g5hTKJXAXRHql3kRepk040AoU1YwxBHiYQb8Wqb+OK6NNi3fDo1bE9kmF5QIUs"
    "eyxwCRfv3nuE2PypK/onlWxDVSDNSlS8CGAtRe0REitqZAllpbEGQ6BV6mOcDQOb6I1UTXGMtqsfQVhmdvCqYiXQ"
    "WP0GgbUsPwkL8xMhzAszHzNdoZ61FkMbBDDmhjAgP1POMliHSDi6QP2s8L5CLXE0TMKMOE7kQCCLN5Mqu82e76AE"
    "lDxjcQkmz1w8Lj0oLvWrUGU9ESRZx6VXT4ZuBt2OpMxk5JVmO+rVt/W0WAXqCo9f6YkMxhXCy8NEaojpTIck2rDB"
    "jp5R4xys6+vHR89c9lqE7AG5TPUo4QJm3vE/+kgxrIgUUUNd4bRUxscmGGN6XVzXkWgywBbU+Q/EB/FQBxgkQnyp"
    "j1KIDoG4kThz6lwgglMqNliW71gcKfLS/oq4n2ReYu7AcjQcm/o9WjMYgKpVVRuB22IYvX7L5eDW8CeBU5DwQlA8"
    "BREw8NsI17f1aobDEg/0zMXlB59JftCj1XFGq3FFtDIEml25auxL/qkaBxzgJWt1o3XDqTqR9ah+pmpVpuaEaoBi"
    "GTEtU9syfw8OrFZxK/tZMmdhvW1YWG8j7tZoGg91Pi8wdIq/A6vsjak6CJoGnxO+Pvi0jI5D1m21we0DvyszD5Vs"
    "LtOJqhfotUMT//SI5fKhXmnziHTviBRWqQoEWJVZeOFZsq1KV6dDTWegz5E3CGGwBLA4IzlQ4jw60xgq6pnQWerA"
    "iVXw2EnYYvKXjMdv+UtcVWkLj15p22MB3QfU2UaPEHssvute/Ti9+jpWfrZvjtr/m9ZaAaMVxXY0zmS1lfXJ5N/o"
    "k0gtS4Kb0pELlqYUQzCDMebII1EggkPmvatY+f1itRi6PJwDVTk0bhSLOnFf6Ozr7GeUdTBGvhBsgTxK9cJIzOqF"
    "X6MLJEUx1HRar7+dPZGQyuEhSV97jnFk4tkeM44zZqzg0pMHjHzP3CNRzyHhDavpMqr6hLql8Qmp5QgJ1foJwhET"
    "SQrIr4GfTI+LtXem69mZnktYFTNapak+QSawh/LxD2HWO7d+D8Xn3Y8fpx9fwYG3Kg29bBQjpf8s/eZeAvq2hx6E"
    "lRWWVbqKrFbo196YHlwTeOPSVxGiN1blFR0efgT92q5TXKETWZd2xOl7q8MgZr5Y8XmDSebOVKG7wHxtdvLVdvEZ"
    "PotyBeVDRQqTXKWOWz0aSrkztckqxuJhDH54jD2/RkfcZ1SEMZGi9hcz5s7Uxs2aLB9FZQEMeTK1TrJO8tcBLHcG"
    "9zegIBdM8xwdUamYC9dhOW47TLe5nhceZOt6zmMU9mKCwDUvuDVo4SK6XHi3F/6fD+mY78/BD+mY5xvcc0IHz4Z4"
    "iF2dexJ0uImAo6n3FlNwj2LB4zMSzMZSxUFJtVj/eATVO5hK/GB4Ymo7KKqAB5bCsE/oONgJHYqKrY8ylnxlNsdf"
    "f3v15fzz19Pzr5/PTr58ffevs9Pzky9n//317NPp2cnvH7/8/vb89J8nHz/9+fX81d//8+rND6+///HkH29+/uW7"
    "S3M8nniOwPYkBp8p4DMFFs0UeBZdc68huG74+vGgD1cudrtzjeCXUUh1y3NF0udQRXQ7c/3Bb/INnkkBze3w6LXG"
    "XkhpyS3PlY3ulV88mbaKW6SrmCy0wWfTcHCbdM2EFTnJE/C23QKdIb2IIf0iHE23TmdD7hIXzO1xj7lXL8D+cHvZ"
    "K6bFDuDM3WL2Dtf9rNjSm3CclxEmizCd4HvgdSeb1z6r4I42qb0zhp4mvLdpjKFKh77T7CrwE8xt55VapUEc0O7V"
    "7JAAhjcITAjmIoAqCkeHLNzcH7M+nsIDRhVuY63uiymMaBkwOwaEYLCpoDFVww1nkOU2x8Cw8ompNqjVgESrsJ7E"
    "WOpnlLGRZZPZaa6aDJ2TrJ0pbI4pPBxM4bSy08m7jvk9EXfKY0qXyxU84cZqv/vx9U+/fv/mEkhwa8Oy7JG7BvJq"
    "D31VYtbMSY95cwtbDcMlgk0ZYkiGNhEA3QakE4sNYB+TwljSsBAeIOh9PAadGfssEtIh41QNil90iwDgCnTb2XB0"
    "pHo3ROq7zy3x4FwQHRJGk1tga3IYk5kM008N2tlPP31oG6LJsBK/a3+HUuZXLoK4fYdAmtNj2ILodF/6OnBXLmDb"
    "t7o3SFjdVqu24OhKP9pZsEXYen9zw8195kvvu7Y1uzAknOW71E1hehYXDg/6vDYUF+e9t1ZzfQPVXAOwx0j5Yhsc"
    "++LX/cbVbpE0dgaWevtql8gyZJFvIFf1rKUB9nvbFELSMfqOaFXRhBlkKQMjFhLr1jA5OXgbh4c7j/PooXn8KYEA"
    "gbtvrP0WyOtN73WY9O7DpPHU/TUfG+Z05m7fIK+u0gDvScss3GTkJdCYIVNmxAlHZE/apiNj4/JeCXmRkT0E3q5G"
    "ExguJuErMmXH0N7KdpPBXEZc7BC7GtmUDDVdIn61rVSj/KalkKHbt8fbZIMbjn69pLLsSIeakK2BbG0napfs7Wq6"
    "du2YtydVy1K7BjjKZsm3Pi/Xt6n3za9GJkcXGFYDO/SKqZM54TgSytwj7qPajE/UI1CIG2ZNOWVYbDASIV/apb3p"
    "+aByyuel6pOlMer51cHmV0V1TtaarmVZYhy+/vX7n386+eWH1z9dyrNuLJTsQ6HgtpXfuBtPJrg7mFx8siKahL4Y"
    "0pW0v4pVMi2DldYkvgIVXtGKGzvqKDYoJZvEV+ImB4j3GrRCVLpxvVcj6847jm+v/9Z2wLPFhzvXd132rZj0DiI9"
    "nG1J2oXUKgHPaI9u1LA4JN6CxnnaY1w2I85G3REbEdqzz49YXdFnqmTiRMmdr+oTkCFnin5rS+P0LktmOCHSCZE7"
    "QohcLtxB2+4s9ybuGkppFa1GBeH4hOlm7FS22jcUb+053fJl6JZPIWDstuwUzpehcLo1Oy10X2mhbrtONT1Uqqnb"
    "ttNXD4e+6tbslNjDp8S6lTvN9hhotm7nTt09POquW7XTgY+LDuwW7xTjQ6cYu407bfmlacuPP8DCLdCJ0C89cMtt"
    "0KnVzzu2Z4vd8A0E3LIhPIZeHcCfFkY8RfCX4/bwb1CWvbB9jdwNdrS3MUtBZG0QfxFUaNJgKTgLcYM37YUU07gp"
    "YWJ9FMx8Dw9+FMwWMPuezIIdmbbkzIJDmwYTLkE3G+Pg7BZ2wTzPyKkFTi1wasHBUgucSuBUgtVUAp/De4xzeFvh"
    "efk89UTkaN4vQfoOpFGRvcAor2axTxN1M4pZWtdIhCpKweznInI456wIn7kW7bxGnieEGIhQZcU89WQAqD2RejgE"
    "Gs9jzOL1QpQTga6U+T0qHWdUCiui0kAc0s6aXIgZ7pmzzNJglHwJ3l0T04N256gzytu3/VAlq+uVf/LpPkkEBYEn"
    "dn4qLPb8rttqONwdldqqu2VxiV1mx4oK0Y8do5U4lREXxWEreSbdGYlRmQ3ZvW2WQmYeiXOFAminKNbibrtenHfL"
    "Z7nvi+EMO0rD81jkRL5Hafh59DnO6BOXR5+WE7CixNz2rJ4T3nqwqmjLlQYqRz21QmU7A75ZNdLmhSvVA62+4p2p"
    "KFodsiqToiaX0CiunHdeHH1aJWtR9PnGxO69pbLePyI0cSmPBU6D9XhwxPEgrchGevb5o+Ugqugqe6Duw/67xYBI"
    "RhKJCx2rCqoJtZ5E60UQF0Y6Mh1n39PRGdRr4Cok8pMWE6ictTiyJh4srJFVcqpRGQL5UrJOSJbmPRr5VMOVPahL"
    "Z+ALZRmF2mBPFoLuPb0WnXGlzldSti4VNkXHJcnX7ycF3bMQJ7E/MYnd49FxxqO8Ih51VR3qSiQJ6lRaf7/qnSaE"
    "nuauBRUn+pt4+GHOijg/5Tny1HXuA7UTadcCVIXyG/XHw4rqWFpcHeNqTX9n6xG1vouiZVsbndqkDk2vThSzVwrd"
    "nkw8DtyNrEkvujKcSU8kogLJ5wc7k0TlLXGcvP8SEh6bXITCq2Mefe4VfcoqxEDEf7bv1pwsZOHponR45I6ziaDb"
    "NByj5RTKJHIVRHuk3kVepE460QgU1owxBHmYQLwVq76NK6JPi3XDo1fH9kiG5QEVsuyxwCVcvHvvEWLzp67on1Sy"
    "DVWBNCtR8SKAtRS1R0isqJEllJXGGgyBVqmPcTYMbKI3UjXFMdqufgRhmdnBq4qVQGP1GwTWsvwkLMxPhDAvzHzM"
    "dIV61loMbRDAmBvCgPxMOctgHSLh6AL1s8L7CrXE0TAJM+I4kQOBLN5Mquw2e76DElDyjMUlmDxz8bj0oLjUr0KV"
    "9USQZB2XXj0Zuhl0O5Iyk5FXmu2oV9/W02IVqCs8fqUnMhhXCC8PE6khpjMdkmjDBjt6Ro1zsK6vHx89c9lrEbIH"
    "5DLVo4QLmHnH/+gjxbAiUkQNdYXTUhkfm2CM6XVxXUeiyQBbUOc/EB/EQx1gkAjxpT5KIToE4kbizKlzgQhOqdhg"
    "Wb5jcaTIS/sr4n6SeYm5A8vRcGzq92jNYACqVlVtBG6LYfT6LZeDW8OfBE5BwgtB8RREwMBvI1zf1qsZDks80DMX"
    "lx98JvlBj1bHGa3GFdHKEGh25aqxL/mnahxwgJes1Y3WDafqRNaj+pmqVZmaE6oBimXEtExty/w9OLBaxa3sZ8mc"
    "hfW2YWG9jbhbo2k81Pm8wNAp/g6ssjem6iBoGnxO+Prg0zI6Dlm31Qa3D/yuzDxUsrlMJ6peoNcOTfzTI5bLh3ql"
    "zSPSvSNSWKUqEGBVZuGFZ8m2Kl2dDjWdgT5H3iCEwRLA4ozkQInz6ExjqKhnQmepAydWwWMnYYvJXzIev+UvcVWl"
    "LTx6pW2PBXQfUGcbPULssfiue/Xj9OrrWPnZvjlq/29aawWMVhTb0TiT1VbWJ5N/o08itSwJbkpHLliaUgzBDMaY"
    "I49EgQgOmfeuYuX3i9Vi6PJwDlTl0LhRLOrEfaGzr7OfUdbBGPlCsAXyKNULIzGrF36NLpAUxVDTab3+dvZEQiqH"
    "hyR97TnGkYlne8w4zpixgktPHjDyPXOPRD2HhDespsuo6hPqlsYnpJYjJFTrJwhHTCQpIL8GfjI9Ltbema5nZ3ou"
    "YVXMaJWm+gSZwB7Kxz+EWe/c+j0Un3c/fpx+fAUH3qo09LJRjJT+s/Sbewno2x56EFZWWFbpKrJaoV97Y3pwTeCN"
    "S19FiN5YlVd0ePgR9Gu7TnGFTmRd2hGn760Og5j5YsXnDSaZO1OF7gLztdnJV9vFZ/gsyhWUDxUpTHKVOm71aCjl"
    "ztQmqxiLhzH44TH2/BodcZ9REcZEitpfzJg7Uxs3a7J8FJUFMOTJ1DrJOslfB7DcGdzfgIJcMM1zdESlYi5ch+W4"
    "7TDd5npeeJCt6zmPUdiLCQLXvODWoIWL6LI73s2HdNj92bEhHeHRh3TM8w3uOaHDFEekghhsZkAGzased7DhMWQe"
    "eIogf2D6iiM1KHUWiml+depEJ2GnVMvJptiIHzHN76Emn9BxoBM6FBVbH2Us+cpsjr/++uv/AclxTDk="
)

_extra_bundle_cache = {}


def _extra_bundle():
    if "v" not in _extra_bundle_cache:
        raw = _zlib.decompress(_b64.b64decode(_EXTRA_BUNDLE_B64_ZLIB))
        assert len(raw) == _EXTRA_BUNDLE_PINNED_RAW_LEN
        assert _hl.sha256(raw).hexdigest() == _EXTRA_BUNDLE_PINNED_SHA256
        _extra_bundle_cache["v"] = _json.loads(raw)
    return _extra_bundle_cache["v"]


# ======================================================================
# Base 14-row descriptor set (embedded literal, byte-identical to the
# pinned complete_snapshot_publication_unit descriptor_set and to
# valid_descriptor_set_one_partition) plus deterministic mutation
# constructors verified during authoring to reproduce every pinned
# descriptor-set mutation fixture exactly.
# ======================================================================

_PREP_OBJECTS_PREFIX = (
    "artifacts/local_curl_per_side/runs/" + _RUN_ID
    + "/prepared_evidence/SNAPSHOT_PUBLICATION/" + _STRUCTURAL_PREP_ID
    + "/objects/"
)
_CAPTURE_PREFIX = "artifacts/local_curl_per_side/runs/" + _RUN_ID + "/capture/"
_PARTITION_ID_BACA = (
    "part_baca56ed5f9d54828f86231ed320e5ffc0500f7ee74a3aafa92b4f1e82177d63"
)


def _base_row(ordinal, role, schema, mode, target, size, fsha, lsha, sidecar_of):
    return {
        "canonical_target_path": _CAPTURE_PREFIX + target,
        "content_schema_id": schema,
        "durable_source_path": _PREP_OBJECTS_PREFIX + str(ordinal).zfill(10) + ".bin",
        "file_sha256": fsha,
        "file_size_bytes": size,
        "logical_sha256": lsha,
        "object_ordinal": ordinal,
        "object_role": role,
        "publication_mode": mode,
        "sidecar_of_object_ordinal": sidecar_of,
    }


_BASE_DESCRIPTOR_ROWS = (
    _base_row(0, "PARTITION_PAYLOAD", "table:capture_events", "SINGLE_AUTHORITATIVE_FILE",
              "partitions/" + _PARTITION_ID_BACA + ".parquet", 35,
              "3a2b73a11c72dc923e86f194de03f39b05cdeb05e0d0e642dd0a529ed4726750",
              "b472da67c0017c932aae0b3d62e1abc68ac37ed27ad94c12a82d7f8a36b144d9", None),
    _base_row(1, "HISTORY_MANIFEST", "json:audit_snapshot_manifest", "ATOMIC_BUNDLE_MEMBER",
              "audit_snapshot_history/00000000000000000000/audit_snapshot_manifest.json", 120,
              "81c43f45c70d0c436a1b9c06a6172baea7c6efd87f3ac471e1540d5933747056",
              "9d0efe673aa7532275b733723afb24eaaad97dceb622dee30e1a64c7d8838c03", None),
    _base_row(2, "HISTORY_MANIFEST_SIDECAR", "json:sha256_sidecar", "ATOMIC_BUNDLE_MEMBER",
              "audit_snapshot_history/00000000000000000000/audit_snapshot_manifest.sha256", 290,
              "d6d73ba43c3aa8585ca8bf7e456487db3b64fd3525fe1e7c8e16e031dc13f324",
              None, 1),
    _base_row(3, "HISTORY_INDEX", "table:snapshot_partition", "ATOMIC_BUNDLE_MEMBER",
              "audit_snapshot_history/00000000000000000000/snapshot_partitions.parquet", 29,
              "712970d821540b14ee452b9bbf0f314d91fdfb69d100a76580798e371addd064",
              "f5c9883ea36bf439e49b8fc03769633aa653e7626fbf514d6d454a9e9de203de", None),
    _base_row(4, "PUBLICATION_MARKER", "json:snapshot_publication_commit_v23", "ATOMIC_BUNDLE_MEMBER",
              "audit_snapshot_history/00000000000000000000/PUBLICATION_COMMITTED.json", 130,
              "0e706d1131e8e1f25604a34c12678284380002afcba19e63a116609a05647fba",
              "8be8ded427b69ba5d51bc71945a5b441510ede3cd11a1745001bc847fc5335a4", None),
    _base_row(5, "PUBLICATION_MARKER_SIDECAR", "json:sha256_sidecar", "ATOMIC_BUNDLE_MEMBER",
              "audit_snapshot_history/00000000000000000000/PUBLICATION_COMMITTED.sha256", 288,
              "3b7feb2ad8f69305b0c0be522139fc04fc193f1fd7f802b773b3061c59eaa89a",
              None, 4),
    _base_row(6, "CURRENT_GENERATION_MANIFEST", "json:audit_snapshot_manifest", "ATOMIC_BUNDLE_MEMBER",
              "current_view_generations/00000000000000000000/audit_snapshot_manifest.json", 131,
              "f6746d1ee7feaf9c82932bf06c39aa11f101b3f913fa3e21a194f433883c8a79",
              "483e95da4711eea7ab6ac47e75d587e43e8133eac5d89c47700738db7c549f06", None),
    _base_row(7, "CURRENT_GENERATION_MANIFEST_SIDECAR", "json:sha256_sidecar", "ATOMIC_BUNDLE_MEMBER",
              "current_view_generations/00000000000000000000/audit_snapshot_manifest.sha256", 292,
              "87e238077dfba69b83199a62cc8e2ebbcebeef03894e587089243ab7f900d1cd",
              None, 6),
    _base_row(8, "CURRENT_GENERATION_INDEX", "table:snapshot_partition", "ATOMIC_BUNDLE_MEMBER",
              "current_view_generations/00000000000000000000/snapshot_partitions.parquet", 40,
              "2b21b06a4c56bb29d797e85750c8ebca0837ae7f09e9213835fcb3efc51da6bb",
              "e1d82639d57ca8a110832f4ceff40000ce7ee7bdaaacddc76a7df768aab4b948", None),
    _base_row(9, "CURRENT_GENERATION_MARKER", "json:snapshot_current_view_commit_v23", "ATOMIC_BUNDLE_MEMBER",
              "current_view_generations/00000000000000000000/CURRENT_VIEW_COMMITTED.json", 138,
              "4ee4aaaf0e63c6f8f1a90eb9500477b8883d58449ed1bcaebd6aacdd966f7c75",
              "06ab4806af0efb9d78ed7dc98c36d690b53d48d6f3da38b554726ef41ff14d6d", None),
    _base_row(10, "CURRENT_GENERATION_MARKER_SIDECAR", "json:sha256_sidecar", "ATOMIC_BUNDLE_MEMBER",
              "current_view_generations/00000000000000000000/CURRENT_VIEW_COMMITTED.sha256", 291,
              "1594633633cde401888dd4a9e22a6126bc3108345eacf60e8f973e9d11453bf2",
              None, 9),
    _base_row(11, "LEGACY_CURRENT_MANIFEST", "json:audit_snapshot_manifest", "DERIVED_VIEW_TARGET",
              "audit_snapshot_manifest.json", 127,
              "840eb26f730b559bd35ba465cb73f6ce53d3bf7230a63fee8e7fb739bc266230",
              "b3c85535f4dba60c03b6b8458e1aeaaf1fa7b21b2087306b7bd5392c4bfde857", None),
    _base_row(12, "LEGACY_CURRENT_MANIFEST_SIDECAR", "json:sha256_sidecar", "DERIVED_VIEW_TARGET",
              "audit_snapshot_manifest.sha256", 246,
              "599cf50c8ca8c2c6e6dcd5659626c6ddb768221f6e4f86e12a8ec09250933130",
              None, 11),
    _base_row(13, "LEGACY_CURRENT_INDEX", "table:snapshot_partition", "DERIVED_VIEW_TARGET",
              "snapshot_partitions.parquet", 36,
              "a9e7f0a2fa84a77f7455384837381ab528137802d976fd3c194bff70f899f58b",
              "ea12486b665c4f06c180e875f0d5396bfdd4fa60f73532a0a06f943303d66441", None),
)


def _rows_to_descriptors(rows):
    return tuple(
        PreparedObjectDescriptor(
            object_ordinal=r["object_ordinal"],
            object_role=PreparedObjectRole(r["object_role"]),
            content_schema_id=r["content_schema_id"],
            publication_mode=PublicationMode(r["publication_mode"]),
            durable_source_path=r["durable_source_path"],
            canonical_target_path=r["canonical_target_path"],
            file_size_bytes=r["file_size_bytes"],
            file_sha256=r["file_sha256"],
            logical_sha256=r["logical_sha256"],
            sidecar_of_object_ordinal=r["sidecar_of_object_ordinal"],
        )
        for r in rows
    )


def _repack_rows(rows):
    # Deterministic repack rule confirmed against the pinned mutation
    # fixtures: renumber object_ordinal to 0..n-1 in order, renumber
    # durable_source_path objects/NNNNNNNNNN.bin to the new ordinal, and
    # remap sidecar_of_object_ordinal through the old->new ordinal map.
    omap = {r["object_ordinal"]: i for i, r in enumerate(rows)}
    out = []
    for r in rows:
        r2 = _copy.deepcopy(r)
        new_ord = omap[r["object_ordinal"]]
        r2["object_ordinal"] = new_ord
        r2["durable_source_path"] = _PREP_OBJECTS_PREFIX + str(new_ord).zfill(10) + ".bin"
        if r2["sidecar_of_object_ordinal"] is not None:
            r2["sidecar_of_object_ordinal"] = omap[r2["sidecar_of_object_ordinal"]]
        out.append(r2)
    return out


def _snapshot_claim_one_partition_bytes() -> bytes:
    # Byte-identical to the CLAIM_SEMANTIC.json structural member.
    return _member_bytes("CLAIM_SEMANTIC.json")


_SNAPSHOT_CLAIM_EMPTY_OBJECT = {
    "audit_family": "capture",
    "capture_coverage_relation_logical_sha256": _EMPTY_SHA256,
    "capture_coverage_state": "CAPTURE_EMPTY_PREFIX_ORIGIN",
    "covered_through_fence_sequence": None,
    "duplicate_key_count": 0,
    "first_key_canonical_json": None,
    "last_key_canonical_json": None,
    "ordered_relation_logical_sha256": _EMPTY_SHA256,
    "partition_entries": [],
    "partition_entries_semantic_logical_sha256": _EMPTY_SHA256,
    "previous_publication_commit_file_sha256": None,
    "previous_snapshot_file_sha256": None,
    "run_id": _RUN_ID,
    "schema_version": "local_curl_snapshot_publication_claim_semantic.v23",
    "snapshot_sequence": 0,
    "spec_revision": 23,
    "total_row_count": 0,
}


def _snapshot_claim_empty_bytes() -> bytes:
    raw = _canonical_json_bytes(_SNAPSHOT_CLAIM_EMPTY_OBJECT)
    assert len(raw) == 846
    assert _hl.sha256(raw).hexdigest() == (
        "9044aa51db761d21631926dd49d637cf65c750dfaa5b0780d47d143f16943ec1"
    )
    return raw


def _snapshot_claim_forbidden_count_bytes() -> bytes:
    obj = _json.loads(_snapshot_claim_one_partition_bytes())
    obj["snapshot_partition_count"] = 1
    raw = _canonical_json_bytes(obj)
    assert len(raw) == 1380
    assert _hl.sha256(raw).hexdigest() == (
        "484c9d4cabb03363c306d85ecb6066f1dc96db3c76ae5285a33ea0c60f08d80d"
    )
    return raw


def _descriptor_set_input(rows, claim_bytes):
    return DescriptorSetInput(
        unit_context=_VALID_UNIT_CONTEXT,
        descriptors=_rows_to_descriptors(rows),
        snapshot_claim_semantic_bytes=claim_bytes,
    )


# --- validate_prepared_descriptor_set: T009, T041, T042, T044, T068,
# T069, T070, T090, T107, T108, T109, T153 ------------------------------

_A2_SET_ASSURANCES = (
    AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
    AssuranceLevel.A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS,
    AssuranceLevel.A2_DESCRIPTOR_SET_COMPLETE,
)

from pm_research.local_curl_per_side.prepared_evidence import (
    DescriptorSetInput,
    validate_prepared_descriptor_set,
)


def test_t009_complete_one_partition_descriptor_set_returns_a2_set():
    value = _descriptor_set_input(
        _BASE_DESCRIPTOR_ROWS, _snapshot_claim_one_partition_bytes()
    )
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.I0A_VALID_A2_SET
    assert result.established_assurances == _A2_SET_ASSURANCES


def test_t041_missing_publication_marker_returns_err_role_cardinality_invalid():
    rows = _repack_rows(
        [
            r
            for r in _BASE_DESCRIPTOR_ROWS
            if r["object_role"]
            not in ("PUBLICATION_MARKER", "PUBLICATION_MARKER_SIDECAR")
        ]
    )
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_ROLE_CARDINALITY_INVALID
    assert result.established_assurances == ()


def test_t042_duplicate_ordinal_zero_returns_err_ordinal_sequence_invalid():
    rows = [_copy.deepcopy(r) for r in _BASE_DESCRIPTOR_ROWS]
    rows[1]["object_ordinal"] = 0
    rows[1]["durable_source_path"] = _PREP_OBJECTS_PREFIX + "0000000000.bin"
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_ORDINAL_SEQUENCE_INVALID
    assert result.established_assurances == ()


def test_t044_sidecar_pairs_to_sidecar_returns_err_sidecar_relation_invalid():
    rows = [_copy.deepcopy(r) for r in _BASE_DESCRIPTOR_ROWS]
    rows[2]["sidecar_of_object_ordinal"] = 5
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_SIDECAR_RELATION_INVALID
    assert result.established_assurances == ()


def test_t068_empty_partition_set_with_empty_claim_returns_a2_set():
    rows = _repack_rows([r for r in _BASE_DESCRIPTOR_ROWS if r["object_ordinal"] != 0])
    value = _descriptor_set_input(rows, _snapshot_claim_empty_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.I0A_VALID_A2_SET
    assert result.established_assurances == _A2_SET_ASSURANCES


def test_t069_forbidden_snapshot_partition_count_returns_err_selected_schema_invalid():
    value = _descriptor_set_input(
        _BASE_DESCRIPTOR_ROWS, _snapshot_claim_forbidden_count_bytes()
    )
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_SELECTED_SCHEMA_INVALID
    assert result.established_assurances == ()


def test_t070_zero_partition_payload_with_one_partition_claim_returns_err_role_cardinality_invalid():
    rows = _repack_rows([r for r in _BASE_DESCRIPTOR_ROWS if r["object_ordinal"] != 0])
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_ROLE_CARDINALITY_INVALID
    assert result.established_assurances == ()


def test_t090_excluded_unit_descriptor_set_returns_stop_unit_kind_not_accepted_i0a():
    value = DescriptorSetInput(
        unit_context=_EXCLUDED_UNIT_CONTEXT,
        descriptors=(),
        snapshot_claim_semantic_bytes=b"{",
    )
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


def test_t107_partition_path_mismatch_returns_err_plan_unit_cross_member_mismatch():
    rows = [_copy.deepcopy(r) for r in _BASE_DESCRIPTOR_ROWS]
    rows[0]["canonical_target_path"] = rows[0]["canonical_target_path"].replace(
        "/capture/partitions/", "/analysis_compatibility/partitions/"
    )
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_PLAN_UNIT_CROSS_MEMBER_MISMATCH
    assert result.established_assurances == ()


def test_t108_partition_identity_mismatch_returns_err_plan_unit_cross_member_mismatch():
    rows = [_copy.deepcopy(r) for r in _BASE_DESCRIPTOR_ROWS]
    rows[0]["canonical_target_path"] = rows[0]["canonical_target_path"].replace(
        _PARTITION_ID_BACA, "part_" + "f" * 64
    )
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_PLAN_UNIT_CROSS_MEMBER_MISMATCH
    assert result.established_assurances == ()


def test_t109_partition_logical_hash_mismatch_returns_err_plan_unit_cross_member_mismatch():
    rows = [_copy.deepcopy(r) for r in _BASE_DESCRIPTOR_ROWS]
    rows[0]["logical_sha256"] = (
        "41f974d00755521f4c9a9014e0b3867b6577fb971e99441eed92e20820149343"
    )
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_PLAN_UNIT_CROSS_MEMBER_MISMATCH
    assert result.established_assurances == ()


def test_t153_duplicate_canonical_target_returns_err_canonical_target_duplicate():
    rows = [_copy.deepcopy(r) for r in _BASE_DESCRIPTOR_ROWS]
    rows[1]["canonical_target_path"] = rows[0]["canonical_target_path"]
    value = _descriptor_set_input(rows, _snapshot_claim_one_partition_bytes())
    result = validate_prepared_descriptor_set(value)
    assert result.code == I0AResultCode.ERR_CANONICAL_TARGET_DUPLICATE
    assert result.established_assurances == ()


# --- validate_payload_logical_representation: T067 ---------------------


def test_t067_valid_table_schema_returns_stop_payload_logical_validation_out_of_scope():
    value = AcceptedRegistryLogicalValidationInput(
        schema_id="table:snapshot_partition",
        decoded_rows=None,
        expected_logical_sha256="0" * 64,
        accepted_registry_bytes=_pe_canonical_registry_bytes(),
    )
    result = validate_payload_logical_representation(value)
    assert result.code == I0AResultCode.STOP_PAYLOAD_LOGICAL_VALIDATION_OUT_OF_SCOPE
    assert result.established_assurances == ()


# --- validate_selected_json_payload: T012, T052, T053, T064, T072,
# T093, T105 -----------------------------------------------------------

from pm_research.local_curl_per_side.prepared_evidence import (
    SelectedJsonPayloadInput,
    validate_selected_json_payload,
)


def _selected_input(rows, selected_ordinal, selected_bytes, paired_bytes,
                    registry_bytes=None, unit_context=None, claim_bytes=None):
    return SelectedJsonPayloadInput(
        descriptor_set_input=DescriptorSetInput(
            unit_context=unit_context or _VALID_UNIT_CONTEXT,
            descriptors=_rows_to_descriptors(rows) if rows else (),
            snapshot_claim_semantic_bytes=(
                claim_bytes
                if claim_bytes is not None or rows is None
                else _snapshot_claim_one_partition_bytes()
            ),
        ),
        selected_object_ordinal=selected_ordinal,
        selected_payload_bytes=selected_bytes,
        paired_target_payload_bytes=paired_bytes,
        accepted_registry_bytes=(
            registry_bytes if registry_bytes is not None else _pe_canonical_registry_bytes()
        ),
    )


def test_t012_valid_history_sidecar_selection_returns_a6_selected():
    value = _selected_input(
        _BASE_DESCRIPTOR_ROWS, 2, _payload_bytes(2), _payload_bytes(1)
    )
    result = validate_selected_json_payload(value)
    assert result.code == I0AResultCode.I0A_VALID_A6_SELECTED
    assert result.established_assurances == (
        AssuranceLevel.A1_LEXICAL_PATH_SHAPE,
        AssuranceLevel.A1_REGISTRY_BINDING_RESOLVED,
        AssuranceLevel.A2_SINGLE_DESCRIPTOR_CLOSED_FIELDS,
        AssuranceLevel.A2_DESCRIPTOR_SET_COMPLETE,
        AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
        AssuranceLevel.A6_DESCRIPTOR_SELECTED_SCHEMA_COMPLETE,
    )


def test_t052_missing_paired_proof_returns_err_paired_target_physical_proof_required():
    value = _selected_input(_BASE_DESCRIPTOR_ROWS, 2, _payload_bytes(2), None)
    result = validate_selected_json_payload(value)
    assert result.code == I0AResultCode.ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED
    assert result.established_assurances == ()


def test_t053_cross_paired_sidecar_returns_err_paired_target_descriptor_mismatch():
    rows = [_copy.deepcopy(r) for r in _BASE_DESCRIPTOR_ROWS]
    rows[2]["sidecar_of_object_ordinal"] = 4
    value = _selected_input(rows, 2, _payload_bytes(2), _payload_bytes(4))
    result = validate_selected_json_payload(value)
    assert result.code == I0AResultCode.ERR_PAIRED_TARGET_DESCRIPTOR_MISMATCH
    assert result.established_assurances == ()


def test_t064_selected_manifest_schema_returns_stop_content_schema_not_implemented_i0a():
    value = _selected_input(_BASE_DESCRIPTOR_ROWS, 1, _payload_bytes(1), None)
    result = validate_selected_json_payload(value)
    assert result.code == I0AResultCode.STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A
    assert result.established_assurances == ()


def test_t072_wrong_paired_hash_returns_err_physical_sha256_mismatch():
    mutated_paired = bytes([_payload_bytes(1)[0] ^ 0x01]) + _payload_bytes(1)[1:]
    value = _selected_input(_BASE_DESCRIPTOR_ROWS, 2, _payload_bytes(2), mutated_paired)
    result = validate_selected_json_payload(value)
    assert result.code == I0AResultCode.ERR_PHYSICAL_SHA256_MISMATCH
    assert result.established_assurances == ()


def test_t093_bad_registry_bytes_returns_err_governing_package_bytes_mismatch():
    value = _selected_input(
        _BASE_DESCRIPTOR_ROWS, 999, b"{", None, registry_bytes=b"\x00"
    )
    result = validate_selected_json_payload(value)
    assert result.code == I0AResultCode.ERR_GOVERNING_PACKAGE_BYTES_MISMATCH
    assert result.established_assurances == ()


def test_t105_excluded_unit_selection_returns_stop_unit_kind_not_accepted_i0a():
    value = SelectedJsonPayloadInput(
        descriptor_set_input=DescriptorSetInput(
            unit_context=_EXCLUDED_UNIT_CONTEXT,
            descriptors=(),
            snapshot_claim_semantic_bytes=None,
        ),
        selected_object_ordinal=0,
        selected_payload_bytes=b"\x00",
        paired_target_payload_bytes=None,
        accepted_registry_bytes=_pe_canonical_registry_bytes(),
    )
    result = validate_selected_json_payload(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


# --- validate_structural_json_member: T051, T055, T056, T077, T078,
# T110, T111, T126-T141 ------------------------------------------------

_A6_STRUCTURAL_ASSURANCES = (
    AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
    AssuranceLevel.A6_STRUCTURAL_SCHEMA_COMPLETE,
)
_A3_A4_STRUCTURAL_ASSURANCES = (
    AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
    AssuranceLevel.A4_DECODED_LOGICAL_ROWS_VALIDATED,
)
_A3_SIDECAR_ASSURANCES = (
    AssuranceLevel.A3_EXACT_LENGTH_AND_SHA256_RECONCILED,
    AssuranceLevel.A3_STRUCTURAL_SIDECAR_PAIR_RECONCILED,
)

_MEMBER_NAME_BY_STRING = {
    "CLAIM_SCOPE.json": StructuralMemberName.CLAIM_SCOPE_JSON,
    "CLAIM_SCOPE.sha256": StructuralMemberName.CLAIM_SCOPE_SHA256,
    "CLAIM_SEMANTIC.json": StructuralMemberName.CLAIM_SEMANTIC_JSON,
    "CLAIM_SEMANTIC.sha256": StructuralMemberName.CLAIM_SEMANTIC_SHA256,
    "PREPARATION_PLAN.json": StructuralMemberName.PREPARATION_PLAN_JSON,
    "PREPARATION_PLAN.sha256": StructuralMemberName.PREPARATION_PLAN_SHA256,
    "PREPARED_UNIT.json": StructuralMemberName.PREPARED_UNIT_JSON,
    "PREPARED_UNIT.sha256": StructuralMemberName.PREPARED_UNIT_SHA256,
}

_SIDECAR_PAIRED_JSON = {
    "CLAIM_SCOPE.sha256": "CLAIM_SCOPE.json",
    "CLAIM_SEMANTIC.sha256": "CLAIM_SEMANTIC.json",
    "PREPARATION_PLAN.sha256": "PREPARATION_PLAN.json",
    "PREPARED_UNIT.sha256": "PREPARED_UNIT.json",
}


def _member_input(member_string, payload_bytes, expected_len, expected_sha,
                  with_pair):
    if with_pair:
        paired_name = _SIDECAR_PAIRED_JSON[member_string]
        p_len, p_sha = _STRUCTURAL_MEMBER_EXPECTATIONS[paired_name]
        paired = (_member_bytes(paired_name), p_len, p_sha)
    else:
        paired = (None, None, None)
    return StructuralJsonMemberInput(
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        run_id=_RUN_ID,
        prepared_unit_id=_STRUCTURAL_PREP_ID,
        member_name=_MEMBER_NAME_BY_STRING[member_string],
        payload_bytes=payload_bytes,
        expected_file_size_bytes=expected_len,
        expected_file_sha256=expected_sha,
        paired_target_bytes=paired[0],
        paired_target_expected_file_size_bytes=paired[1],
        paired_target_expected_file_sha256=paired[2],
    )


def _pinned_member_input(member_string, with_pair):
    exp_len, exp_sha = _STRUCTURAL_MEMBER_EXPECTATIONS[member_string]
    return _member_input(
        member_string, _member_bytes(member_string), exp_len, exp_sha, with_pair
    )


def _mutated_member_object_input(member_string, mutate, expected_len, expected_sha):
    obj = _json.loads(_member_bytes(member_string))
    mutate(obj)
    raw = _canonical_json_bytes(obj)
    assert len(raw) == expected_len
    assert _hl.sha256(raw).hexdigest() == expected_sha
    return _member_input(member_string, raw, expected_len, expected_sha, False)


def test_t051_plan_unknown_field_returns_err_selected_schema_invalid():
    value = _mutated_member_object_input(
        "PREPARATION_PLAN.json",
        lambda o: o.__setitem__("unknown", 1),
        5835,
        "8d8a0682e083ddc82236459a74198baf52523b7e784958ff33d046b42addf03a",
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_SELECTED_SCHEMA_INVALID
    assert result.established_assurances == ()


def test_t055_claim_semantic_predecessor_invalid_returns_err_predecessor_rule_invalid():
    value = _mutated_member_object_input(
        "CLAIM_SEMANTIC.json",
        lambda o: o.__setitem__("previous_publication_commit_file_sha256", "a" * 64),
        1413,
        "4a7d915f429b795ab8865275bd073fa1b07795371eeeb8e1195d50eb68a7d8a4",
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_PREDECESSOR_RULE_INVALID
    assert result.established_assurances == ()


def _mutate_coverage_invalid(o):
    o["capture_coverage_state"] = "NOT_CAPTURE"
    o["capture_coverage_relation_logical_sha256"] = "a" * 64


def test_t056_claim_semantic_coverage_invalid_returns_err_coverage_state_invalid():
    value = _mutated_member_object_input(
        "CLAIM_SEMANTIC.json",
        _mutate_coverage_invalid,
        1332,
        "2244ffd9e8de090881cf746d813f3f85ec1a05d2330919575929aaf808a13116",
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_COVERAGE_STATE_INVALID
    assert result.established_assurances == ()


def test_t077_claim_scope_predecessor_invalid_returns_err_predecessor_rule_invalid():
    value = _mutated_member_object_input(
        "CLAIM_SCOPE.json",
        lambda o: o.__setitem__("expected_predecessor_commit_sha256", "a" * 64),
        4841,
        "fa3fad9b2267c7382179cd827a688e85244035528e5383c58d354165d8c52b7b",
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_PREDECESSOR_RULE_INVALID
    assert result.established_assurances == ()


def test_t078_claim_semantic_covered_sequence_invalid_returns_err_coverage_state_invalid():
    value = _mutated_member_object_input(
        "CLAIM_SEMANTIC.json",
        lambda o: o.__setitem__("capture_coverage_state", "CAPTURE_EMPTY_PREFIX_ORIGIN"),
        1348,
        "cd07d7b832b8cbb187863476686c219e4ef34cfd0a961bc7cfdebc080b14accd",
    )
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_COVERAGE_STATE_INVALID
    assert result.established_assurances == ()


def test_t110_valid_plan_member_returns_a3_a4_structural_object():
    value = _pinned_member_input("PREPARATION_PLAN.json", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_A4_STRUCTURAL_OBJECT
    assert result.established_assurances == _A3_A4_STRUCTURAL_ASSURANCES


def test_t111_valid_prepared_unit_member_returns_a3_a4_structural_object():
    value = _pinned_member_input("PREPARED_UNIT.json", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_A4_STRUCTURAL_OBJECT
    assert result.established_assurances == _A3_A4_STRUCTURAL_ASSURANCES


def test_t126_valid_claim_scope_member_returns_a6_structural():
    value = _pinned_member_input("CLAIM_SCOPE.json", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A6_STRUCTURAL
    assert result.established_assurances == _A6_STRUCTURAL_ASSURANCES


def test_t127_valid_claim_scope_sidecar_member_returns_a3_structural_sidecar():
    value = _pinned_member_input("CLAIM_SCOPE.sha256", True)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_STRUCTURAL_SIDECAR
    assert result.established_assurances == _A3_SIDECAR_ASSURANCES


def test_t128_valid_claim_semantic_member_returns_a6_structural():
    value = _pinned_member_input("CLAIM_SEMANTIC.json", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A6_STRUCTURAL
    assert result.established_assurances == _A6_STRUCTURAL_ASSURANCES


def test_t129_valid_claim_semantic_sidecar_member_returns_a3_structural_sidecar():
    value = _pinned_member_input("CLAIM_SEMANTIC.sha256", True)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_STRUCTURAL_SIDECAR
    assert result.established_assurances == _A3_SIDECAR_ASSURANCES


def test_t130_valid_plan_member_second_pinned_instance_returns_a3_a4_structural_object():
    # T130 shares the valid_structural_plan_input fixture with T110 but is
    # a distinct pinned case ID with its own coverage record.
    value = _pinned_member_input("PREPARATION_PLAN.json", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_A4_STRUCTURAL_OBJECT
    assert result.established_assurances == _A3_A4_STRUCTURAL_ASSURANCES


def test_t131_valid_plan_sidecar_member_returns_a3_structural_sidecar():
    value = _pinned_member_input("PREPARATION_PLAN.sha256", True)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_STRUCTURAL_SIDECAR
    assert result.established_assurances == _A3_SIDECAR_ASSURANCES


def test_t132_valid_prepared_unit_member_second_pinned_instance_returns_a3_a4_structural_object():
    # T132 shares the valid_structural_prepared_unit_input fixture with
    # T111 but is a distinct pinned case ID with its own coverage record.
    value = _pinned_member_input("PREPARED_UNIT.json", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_A4_STRUCTURAL_OBJECT
    assert result.established_assurances == _A3_A4_STRUCTURAL_ASSURANCES


def test_t133_valid_prepared_unit_sidecar_member_returns_a3_structural_sidecar():
    value = _pinned_member_input("PREPARED_UNIT.sha256", True)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.I0A_VALID_A3_STRUCTURAL_SIDECAR
    assert result.established_assurances == _A3_SIDECAR_ASSURANCES


def _physically_mutated_input(member_string):
    # Pinned mutation rule: xor 0x01 at byte offset 0; retain the original
    # expected length and SHA-256.
    original = _member_bytes(member_string)
    mutated = bytes([original[0] ^ 0x01]) + original[1:]
    exp_len, exp_sha = _STRUCTURAL_MEMBER_EXPECTATIONS[member_string]
    return _member_input(member_string, mutated, exp_len, exp_sha, False)


def test_t134_physical_mutation_claim_scope_returns_err_physical_sha256_mismatch():
    result = validate_structural_json_member(_physically_mutated_input("CLAIM_SCOPE.json"))
    assert result.code == I0AResultCode.ERR_PHYSICAL_SHA256_MISMATCH
    assert result.established_assurances == ()


def test_t135_physical_mutation_claim_semantic_returns_err_physical_sha256_mismatch():
    result = validate_structural_json_member(
        _physically_mutated_input("CLAIM_SEMANTIC.json")
    )
    assert result.code == I0AResultCode.ERR_PHYSICAL_SHA256_MISMATCH
    assert result.established_assurances == ()


def test_t136_physical_mutation_plan_returns_err_physical_sha256_mismatch():
    result = validate_structural_json_member(
        _physically_mutated_input("PREPARATION_PLAN.json")
    )
    assert result.code == I0AResultCode.ERR_PHYSICAL_SHA256_MISMATCH
    assert result.established_assurances == ()


def test_t137_physical_mutation_prepared_unit_returns_err_physical_sha256_mismatch():
    result = validate_structural_json_member(
        _physically_mutated_input("PREPARED_UNIT.json")
    )
    assert result.code == I0AResultCode.ERR_PHYSICAL_SHA256_MISMATCH
    assert result.established_assurances == ()


def test_t138_missing_paired_proof_claim_scope_sidecar_returns_err_paired_target_physical_proof_required():
    value = _pinned_member_input("CLAIM_SCOPE.sha256", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED
    assert result.established_assurances == ()


def test_t139_missing_paired_proof_claim_semantic_sidecar_returns_err_paired_target_physical_proof_required():
    value = _pinned_member_input("CLAIM_SEMANTIC.sha256", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED
    assert result.established_assurances == ()


def test_t140_missing_paired_proof_plan_sidecar_returns_err_paired_target_physical_proof_required():
    value = _pinned_member_input("PREPARATION_PLAN.sha256", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED
    assert result.established_assurances == ()


def test_t141_missing_paired_proof_prepared_unit_sidecar_returns_err_paired_target_physical_proof_required():
    value = _pinned_member_input("PREPARED_UNIT.sha256", False)
    result = validate_structural_json_member(value)
    assert result.code == I0AResultCode.ERR_PAIRED_TARGET_PHYSICAL_PROOF_REQUIRED
    assert result.established_assurances == ()


# --- validate_prepared_unit_structure / dispatch_i0a_unit_validation /
# full-validation requests: T007, T014, T016, T017, T054, T057, T060,
# T061, T062, T079, T080, T081, T087, T095, T124, T125, T142, T143,
# T156, T157, T158, T159 -----------------------------------------------

from pm_research.local_curl_per_side.prepared_evidence import (
    FullPreparedObjectValidationRequest,
    FullPreparedUnitValidationRequest,
    PreparedUnitStructureInput,
    dispatch_i0a_unit_validation,
    validate_full_prepared_object,
    validate_full_prepared_unit,
    validate_prepared_unit_structure,
)


def _complete_unit_structure_input() -> PreparedUnitStructureInput:
    members, payloads = _unit_bundle()
    return PreparedUnitStructureInput(
        accepted_registry_bytes=_pe_canonical_registry_bytes(),
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        structural_members={
            _MEMBER_NAME_BY_STRING[name]: b for name, b in members.items()
        },
        object_payload_bytes_by_ordinal=dict(payloads),
    )


def _excluded_fence_structure_input(registry_bytes: bytes) -> PreparedUnitStructureInput:
    return PreparedUnitStructureInput(
        accepted_registry_bytes=registry_bytes,
        unit_context=_EXCLUDED_UNIT_CONTEXT,
        structural_members={},
        object_payload_bytes_by_ordinal={},
    )


def _structure_override_input(fixture_name: str) -> PreparedUnitStructureInput:
    # The pinned structure-mutation fixtures replace the full structural
    # member map while reusing the complete unit's 14 object payloads.
    overrides = _extra_bundle()["structure_overrides"][fixture_name]
    _members, payloads = _unit_bundle()
    return PreparedUnitStructureInput(
        accepted_registry_bytes=_pe_canonical_registry_bytes(),
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        structural_members={
            _MEMBER_NAME_BY_STRING[name]: bytes.fromhex(hexv)
            for name, hexv in overrides.items()
        },
        object_payload_bytes_by_ordinal=dict(payloads),
    )


def _analysis_unit_structure_input(fixture_name: str) -> PreparedUnitStructureInput:
    unit = _extra_bundle()["analysis_units"][fixture_name]
    uc = unit["unit_context"]
    return PreparedUnitStructureInput(
        accepted_registry_bytes=_pe_canonical_registry_bytes(),
        unit_context=UnitContext(
            unit_kind=PreparedUnitKind(uc["unit_kind"]),
            subject_family=uc["subject_family"],
            subject_sequence=uc["subject_sequence"],
        ),
        structural_members={
            _MEMBER_NAME_BY_STRING[name]: bytes.fromhex(hexv)
            for name, hexv in unit["structural_members"].items()
        },
        object_payload_bytes_by_ordinal={
            int(k): bytes.fromhex(hexv)
            for k, hexv in unit["object_payloads"].items()
        },
    )


def test_t014_excluded_fence_structure_returns_stop_unit_kind_not_accepted_i0a():
    value = _excluded_fence_structure_input(_pe_canonical_registry_bytes())
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


def test_t007_dispatch_excluded_fence_structure_returns_stop_unit_kind_not_accepted_i0a():
    value = _excluded_fence_structure_input(_pe_canonical_registry_bytes())
    result = dispatch_i0a_unit_validation(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


def test_t062_dispatch_excluded_unit_context_returns_stop_unit_kind_not_accepted_i0a():
    value = _excluded_fence_structure_input(b"\x00")
    result = dispatch_i0a_unit_validation(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


def test_t087_dispatch_excluded_unit_gate_precedes_registry_check():
    # The unit-kind gate precedes the (deliberately invalid) registry
    # bytes; the stop fires without touching the registry.
    value = _excluded_fence_structure_input(b"\x00")
    result = dispatch_i0a_unit_validation(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


def test_t095_structure_excluded_unit_gate_precedes_registry_check():
    value = _excluded_fence_structure_input(b"\x00")
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


def test_t054_missing_prepared_unit_sidecar_returns_err_structural_member_set_invalid():
    members, payloads = _unit_bundle()
    value = PreparedUnitStructureInput(
        accepted_registry_bytes=_pe_canonical_registry_bytes(),
        unit_context=_STRUCTURAL_UNIT_CONTEXT,
        structural_members={
            _MEMBER_NAME_BY_STRING[name]: b
            for name, b in members.items()
            if name != "PREPARED_UNIT.sha256"
        },
        object_payload_bytes_by_ordinal=dict(payloads),
    )
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.ERR_STRUCTURAL_MEMBER_SET_INVALID
    assert result.established_assurances == ()


def test_t057_plan_run_id_mismatch_returns_err_plan_unit_cross_member_mismatch():
    value = _structure_override_input("structure_plan_run_id_mismatch_input")
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.ERR_PLAN_UNIT_CROSS_MEMBER_MISMATCH
    assert result.established_assurances == ()


def test_t079_subject_sequence_mismatch_returns_err_plan_unit_cross_member_mismatch():
    value = _structure_override_input("structure_subject_sequence_mismatch_input")
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.ERR_PLAN_UNIT_CROSS_MEMBER_MISMATCH
    assert result.established_assurances == ()


def test_t060_prepared_unit_id_mismatch_returns_err_prepared_unit_id_mismatch():
    value = _structure_override_input("structure_prepared_unit_id_mismatch_input")
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.ERR_PREPARED_UNIT_ID_MISMATCH
    assert result.established_assurances == ()


def test_t080_prepared_unit_id_mismatch_second_pinned_instance():
    # T080 shares the structure_prepared_unit_id_mismatch_input fixture
    # with T060 but is a distinct pinned case ID with its own record.
    value = _structure_override_input("structure_prepared_unit_id_mismatch_input")
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.ERR_PREPARED_UNIT_ID_MISMATCH
    assert result.established_assurances == ()


def test_t061_claim_semantic_schema_mismatch_returns_err_claim_semantic_schema_mismatch():
    value = _structure_override_input("structure_claim_semantic_schema_mismatch_input")
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.ERR_CLAIM_SEMANTIC_SCHEMA_MISMATCH
    assert result.established_assurances == ()


def test_t081_claim_semantic_schema_mismatch_second_pinned_instance():
    # T081 shares the structure_claim_semantic_schema_mismatch_input
    # fixture with T061 but is a distinct pinned case ID with its own
    # record.
    value = _structure_override_input("structure_claim_semantic_schema_mismatch_input")
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.ERR_CLAIM_SEMANTIC_SCHEMA_MISMATCH
    assert result.established_assurances == ()


def test_t142_complete_unit_returns_stop_content_schema_not_implemented_i0a():
    value = _complete_unit_structure_input()
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A
    assert result.established_assurances == ()


def test_t143_dispatch_complete_unit_returns_stop_content_schema_not_implemented_i0a():
    value = _complete_unit_structure_input()
    result = dispatch_i0a_unit_validation(value)
    assert result.code == I0AResultCode.STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A
    assert result.established_assurances == ()


def test_t156_analysis_compatibility_unit_returns_stop_content_schema_not_implemented_i0a():
    value = _analysis_unit_structure_input(
        "complete_snapshot_publication_analysis_compatibility"
    )
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A
    assert result.established_assurances == ()


def test_t157_dispatch_analysis_compatibility_unit_returns_stop_content_schema_not_implemented_i0a():
    value = _analysis_unit_structure_input(
        "complete_snapshot_publication_analysis_compatibility"
    )
    result = dispatch_i0a_unit_validation(value)
    assert result.code == I0AResultCode.STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A
    assert result.established_assurances == ()


def test_t158_analysis_strict_unit_returns_stop_content_schema_not_implemented_i0a():
    value = _analysis_unit_structure_input(
        "complete_snapshot_publication_analysis_strict"
    )
    result = validate_prepared_unit_structure(value)
    assert result.code == I0AResultCode.STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A
    assert result.established_assurances == ()


def test_t159_dispatch_analysis_strict_unit_returns_stop_content_schema_not_implemented_i0a():
    value = _analysis_unit_structure_input(
        "complete_snapshot_publication_analysis_strict"
    )
    result = dispatch_i0a_unit_validation(value)
    assert result.code == I0AResultCode.STOP_CONTENT_SCHEMA_NOT_IMPLEMENTED_I0A
    assert result.established_assurances == ()


def test_t016_full_prepared_object_returns_stop_filesystem_facts_out_of_scope():
    request = FullPreparedObjectValidationRequest(
        selected_input=_selected_input(
            _BASE_DESCRIPTOR_ROWS, 2, _payload_bytes(2), _payload_bytes(1)
        ),
        filesystem_request=FilesystemValidationRequest(
            claim_kind=FilesystemClaimKind.CANONICAL_TARGET_REOPENED,
            claimed_path=(
                _CAPTURE_PREFIX
                + "audit_snapshot_history/00000000000000000000/PUBLICATION_COMMITTED.json"
            ),
            caller_asserted_value=True,
        ),
    )
    result = validate_full_prepared_object(request)
    assert result.code == I0AResultCode.STOP_FILESYSTEM_FACTS_OUT_OF_SCOPE
    assert result.established_assurances == ()


def test_t124_full_prepared_object_excluded_returns_stop_unit_kind_not_accepted_i0a():
    request = FullPreparedObjectValidationRequest(
        selected_input=SelectedJsonPayloadInput(
            descriptor_set_input=DescriptorSetInput(
                unit_context=_EXCLUDED_UNIT_CONTEXT,
                descriptors=(),
                snapshot_claim_semantic_bytes=None,
            ),
            selected_object_ordinal=0,
            selected_payload_bytes=b"\x00",
            paired_target_payload_bytes=None,
            accepted_registry_bytes=_pe_canonical_registry_bytes(),
        ),
        filesystem_request=FilesystemValidationRequest(
            claim_kind=FilesystemClaimKind.CANONICAL_TARGET_REOPENED,
            claimed_path="/absolute",
            caller_asserted_value=True,
        ),
    )
    result = validate_full_prepared_object(request)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()


def test_t017_full_prepared_unit_returns_stop_filesystem_facts_out_of_scope():
    request = FullPreparedUnitValidationRequest(
        unit_input=_complete_unit_structure_input(),
        filesystem_requests=(),
    )
    result = validate_full_prepared_unit(request)
    assert result.code == I0AResultCode.STOP_FILESYSTEM_FACTS_OUT_OF_SCOPE
    assert result.established_assurances == ()


def test_t125_full_prepared_unit_excluded_returns_stop_unit_kind_not_accepted_i0a():
    request = FullPreparedUnitValidationRequest(
        unit_input=_excluded_fence_structure_input(_pe_canonical_registry_bytes()),
        filesystem_requests=(),
    )
    result = validate_full_prepared_unit(request)
    assert result.code == I0AResultCode.STOP_UNIT_KIND_NOT_ACCEPTED_I0A
    assert result.established_assurances == ()
